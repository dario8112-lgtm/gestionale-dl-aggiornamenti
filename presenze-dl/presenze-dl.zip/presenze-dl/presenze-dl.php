<?php
/**
 * Plugin Name: Presenze DL
 * Description: Gestione dipendenti di D.L. S.A.S.: presenze mensili, documenti (buste paga, tredicesime, altro), ferie e permessi con approvazione. Area riservata con lo shortcode [area_dipendenti].
 * Version: 2.9.3
 * Author: D.L. S.A.S.
 * Text Domain: presenze-dl
 */
if (!defined('ABSPATH')) exit;

define('PDL_VER', '2.9.3');
define('PDL_AGG', 'https://raw.githubusercontent.com/dario8112-lgtm/gestionale-dl-aggiornamenti/main/presenze-dl/versione.json');

class Presenze_DL {
    const CODICI = ['P' => 'Presente', 'F' => 'Ferie', 'PE' => 'Permesso', 'M' => 'Malattia', 'A' => 'Assente', 'R' => 'Riposo', 'FS' => 'Festivo'];
    const CATEGORIE = ['Busta paga', 'Tredicesima', 'Quattordicesima', 'CU', 'Contratto', 'Altro'];
    const COLORI = ['P' => '#16a34a', 'F' => '#2563eb', 'PE' => '#9333ea', 'M' => '#dc2626', 'A' => '#ea580c', 'R' => '#64748b', 'FS' => '#0891b2'];
    const MESI = ['', 'Gennaio', 'Febbraio', 'Marzo', 'Aprile', 'Maggio', 'Giugno', 'Luglio', 'Agosto', 'Settembre', 'Ottobre', 'Novembre', 'Dicembre'];
    const META = ['matricola' => 'Matricola', 'codice_fiscale' => 'Codice fiscale', 'telefono' => 'Telefono', 'mansione' => 'Mansione', 'data_assunzione' => 'Data assunzione', 'ore_giorno' => 'Ore al giorno'];

    static function t($n) { global $wpdb; return $wpdb->prefix . 'pdl_' . $n; }

    /* ---------------- attivazione ---------------- */
    static function activate() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $c = $wpdb->get_charset_collate();
        dbDelta("CREATE TABLE " . self::t('presenze') . " (
            utente_id BIGINT UNSIGNED NOT NULL, giorno DATE NOT NULL, codice VARCHAR(4) NOT NULL, ore DECIMAL(5,2) NULL,
            PRIMARY KEY  (utente_id, giorno)) $c;");
        dbDelta("CREATE TABLE " . self::t('documenti') . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, utente_id BIGINT UNSIGNED NOT NULL, categoria VARCHAR(40) NOT NULL,
            anno SMALLINT NULL, mese TINYINT NULL, titolo VARCHAR(255) NOT NULL, file VARCHAR(255) NOT NULL, nome_originale VARCHAR(255) NOT NULL,
            caricato DATETIME NOT NULL, scaricato DATETIME NULL, tipo VARCHAR(10) NOT NULL DEFAULT 'doc', netto DECIMAL(10,2) NULL, emissione DATE NULL,
            note TEXT NULL, condiviso TINYINT(1) NOT NULL DEFAULT 1, competenza DATE NULL, scadenza DATE NULL,
            PRIMARY KEY  (id), KEY utente_id (utente_id), KEY tipo_anno (tipo, anno)) $c;");
        dbDelta("CREATE TABLE " . self::t('richieste_doc') . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, utente_id BIGINT UNSIGNED NOT NULL, titolo VARCHAR(255) NOT NULL, nota TEXT NULL, categoria VARCHAR(60) NULL,
            scadenza DATE NULL, stato VARCHAR(20) NOT NULL DEFAULT 'In attesa', documento_id BIGINT UNSIGNED NULL, creata DATETIME NOT NULL,
            PRIMARY KEY  (id), KEY utente_id (utente_id)) $c;");
        dbDelta("CREATE TABLE " . self::t('giust') . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, utente_id BIGINT UNSIGNED NOT NULL, giorno DATE NOT NULL, tipo VARCHAR(60) NOT NULL, ore DECIMAL(5,2) NULL,
            dalle TIME NULL, alle TIME NULL, intero TINYINT(1) NOT NULL DEFAULT 1, stato VARCHAR(15) NOT NULL DEFAULT 'Approvato', nota VARCHAR(255) NULL, nota_admin VARCHAR(255) NULL, protocollo VARCHAR(60) NULL,
            gruppo VARCHAR(20) NULL, creato DATETIME NOT NULL, creato_da BIGINT UNSIGNED NULL,
            PRIMARY KEY  (id), KEY utente_giorno (utente_id, giorno), KEY stato (stato), KEY gruppo (gruppo)) $c;");
        dbDelta("CREATE TABLE " . self::t('correzioni') . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, utente_id BIGINT UNSIGNED NOT NULL, anno SMALLINT NOT NULL, mese TINYINT NOT NULL, conto VARCHAR(20) NOT NULL,
            ore DECIMAL(6,2) NOT NULL, nota VARCHAR(255) NULL, creato DATETIME NOT NULL, PRIMARY KEY  (id), KEY utente_id (utente_id)) $c;");
        self::colonne();
        self::migra_presenze();
        if (version_compare(get_option('pdl_ver', '0'), '2.0.0', '<'))
            $wpdb->query("UPDATE " . self::t('documenti') . " SET tipo='busta' WHERE categoria IN ('Busta paga','Tredicesima','Quattordicesima')");
        dbDelta("CREATE TABLE " . self::t('richieste') . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, utente_id BIGINT UNSIGNED NOT NULL, tipo VARCHAR(20) NOT NULL,
            dal DATE NOT NULL, al DATE NOT NULL, ore DECIMAL(5,2) NULL, motivo TEXT NULL, stato VARCHAR(20) NOT NULL DEFAULT 'In attesa',
            nota_admin TEXT NULL, creata DATETIME NOT NULL, PRIMARY KEY  (id), KEY utente_id (utente_id)) $c;");
        add_role('dipendente', 'Dipendente', ['read' => true]);
        self::cartella();
        self::crea_pagine();
        update_option('pdl_ver', PDL_VER);
    }

    /** Aggiunge le colonne mancanti nel caso in cui l'aggiornamento automatico della tabella non le abbia create */
    static function colonne() {
        global $wpdb; $tg = self::t('giust');
        if (get_option('pdl_dedup') !== '1' && $wpdb->get_var("SHOW TABLES LIKE '$tg'")) { // rimuove i doppioni creati per errore (stesso dipendente, giorno, tipo, orari e stato)
            $wpdb->query("DELETE a FROM $tg a JOIN $tg b ON a.utente_id=b.utente_id AND a.giorno=b.giorno AND a.tipo=b.tipo AND a.stato=b.stato AND a.ore=b.ore AND a.dalle<=>b.dalle AND a.alle<=>b.alle AND a.id>b.id");
            update_option('pdl_dedup', '1');
        }
        global $wpdb;
        $t = self::t('documenti');
        $ci = $wpdb->get_col("SHOW COLUMNS FROM $t");
        if (!$ci) return;
        $vuole = ['tipo' => "VARCHAR(10) NOT NULL DEFAULT 'doc'", 'netto' => 'DECIMAL(10,2) NULL', 'emissione' => 'DATE NULL', 'note' => 'TEXT NULL',
                  'condiviso' => 'TINYINT(1) NOT NULL DEFAULT 1', 'competenza' => 'DATE NULL', 'scadenza' => 'DATE NULL'];
        foreach ($vuole as $c => $def) if (!in_array($c, $ci, true)) $wpdb->query("ALTER TABLE $t ADD COLUMN $c $def");
        $t = self::t('giust'); $ci = $wpdb->get_col("SHOW COLUMNS FROM $t");
        if ($ci) foreach (['dalle' => 'TIME NULL', 'alle' => 'TIME NULL', 'intero' => 'TINYINT(1) NOT NULL DEFAULT 1', 'nota' => 'VARCHAR(255) NULL', 'nota_admin' => 'VARCHAR(255) NULL',
            'protocollo' => 'VARCHAR(60) NULL', 'gruppo' => 'VARCHAR(20) NULL', 'creato_da' => 'BIGINT UNSIGNED NULL'] as $c => $def) if (!in_array($c, $ci, true)) $wpdb->query("ALTER TABLE $t ADD COLUMN $c $def");
    }

    static function crea_pagine() {
        foreach (['pdl_pagina' => ['Area dipendenti', 'area-dipendenti', '[area_dipendenti]'],
                  'pdl_pagina_gestione' => ['Gestione dipendenti', 'gestione-dipendenti', '[gestione_dipendenti]']] as $opt => $d) {
            $id = get_option($opt);
            if ($id && get_post($id) && get_post_status($id) !== 'trash') continue;
            $id = wp_insert_post(['post_title' => $d[0], 'post_name' => $d[1], 'post_content' => $d[2], 'post_status' => 'publish', 'post_type' => 'page']);
            if ($id && !is_wp_error($id)) update_option($opt, $id);
        }
    }

    /* contesto: pannello WordPress oppure pagina del sito */
    static $fe = false;
    static $errore = '';
    static function url_gestione() { $p = get_option('pdl_pagina_gestione'); return $p ? get_permalink($p) : admin_url('admin.php?page=pdl'); }
    static function u($page, $args = []) {
        $map = ['pdl' => 'dipendenti', 'pdl-presenze' => 'presenze', 'pdl-documenti' => 'documenti', 'pdl-richieste' => 'ferie'];
        return self::link($map[$page] ?? 'dipendenti', $args);
    }
    static function hid($page) { $map = ['pdl-presenze' => 'presenze', 'pdl-documenti' => 'documenti']; return '<input type="hidden" name="v" value="' . esc_attr($map[$page] ?? 'dipendenti') . '">'; }

    /** Cartella privata dei documenti: nome casuale + blocco accesso diretto */
    static function cartella() {
        $nome = get_option('pdl_dir');
        if (!$nome) { $nome = 'pdl-privati-' . wp_generate_password(20, false); update_option('pdl_dir', $nome); }
        $up = wp_upload_dir();
        $dir = trailingslashit($up['basedir']) . $nome;
        if (!is_dir($dir)) wp_mkdir_p($dir);
        if (!file_exists("$dir/.htaccess")) file_put_contents("$dir/.htaccess", "Require all denied\nDeny from all\n");
        if (!file_exists("$dir/index.php")) file_put_contents("$dir/index.php", "<?php // silenzio");
        return $dir;
    }

    /* ---------------- avvio ---------------- */
    static function init() {
        add_shortcode('area_dipendenti', [__CLASS__, 'shortcode']);
        add_shortcode('gestione_dipendenti', '__return_empty_string');
        add_action('template_redirect', [__CLASS__, 'app_template'], 1);
        add_action('template_redirect', [__CLASS__, 'area_template'], 1);
        add_action('wp_ajax_pdl_push_sub', [__CLASS__, 'ajax_push_sub']);
        add_action('wp_ajax_pdl_push_get', [__CLASS__, 'ajax_push_get']);
        add_action('admin_post_pdl_export_bp', [__CLASS__, 'export_bp']);
        add_action('admin_menu', function () {
            add_menu_page('Dipendenti', 'Dipendenti', 'manage_options', 'pdl', function () { echo '<script>location.href=' . wp_json_encode(Presenze_DL::url_gestione()) . '</script>'; }, 'dashicons-groups', 56);
        });
        add_action('wp_head', function () { if (is_page([get_option('pdl_pagina'), get_option('pdl_pagina_gestione')])) echo '<meta name="robots" content="noindex,nofollow">'; });
        add_action('admin_post_pdl_scarica', [__CLASS__, 'scarica']);
        add_action('admin_post_pdl_export', [__CLASS__, 'export_csv']);
        add_action('init', [__CLASS__, 'gestisci_post_frontend']);
        add_action('admin_init', [__CLASS__, 'blocca_admin']);
        add_filter('show_admin_bar', function ($s) { return self::is_dip() ? false : $s; });
        add_filter('wp_authenticate_user', [__CLASS__, 'blocca_disattivati']);
        add_filter('login_redirect', function ($to, $req, $u) {
            return (!is_wp_error($u) && in_array('dipendente', (array)$u->roles)) ? self::url_area() : $to;
        }, 10, 3);
        if (get_option('pdl_ver') !== PDL_VER) add_action('init', [__CLASS__, 'activate']);
        add_filter('pre_set_site_transient_update_plugins', [__CLASS__, 'agg_transient']);
    }
    /** Controlla su GitHub se c'è una versione nuova (cache 1 ora) */
    static function agg_info($forza = false) {
        $i = $forza ? false : get_transient('pdl_agg');
        if ($i === false) {
            $r = wp_remote_get(PDL_AGG . '?t=' . time(), ['timeout' => 8]);
            $i = is_wp_error($r) ? [] : (json_decode(wp_remote_retrieve_body($r), true) ?: []);
            set_transient('pdl_agg', $i, HOUR_IN_SECONDS);
        }
        return (!empty($i['versione']) && !empty($i['zip']) && version_compare($i['versione'], PDL_VER, '>')) ? $i : null;
    }
    static function agg_transient($t) {
        if (!is_object($t)) return $t;
        $i = self::agg_info(); $b = plugin_basename(__FILE__);
        if ($i) $t->response[$b] = (object)['slug' => 'presenze-dl', 'plugin' => $b, 'new_version' => $i['versione'], 'package' => $i['zip'], 'url' => ''];
        return $t;
    }
    static function agg_esegui() {
        $i = self::agg_info(true); if (!$i) return 'Hai già l\'ultima versione (' . PDL_VER . ')';
        require_once ABSPATH . 'wp-admin/includes/file.php'; require_once ABSPATH . 'wp-admin/includes/misc.php'; require_once ABSPATH . 'wp-admin/includes/plugin.php'; require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        WP_Filesystem();
        $up = new Plugin_Upgrader(new Automatic_Upgrader_Skin());
        $ok = $up->install($i['zip'], ['overwrite_package' => true, 'clear_update_cache' => true]);
        if (is_wp_error($ok) || !$ok) return 'ERR Aggiornamento non riuscito' . (is_wp_error($ok) ? ': ' . $ok->get_error_message() : '');
        activate_plugin(plugin_basename(__FILE__)); delete_transient('pdl_agg');
        return 'Aggiornato alla versione ' . $i['versione'];
    }

    static function is_dip($u = null) { $u = $u ?: wp_get_current_user(); return $u && in_array('dipendente', (array)$u->roles); }
    static function url_area() { $p = get_option('pdl_pagina'); return $p ? get_permalink($p) : home_url('/'); }

    static function blocca_admin() {
        if (self::is_dip() && !wp_doing_ajax() && basename($_SERVER['SCRIPT_NAME']) !== 'admin-post.php') {
            wp_safe_redirect(self::url_area()); exit;
        }
    }
    static function blocca_disattivati($u) {
        if (!is_wp_error($u) && in_array('dipendente', (array)$u->roles) && get_user_meta($u->ID, 'pdl_attivo', true) === '0')
            return new WP_Error('pdl_disattivato', 'Account disattivato.');
        return $u;
    }

    /* ---------- aziende ---------- */
    static function aziende() { $a = get_option('pdl_aziende'); if (!is_array($a) || !$a) $a = ['af' => get_bloginfo('name') ?: 'Affari di Famiglia', 'mouse' => 'Mouse srl']; return $a; }
    static function az_corr() { $a = self::aziende(); $c = get_user_meta(get_current_user_id(), 'pdl_azienda_corrente', true); return isset($a[$c]) ? $c : array_key_first($a); }
    static function az_nome($k = null) { $a = self::aziende(); return $a[$k ?? self::az_corr()] ?? reset($a); }
    static function az_di($uid) { $a = self::aziende(); $c = get_user_meta($uid, 'pdl_azienda', true); return isset($a[$c]) ? $c : array_key_first($a); }
    /** Filtro SQL: solo i dipendenti dell'azienda scelta (nella gestione) */
    static function in_az($col = 'utente_id') {
        if (!self::$fe) return '';
        $ids = wp_list_pluck(self::dipendenti(false), 'ID');
        return ' AND ' . $col . ' IN (' . ($ids ? implode(',', array_map('intval', $ids)) : '0') . ')';
    }

    static function dipendenti($solo_attivi = true) {
        $us = get_users(['role' => 'dipendente', 'orderby' => 'display_name']);
        if (self::$fe) { $az = self::az_corr(); $us = array_values(array_filter($us, function ($u) use ($az) { return self::az_di($u->ID) === $az; })); }
        if ($solo_attivi) $us = array_values(array_filter($us, function ($u) { return get_user_meta($u->ID, 'pdl_attivo', true) !== '0'; }));
        usort($us, function ($a, $b) { return strcasecmp($a->last_name . $a->first_name, $b->last_name . $b->first_name); });
        return $us;
    }
    static function nome($u) { return esc_html(trim($u->last_name . ' ' . $u->first_name) ?: $u->display_name); }
    static function data_it($d) { return $d ? esc_html(date_i18n('d/m/Y', strtotime($d))) : ''; }
    static function avviso($m, $tipo = 'success') { echo '<div class="notice notice-' . $tipo . ' is-dismissible"><p>' . esc_html($m) . '</p></div>'; }

    /* ---------------- presenze ---------------- */
    static function mese() {
        $a = isset($_REQUEST['anno']) ? (int)$_REQUEST['anno'] : (int)current_time('Y');
        $m = isset($_REQUEST['mese']) ? (int)$_REQUEST['mese'] : (int)current_time('n');
        return [max(2000, min(2100, $a)), max(1, min(12, $m))];
    }
    static function giorni($a, $m) {
        $out = []; $n = (int)date("t", mktime(0, 0, 0, $m, 1, $a));
        for ($d = 1; $d <= $n; $d++) $out[] = sprintf('%04d-%02d-%02d', $a, $m, $d);
        return $out;
    }
    /* ---------------- documenti ---------------- */
    /** Dal nome del file ricava dipendente, mese, anno e categoria */
    static function indovina($nome, $dip) {
        $n = strtolower(remove_accents($nome));
        $uid = 0;
        foreach ($dip as $u) { $cf = strtolower(get_user_meta($u->ID, 'pdl_codice_fiscale', true)); if ($cf && strpos($n, $cf) !== false) { $uid = $u->ID; break; } }
        if (!$uid) { $trov = [];
            foreach ($dip as $u) { $c = strtolower(remove_accents($u->last_name)); if (strlen($c) > 2 && preg_match('/(^|[^a-z])' . preg_quote($c, '/') . '([^a-z]|$)/', $n)) $trov[] = $u->ID; }
            if (count($trov) === 1) $uid = $trov[0];
            elseif (count($trov) > 1) foreach ($trov as $id) { $nm = strtolower(remove_accents(get_userdata($id)->first_name)); if ($nm && strpos($n, $nm) !== false) { $uid = $id; break; } }
        }
        $cat = '';
        if (preg_match('/tredicesim|13\s*esima|13ma|xiii/', $n)) $cat = 'Tredicesima';
        elseif (preg_match('/quattordicesim|14\s*esima|14ma|xiv/', $n)) $cat = 'Quattordicesima';
        elseif (preg_match('/(^|[^a-z])cu([^a-z]|$)|certificazione unica/', $n)) $cat = 'CU';
        elseif (preg_match('/contratt/', $n)) $cat = 'Contratto';
        elseif (preg_match('/busta|cedolin|lul|paga/', $n)) $cat = 'Busta paga';
        $mese = 0; $anno = 0;
        $abbr = ['gen', 'feb', 'mar', 'apr', 'mag', 'giu', 'lug', 'ago', 'set', 'ott', 'nov', 'dic'];
        for ($i = 12; $i >= 1; $i--) { if (strpos($n, strtolower(self::MESI[$i])) !== false) { $mese = $i; break; } }
        if (!$mese) foreach ($abbr as $i => $ab) if (preg_match('/(^|[^a-z])' . $ab . '([^a-z]|$)/', $n)) { $mese = $i + 1; break; }
        if (preg_match('/(20\d\d)[\s._-]?(0[1-9]|1[0-2])(?!\d)/', $n, $m)) { $anno = (int)$m[1]; $mese = $mese ?: (int)$m[2]; }
        elseif (preg_match('/(?<!\d)(0?[1-9]|1[0-2])[\s._-](20\d\d)/', $n, $m)) { $anno = (int)$m[2]; $mese = $mese ?: (int)$m[1]; }
        elseif (preg_match('/(20\d\d)/', $n, $m)) $anno = (int)$m[1];
        if ($cat === 'Tredicesima' && !$mese) $mese = 12;
        return [$uid, $mese, $anno, $cat];
    }

    static function link_doc($id, $vedi = false) { return wp_nonce_url(admin_url('admin-post.php?action=pdl_scarica&id=' . (int)$id . ($vedi ? '&vedi=1' : '')), 'pdl_scarica_' . (int)$id); }

    static function scarica() {
        global $wpdb;
        $id = (int)($_GET['id'] ?? 0);
        if (!is_user_logged_in() || !wp_verify_nonce($_GET['_wpnonce'] ?? '', 'pdl_scarica_' . $id)) wp_die('Non autorizzato', 403);
        $d = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . self::t('documenti') . " WHERE id=%d", $id));
        $admin = current_user_can('manage_options');
        if (!$d || (!$admin && ((int)$d->utente_id !== get_current_user_id() || !$d->condiviso))) wp_die('Documento non trovato', 404);
        $path = self::cartella() . '/' . basename($d->file);
        if (!is_file($path)) wp_die('File mancante', 404);
        if (!$admin && !$d->scaricato) $wpdb->update(self::t('documenti'), ['scaricato' => current_time('mysql')], ['id' => $id]);
        nocache_headers();
        header('Content-Type: ' . (wp_check_filetype($path)['type'] ?: 'application/octet-stream'));
        $inline = !empty($_GET['vedi']);
        header('Content-Disposition: ' . ($inline ? 'inline' : 'attachment') . '; filename="' . str_replace('"', '', $d->nome_originale) . '"');
        header('Content-Length: ' . filesize($path));
        header('X-Content-Type-Options: nosniff');
        readfile($path); exit;
    }

    /* ---------------- ferie e permessi ---------------- */
    /* =====================================================================
       APPLICAZIONE DI GESTIONE (pagina a schermo intero sul sito)
       ===================================================================== */
    const VISTE = ['dipendenti' => 'Dipendenti', 'documenti' => 'Documenti', 'buste' => 'Buste paga', 'presenze' => 'Presenze'];
    const CAT_DOC = ['Contratto', 'CU', 'Comunicazione', 'Documento di identità', 'Certificato medico', 'Attestato / corso', 'Altro'];

    static function link($v, $args = []) { return add_query_arg(array_merge(['v' => $v], $args), self::url_gestione()); }
    static function vai($v, $args = [], $ok = '') { if ($ok) $args['ok'] = rawurlencode($ok); wp_safe_redirect(self::link($v, $args)); exit; }
    static function iniziali($u) { return esc_html(strtoupper(mb_substr($u->first_name ?: $u->display_name, 0, 1) . mb_substr($u->last_name, 0, 1))); }
    static function m($u, $k) { return get_user_meta($u->ID, 'pdl_' . $k, true); }
    static function euro($n) { if ($n === null || $n === '') return ''; $p = explode(',', number_format((float)$n, 2, ',', '.')); return '€ ' . $p[0] . ',<sup>' . $p[1] . '</sup>'; }
    static function nome_mese($m) { return [13 => '13esima', 14 => '14esima'][$m] ?? (self::MESI[$m] ?? ''); }
    static function data_lunga($d) { return $d ? esc_html(date_i18n('j F Y', strtotime($d))) : ''; }
    static function nonce() { return wp_nonce_field('pdl_app', '_pdlnonce', true, false); }

    /** La pagina "Gestione dipendenti" diventa un'applicazione a schermo intero */
    static function app_template() {
        $p = (int)get_option('pdl_pagina_gestione');
        if (!$p || !is_page($p)) return;
        if (!defined('DONOTCACHEPAGE')) define('DONOTCACHEPAGE', true);
        if (isset($_GET['pdl_manifest'])) self::manifest('Gestione dipendenti · ' . get_bloginfo('name'), 'Gestione DL', self::url_gestione());
        if (isset($_GET['pdl_sw'])) self::sw();
        nocache_headers();
        if (is_user_logged_in() && current_user_can('manage_options') && $_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['pdl_act'])) {
            if (!wp_verify_nonce($_POST['_pdlnonce'] ?? '', 'pdl_app')) wp_die('Sessione scaduta, ricarica la pagina.');
            self::azione(sanitize_key($_POST['pdl_act']));
        }
        self::$fe = true;
        $v = sanitize_key($_GET['v'] ?? 'dipendenti');
        if ($v === 'ferie') { wp_safe_redirect(self::link('presenze', ['tab' => 'richieste'])); exit; }
        if ($v === 'dipendente') $attiva = 'dipendenti'; else $attiva = isset(self::VISTE[$v]) ? $v : 'dipendenti';
        ob_start();
        if (!is_user_logged_in()) self::app_login();
        elseif (!current_user_can('manage_options')) echo '<div class="app-vuoto"><h2>Pagina riservata</h2><p>Questa pagina è solo per l\'amministratore.</p><p><a class="btn" href="' . esc_url(self::url_area()) . '">Vai all\'area dipendenti</a></p></div>';
        else {
            switch ($v) {
                case 'dipendente': self::v_dipendente(); break;
                case 'documenti': self::v_documenti(); break;
                case 'buste': self::v_buste(); break;
                case 'presenze': self::v_presenze(); break;
                default: self::v_dipendenti();
            }
        }
        $corpo = ob_get_clean();
        while (ob_get_level() > 0) @ob_end_clean();
        self::app_shell($corpo, $attiva);
        exit;
    }

    static function app_login() {
        echo '<div class="app-login"><h2>Gestione dipendenti</h2><p class="mut">Accedi con il tuo account del sito.</p>';
        wp_login_form(['redirect' => self::url_gestione(), 'label_username' => 'Nome utente o email', 'label_password' => 'Password', 'label_remember' => 'Ricordami', 'label_log_in' => 'Entra']);
        echo '</div>';
    }

    static function app_shell($corpo, $attiva) {
        global $wpdb;
        $admin = is_user_logged_in() && current_user_can('manage_options');
        $n_ferie = $admin ? (int)$wpdb->get_var("SELECT COUNT(DISTINCT gruppo) FROM " . self::t('giust') . " WHERE stato='In attesa'" . self::in_az()) : 0;
        $me = wp_get_current_user();
        $icone = [
            'dipendenti' => '<path d="M16 11a4 4 0 1 0-4-4 4 4 0 0 0 4 4zM8 12a3 3 0 1 0-3-3 3 3 0 0 0 3 3zm8 1c-2.7 0-8 1.3-8 4v3h16v-3c0-2.7-5.3-4-8-4zM8 14c-.3 0-.7 0-1.1.1C8.2 15 9 16 9 17v3H1v-2.5C1 15.3 5.3 14 8 14z"/>',
            'documenti' => '<path d="M10 4H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-8z"/>',
            'buste' => '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8zm-1 7V3.5L18.5 9zM8 13h8v2H8zm0 4h8v2H8z"/>',
            'presenze' => '<path d="M19 4h-1V2h-2v2H8V2H6v2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zm0 16H5V9h14zM7 11h5v5H7z"/>',
            'ferie' => '<path d="M21 16v-2l-8-5V3.5a1.5 1.5 0 0 0-3 0V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5z"/>',
        ];
        header('Content-Type: text/html; charset=utf-8');
        echo '<!doctype html><html lang="it"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>Gestione dipendenti · ' . esc_html(get_bloginfo('name')) . '</title><link rel="manifest" href="' . esc_url(add_query_arg(['pdl_manifest' => 1, 'v' => PDL_VER], self::url_gestione())) . '"><meta name="theme-color" content="#1559c9"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-title" content="Gestione DL"><link rel="icon" href="' . esc_url(self::icona_app(32)) . '"><link rel="apple-touch-icon" href="' . esc_url(self::icona_app(180)) . '">';
        echo '<link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">';
        echo '<style>' . self::app_css() . '</style></head><body>';
        echo '<header class="app-top"><button class="app-burger" onclick="document.body.classList.toggle(\'menu-on\')" aria-label="Menu"><svg viewBox="0 0 24 24"><path d="M3 6h18v2H3zm0 5h18v2H3zm0 5h18v2H3z"/></svg></button><a class="app-logo" href="' . esc_url(self::link('dipendenti')) . '"><img src="' . esc_url(self::icona_app(192)) . '" alt="DL" style="width:34px;height:34px;border-radius:7px;background:#fff"><span class="app-tit">Gestione dipendenti</span></a><div class="app-sp"></div>';
        if ($admin && ($ai = self::agg_info())) echo '<form method="post" style="margin:0 8px 0 0">' . self::nonce() . '<input type="hidden" name="pdl_act" value="aggiorna"><button class="app-az" style="background:#16a34a;display:inline-block" onclick="this.textContent=\'Aggiornamento…\'">⟳ Aggiorna a ' . esc_html($ai['versione']) . '</button></form>';
        if ($admin) { echo '<div class="pop az-sw"><button class="app-az" data-menu>' . esc_html(self::az_nome()) . ' ▾</button><div class="pop-menu" style="right:0;color:var(--txt)">';
            foreach (self::aziende() as $k => $n) echo '<form method="post">' . self::nonce() . '<input type="hidden" name="pdl_act" value="az_cambia"><input type="hidden" name="az" value="' . esc_attr($k) . '"><input type="hidden" name="torna" value="' . esc_attr(remove_query_arg(['ok', 'err', 'id', 'det', 'g', 'du', 'bu', 'imp', 'nuovo'])) . '"><button>' . ($k === self::az_corr() ? '✓ ' : '<span style="width:14px;display:inline-block"></span>') . esc_html($n) . '</button></form>';
            echo '<a href="#" data-apri="dr-aziende" style="border-top:1px solid var(--line)">⚙ Gestisci aziende</a><form method="post">' . self::nonce() . '<input type="hidden" name="pdl_act" value="agg_controlla"><button>⟳ Controlla aggiornamenti <small style="color:#888">v' . PDL_VER . '</small></button></form></div></div>'; }
        if ($admin) echo '<span style="display:none">' . esc_html(get_bloginfo('name')) . '</span><div class="app-user"><span class="av">' . self::iniziali($me) . '</span><div><small>Amministratore</small><b>' . esc_html($me->first_name ?: $me->display_name) . '</b></div><a href="' . esc_url(wp_logout_url(self::url_gestione())) . '" title="Esci"><svg viewBox="0 0 24 24"><path d="M10 17l1.4-1.4L8.8 13H20v-2H8.8l2.6-2.6L10 7l-5 5zM4 5h8V3H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h8v-2H4z"/></svg></a></div>';
        echo '</header><div class="app-body">';
        if ($admin) {
            echo '<nav class="app-nav"><div class="lab">Gestione</div>';
            foreach (['dipendenti', 'documenti', 'buste'] as $k) echo '<a class="' . ($attiva === $k ? 'on' : '') . '" href="' . esc_url(self::link($k)) . '"><svg viewBox="0 0 24 24">' . $icone[$k] . '</svg>' . self::VISTE[$k] . '</a>';
            echo '<div class="lab">Presenze</div>';
            $tb = sanitize_key($_GET['tab'] ?? '');
            echo '<a class="' . ($attiva === 'presenze' && !$tb ? 'on' : '') . '" href="' . esc_url(self::link('presenze')) . '"><svg viewBox="0 0 24 24">' . $icone['presenze'] . '</svg>Presenze</a>';
            echo '<a class="' . ($attiva === 'presenze' && $tb === 'richieste' ? 'on' : '') . '" href="' . esc_url(self::link('presenze', ['tab' => 'richieste'])) . '"><svg viewBox="0 0 24 24">' . $icone['ferie'] . '</svg>Richieste' . ($n_ferie ? '<i class="bolla">' . $n_ferie . '</i>' : '') . '</a>';
            echo '<a class="' . ($attiva === 'presenze' && $tb === 'bilancio' ? 'on' : '') . '" href="' . esc_url(self::link('presenze', ['tab' => 'bilancio'])) . '"><svg viewBox="0 0 24 24"><path d="M5 9.2h3V19H5zM10.6 5h2.8v14h-2.8zm5.6 8H19v6h-2.8z"/></svg>Bilancio ore</a>';
            echo '<div class="lab">Sito</div><a href="' . esc_url(self::url_area()) . '" target="_blank"><svg viewBox="0 0 24 24"><path d="M14 3v2h3.6l-9.8 9.8 1.4 1.4L19 6.4V10h2V3zm5 16H5V5h7V3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7h-2z"/></svg>Area dipendenti</a>';
            echo '<a href="' . esc_url(home_url('/')) . '"><svg viewBox="0 0 24 24"><path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/></svg>Torna al negozio</a></nav>';
        }
        echo '<main class="app-main">';
        if (!empty($_GET['ok'])) echo '<div class="toast ok">' . esc_html(wp_unslash(rawurldecode($_GET['ok']))) . '</div>';
        if (!empty($_GET['err'])) echo '<div class="toast err">' . esc_html(wp_unslash(rawurldecode($_GET['err']))) . '</div>';
        echo $corpo . '</main></div>';
        if ($admin) echo self::push_js(self::url_gestione());
        if ($admin) { echo '<div class="drawer" id="dr-aziende"><div class="ombra" data-chiudi></div><form class="pan" method="post">' . self::nonce() . '<input type="hidden" name="pdl_act" value="az_salva"><div class="ph"><h2>Aziende</h2><a href="#" data-chiudi>×</a></div><div class="pc"><p class="mut">Ogni dipendente appartiene a un\'azienda. In alto scegli quale azienda stai guardando.</p>';
            foreach (self::aziende() as $k => $n) echo '<div class="campo"><label>Nome azienda</label><input class="inp" name="az[' . esc_attr($k) . ']" value="' . esc_attr($n) . '"></div>';
            echo '<div class="campo"><label>Aggiungi un\'altra azienda</label><input class="inp" name="az_nuova" placeholder="es. Nuova ditta srl"></div></div><div class="pf"><a class="btn" href="#" data-chiudi>Annulla</a><button class="btn blu">Salva</button></div></form></div>'; }
        echo '<script type="speculationrules">{"prefetch":[{"where":{"and":[{"href_matches":"' . esc_js(wp_make_link_relative(self::url_gestione())) . '*"},{"not":{"href_matches":"*wp-admin*"}},{"not":{"href_matches":"*logout*"}}]},"eagerness":"moderate"}]}</script>';
        echo '<div id="carica-bar"></div><style>#carica-bar{position:fixed;top:0;left:0;height:3px;width:0;background:#7fb2ff;z-index:999;transition:width 8s cubic-bezier(.1,.7,.1,1)}body.va #carica-bar{width:85%}</style>';
        echo '<script>window.addEventListener("pageshow",function(){document.body.classList.remove("va");});document.addEventListener("click",function(e){var a=e.target.closest("a[href]");if(a&&!a.target&&a.href.indexOf("#")<0&&a.href.indexOf("wp-admin")<0&&!e.ctrlKey&&!e.metaKey)document.body.classList.add("va");});document.addEventListener("submit",function(){document.body.classList.add("va");});</script>';
        echo '<script>document.querySelectorAll(".toast").forEach(function(t){setTimeout(function(){t.classList.add("via")},4000)});
document.addEventListener("click",function(e){var d=e.target.closest("[data-apri]");if(d){e.preventDefault();var x=document.getElementById(d.dataset.apri);if(x)x.classList.add("on");}
var c=e.target.closest("[data-chiudi]");if(c){e.preventDefault();c.closest(".drawer,.modale").classList.remove("on");}
var m=e.target.closest("[data-menu]");document.querySelectorAll(".pop-menu.on").forEach(function(p){if(!m||p!==m.nextElementSibling)p.classList.remove("on");});if(m){e.preventDefault();m.nextElementSibling.classList.toggle("on");}});
document.querySelectorAll("[data-cerca]").forEach(function(i){i.addEventListener("input",function(){var q=i.value.toLowerCase();document.querySelectorAll(i.dataset.cerca).forEach(function(r){r.style.display=r.textContent.toLowerCase().indexOf(q)>-1?"":"none";});});});
document.querySelectorAll(".dropzone").forEach(function(z){var inp=z.querySelector("input[type=file]"),l=z.querySelector(".dz-lista");
function mostra(){if(!l)return;l.innerHTML="";Array.prototype.forEach.call(inp.files,function(f){var d=document.createElement("div");d.textContent="📄 "+f.name;l.appendChild(d);});}
z.addEventListener("dragover",function(e){e.preventDefault();z.classList.add("sopra");});z.addEventListener("dragleave",function(){z.classList.remove("sopra");});
z.addEventListener("drop",function(e){e.preventDefault();z.classList.remove("sopra");inp.files=e.dataTransfer.files;inp.dispatchEvent(new Event("change"));});inp.addEventListener("change",mostra);});
</script></body></html>';
    }

    static function app_css() {
        return ':root{--blu:#1559c9;--blu2:#0d47a8;--blu-ch:#e8f0fd;--verde:#12805c;--verde2:#0e6b4c;--verde-ch:#e3f6ec;--rosso:#c9302c;--bg:#f3f5f9;--line:#e3e7ee;--txt:#1f2a37;--mut:#6b7684;--rad:6px}
*{box-sizing:border-box}html,body{margin:0;height:100%}body{font-family:Inter,system-ui,-apple-system,"Segoe UI",Arial,sans-serif;font-size:14px;color:var(--txt);background:var(--bg)}
a{color:var(--blu);text-decoration:none}svg{width:18px;height:18px;fill:currentColor;flex:none}
.app-top{position:fixed;top:0;left:0;right:0;height:52px;background:var(--blu);color:#fff;display:flex;align-items:center;gap:14px;padding:0 16px;z-index:50}
.app-logo{display:flex;align-items:center;gap:10px;color:#fff;font-weight:600;font-size:17px}.app-logo span{background:#fff;color:var(--blu);border-radius:6px;padding:2px 6px;font-weight:800;font-size:14px}
.app-sp{flex:1}.app-az{background:rgba(255,255,255,.15);padding:7px 12px;border-radius:4px;font-size:12px;font-weight:600;text-transform:uppercase;color:#fff;border:0;cursor:pointer;font-family:inherit}.app-az:hover{background:rgba(255,255,255,.28)}.az-sw .pop-menu{text-transform:none}
.app-user{display:flex;align-items:center;gap:8px;border-left:2px solid rgba(255,255,255,.3);padding-left:14px}.app-user small{display:block;font-size:11px;opacity:.8}.app-user b{font-size:12px}.app-user a{color:#fff;display:flex;padding:6px}
.av{width:34px;height:34px;border-radius:50%;background:#dbe7fb;color:var(--blu);display:inline-flex;align-items:center;justify-content:center;font-weight:700;font-size:12px;flex:none}
.app-top .av{background:#fff}.app-burger{display:none;background:none;border:0;color:#fff;padding:4px;cursor:pointer}
.app-body{display:flex;padding-top:52px;min-height:100%}
.app-nav{position:fixed;top:52px;bottom:0;left:0;width:220px;background:#fff;border-right:1px solid var(--line);padding:10px 0;overflow-y:auto;z-index:40}
.app-nav .lab{font-size:11px;font-weight:700;color:var(--txt);letter-spacing:.04em;padding:14px 16px 6px;text-transform:uppercase}
.app-nav a{display:flex;align-items:center;gap:12px;padding:9px 18px;color:#3d4753;font-size:14px}.app-nav a svg{color:#7a8592}
.app-nav a:hover{background:#f5f7fb}.app-nav a.on{background:var(--blu-ch);color:var(--blu);font-weight:600}.app-nav a.on svg{color:var(--blu)}
.bolla{margin-left:auto;background:var(--rosso);color:#fff;font-style:normal;font-size:11px;border-radius:10px;padding:0 7px;font-weight:600}
.app-main{flex:1;margin-left:220px;min-width:0}
.pg-head{background:#fff;border-bottom:1px solid var(--line);padding:14px 24px;display:flex;align-items:center;gap:12px;flex-wrap:wrap;min-height:66px;position:sticky;top:52px;z-index:30}
.pg-head h1{font-size:22px;font-weight:600;margin:0;display:flex;align-items:center;gap:10px}.pg-head h1 a{color:var(--blu);text-decoration:underline}.pg-head .sep{color:#9aa4b0;font-weight:400}
.pg-head .az{margin-left:auto;display:flex;gap:8px;flex-wrap:wrap}
.pg-tabs{display:flex;gap:22px;padding:0 24px;background:#fff;border-bottom:1px solid var(--line);overflow-x:auto}.pg-tabs a{padding:10px 0;color:#4a5562;border-bottom:2px solid transparent;white-space:nowrap}.pg-tabs a.on{color:var(--blu);border-color:var(--blu);font-weight:600}
.pg{padding:24px;max-width:1120px;margin:0 auto}
.btn{display:inline-flex;align-items:center;gap:6px;height:34px;padding:0 14px;border-radius:4px;border:1px solid var(--line);background:#fff;color:var(--txt);font:inherit;font-weight:500;cursor:pointer;white-space:nowrap}
.btn:hover{background:#f6f8fb}.btn svg{width:16px;height:16px}.btn.verde{background:var(--verde);border-color:var(--verde);color:#fff}.btn.verde:hover{background:var(--verde2)}
.btn.blu{background:var(--blu);border-color:var(--blu);color:#fff}.btn.blu:hover{background:var(--blu2)}.btn.rosso{color:var(--rosso)}.btn.pic{height:28px;padding:0 9px;font-size:13px}
.seg{display:inline-flex;background:#e2e9f5;border-radius:6px;padding:3px}.seg a{padding:6px 14px;border-radius:5px;color:var(--blu);font-size:13px}.seg a.on{background:#fff;font-weight:600;box-shadow:0 1px 2px rgba(0,0,0,.08)}
.barra{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin:18px 0 14px}.barra .sp{flex:1}
.inp,select.inp,textarea.inp{height:38px;border:1px solid #d7dde6;border-radius:4px;padding:0 10px;font:inherit;background:#fff;color:var(--txt);width:100%}textarea.inp{height:auto;min-height:90px;padding:8px 10px}
.inp:focus{outline:none;border-color:var(--blu);box-shadow:0 0 0 3px rgba(21,89,201,.12)}
.cerca{position:relative;width:240px}.cerca svg{position:absolute;left:9px;top:10px;width:16px;height:16px;color:#6b7684}.cerca .inp{padding-left:32px}
.tab{width:100%;border-collapse:collapse;background:transparent}.tab th{font-weight:400;color:var(--mut);text-align:left;padding:10px 8px;border-bottom:1px solid var(--line);font-size:13px;white-space:nowrap}
.tab td{padding:12px 8px;border-bottom:1px solid var(--line);vertical-align:middle}.tab tr:hover td{background:#fff}
.chi{display:flex;align-items:center;gap:10px}.chi .nm{color:var(--blu);font-weight:500}.chi small{display:flex;align-items:center;gap:5px;color:var(--mut);font-size:12px;margin-top:2px}.chi small svg{width:13px;height:13px}
.stato{display:inline-block;padding:3px 10px;border-radius:3px;font-size:12px;font-weight:500}.stato.ok{background:var(--verde-ch);color:var(--verde)}.stato.no{background:#fde8e7;color:var(--rosso)}.stato.att{background:#fff4dc;color:#a15c00}.stato.grigio{background:#eef0f3;color:#5b6573}
.info{background:#fff;border:1px solid #c9d8f2;border-radius:4px;padding:14px 18px;display:flex;align-items:center;gap:14px;color:#1d3c73;margin-bottom:6px}.info svg{color:var(--blu)}
.card{background:#fff;border-radius:6px;box-shadow:0 1px 3px rgba(16,24,40,.08);padding:20px;margin-bottom:18px}.card h3{margin:0 0 16px;font-size:16px;color:var(--blu);font-weight:600}
.griglia{display:grid;grid-template-columns:repeat(3,1fr);gap:14px 18px}.griglia .larga{grid-column:1/-1}.griglia .due{grid-column:span 2}
.campo label{display:block;font-size:13px;color:#4a5562;margin-bottom:5px}.campo label i{color:var(--rosso);font-style:normal}
.vuoto,.app-vuoto{text-align:center;padding:60px 20px;color:var(--mut)}.vuoto .ill,.app-vuoto .ill{width:120px;height:90px;margin:0 auto 14px;border-radius:50%;background:#e9edf3;display:flex;align-items:center;justify-content:center}.vuoto .ill svg{width:46px;height:46px;color:#9fb0c7}.vuoto h3{color:var(--txt);margin:0 0 6px;font-size:17px;font-weight:500}
.toast{position:fixed;right:20px;top:66px;z-index:90;padding:12px 18px;border-radius:6px;background:var(--verde);color:#fff;box-shadow:0 6px 20px rgba(0,0,0,.15);transition:opacity .4s}.toast.err{background:var(--rosso)}.toast.via{opacity:0;pointer-events:none}
.drawer{position:fixed;inset:0;z-index:80;display:none}.drawer.on{display:block}.drawer .ombra{position:absolute;inset:0;background:rgba(15,23,42,.35)}
.drawer .pan{position:absolute;top:0;right:0;bottom:0;width:440px;max-width:100%;background:#fff;display:flex;flex-direction:column;box-shadow:-8px 0 30px rgba(0,0,0,.15)}
.drawer.largo .pan{width:min(1180px,100%)}.drawer.pieno .pan{width:100%;left:0}.drawer.pieno .split .lato{width:380px}.drawer .ph{display:flex;align-items:center;justify-content:space-between;padding:16px 20px;border-bottom:1px solid var(--line)}.drawer .ph h2{margin:0;font-size:18px;font-weight:600}.drawer .ph a{color:var(--txt);font-size:22px;line-height:1}
.drawer .pc{flex:1;overflow-y:auto;padding:18px 20px}.drawer .pc .campo{margin-bottom:14px}.drawer .pf{display:flex;justify-content:space-between;gap:10px;padding:14px 20px;border-top:1px solid var(--line)}.drawer .pf .btn.blu,.drawer .pf .btn.verde{flex:1;justify-content:center;height:40px}
.split{display:flex;height:100%}.split .prev{flex:1;background:#525659;min-width:0}.split .prev iframe{width:100%;height:100%;border:0}.split .lato{width:420px;display:flex;flex-direction:column;border-left:1px solid var(--line)}
.dropzone{border:1px dashed #b9c6d8;border-radius:6px;background:#f7f9fc;padding:22px;text-align:center;cursor:pointer;position:relative;display:block}.dropzone.sopra{border-color:var(--blu);background:var(--blu-ch)}
.dropzone input{position:absolute;inset:0;opacity:0;cursor:pointer}.dropzone .t{font-size:16px;color:#3d4753;margin:6px 0}.dropzone u{color:var(--blu);font-weight:600}.dz-lista{text-align:left;font-size:13px;margin-top:8px;color:#3d4753}.dz-lista div{padding:3px 0}
.chk{display:flex;align-items:center;gap:8px;font-size:14px}.chk input{width:16px;height:16px;accent-color:var(--blu)}
.pop{position:relative;display:inline-block}.pop-menu{position:absolute;right:0;top:100%;margin-top:4px;background:#fff;border:1px solid var(--line);border-radius:6px;box-shadow:0 8px 24px rgba(0,0,0,.12);min-width:260px;z-index:60;display:none;padding:4px 0}.pop-menu.on{display:block}
.pop-menu a,.pop-menu button{display:flex;align-items:center;gap:10px;width:100%;padding:10px 14px;background:none;border:0;font:inherit;color:var(--txt);text-align:left;cursor:pointer}.pop-menu a:hover,.pop-menu button:hover{background:#f5f7fb}.pop-menu .ros{color:var(--rosso)}
.mesi{background:#fff;border-radius:6px;box-shadow:0 1px 3px rgba(16,24,40,.08);display:grid;grid-template-columns:44px repeat(14,minmax(70px,1fr));overflow-x:auto;margin-bottom:18px}
.mesi .ic{display:flex;align-items:flex-end;justify-content:center;padding-bottom:30px;color:var(--blu)}
.mesi a{display:flex;flex-direction:column;justify-content:space-between;min-height:104px;color:var(--txt);border-bottom:2px solid transparent;position:relative;padding-bottom:6px}
.mesi a .tt{text-align:center;padding:10px 4px 0;color:#4a5562;font-size:14px;white-space:nowrap}.mesi a.on{border-color:var(--blu)}.mesi a.on .tt{color:var(--blu);font-weight:700}
.mesi a .bar{position:absolute;left:0;right:0;bottom:0;background:var(--verde-ch);z-index:0}.mesi a .dd{position:relative;z-index:1;padding:0 6px}.mesi a small{display:block;font-size:12px;color:#4a5562}.mesi a b{font-size:14px;color:var(--verde);font-weight:600;white-space:nowrap}.mesi a b sup{font-size:9px}
.anno{display:inline-flex;align-items:center;gap:6px;font-size:20px;color:var(--blu);font-weight:500}.anno a{width:30px;height:30px;border:1px solid var(--line);border-radius:4px;display:inline-flex;align-items:center;justify-content:center;color:var(--txt)}
.ric td{padding:6px 6px}.ric .inp{height:32px;font-size:13px;padding:0 6px}.ric .fn{font-size:12px;color:var(--mut);max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.ric .ok td:first-child{border-left:3px solid var(--verde)}.ric .ko td:first-child{border-left:3px solid #e8a400}
.app-login{max-width:400px;margin:60px auto;background:#fff;padding:28px;border-radius:8px;box-shadow:0 2px 10px rgba(0,0,0,.08)}.app-login h2{margin:0 0 4px}.app-login p.mut{color:var(--mut);margin:0 0 16px}
.app-login input[type=text],.app-login input[type=password]{width:100%;height:40px;border:1px solid #d7dde6;border-radius:4px;padding:0 10px;font:inherit}.app-login .button{width:100%;height:42px;background:var(--blu);color:#fff;border:0;border-radius:4px;font:inherit;font-weight:600;cursor:pointer}
.mut{color:var(--mut)}.notice{padding:12px 16px;border-radius:6px;background:var(--verde-ch);color:var(--verde);margin:0 0 14px}.notice p{margin:0}.notice-error{background:#fde8e7;color:var(--rosso)}
.wrap h1{font-size:20px;margin:0 0 14px}.widefat{width:100%;border-collapse:collapse;background:#fff;border-radius:6px;overflow:hidden;box-shadow:0 1px 3px rgba(16,24,40,.08)}.widefat th,.widefat td{padding:10px;border-bottom:1px solid var(--line);text-align:left}.widefat thead th{color:var(--mut);font-weight:500;font-size:13px}
.wrap input:not([type=checkbox]),.wrap select{height:34px;border:1px solid #d7dde6;border-radius:4px;padding:0 8px;font:inherit}.wrap .button{display:inline-flex;align-items:center;height:34px;padding:0 14px;border-radius:4px;border:1px solid var(--line);background:#fff;font:inherit;cursor:pointer;color:var(--txt)}.wrap .button-primary{background:var(--blu);border-color:var(--blu);color:#fff}
.wrap .description{color:var(--mut)}table.pg{margin:0}.pg-scroll{background:#fff}
@media(max-width:900px){.app-nav{transform:translateX(-100%);transition:transform .2s}body.menu-on .app-nav{transform:none;box-shadow:4px 0 20px rgba(0,0,0,.15)}.app-main{margin-left:0}.app-burger{display:flex}.app-user div{display:none}.app-az{display:inline-block;padding:8px 10px;font-size:12px;max-width:42vw;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.az-sw .pop-menu{right:0;min-width:220px}
.griglia{grid-template-columns:1fr}.griglia .due{grid-column:auto}.pg{padding:16px}.pg-head{padding:12px 16px}.split{flex-direction:column}.split .prev{min-height:50vh}.split .lato{width:100%}.cerca{width:100%}.tab .nasc{display:none}}@media(max-width:600px){.app-tit{display:none}}';
    }

    /* ---------------- azioni (POST) ---------------- */
    static function azione($a) {
        global $wpdb;
        $p = wp_unslash($_POST);
        switch ($a) {
            case 'dip_salva':
                $id = (int)($p['id'] ?? 0);
                $r = self::salva_dipendente($id);
                if (is_wp_error($r)) self::vai($id ? 'dipendente' : 'dipendenti', $id ? ['id' => $id, 'err' => rawurlencode($r->get_error_message())] : ['err' => rawurlencode($r->get_error_message())]);
                self::vai('dipendente', ['id' => $r, 't' => sanitize_key($p['scheda'] ?? 'riepilogo') === 'nuovo' ? 'riepilogo' : sanitize_key($p['scheda'] ?? 'riepilogo')], 'Dati salvati');
            case 'dip_stato':
                $id = (int)$p['id']; $u = get_userdata($id);
                if ($u && self::is_dip($u)) { $on = $p['stato'] === '1'; update_user_meta($id, 'pdl_attivo', $on ? '1' : '0'); if (!$on) WP_Session_Tokens::get_instance($id)->destroy_all(); }
                self::vai('dipendente', ['id' => $id, 't' => 'accesso'], $p['stato'] === '1' ? 'Dipendente riattivato' : 'Dipendente disattivato');
            case 'dip_importa':
                $k = 'pdl_imp_' . strtolower(wp_generate_password(10, false));
                set_transient($k, self::importa(), 600);
                self::vai('dipendenti', ['imp' => $k]);
            case 'doc_carica':
                $n = self::salva_file_doc($p);
                if (self::$errore) self::vai('documenti', ['err' => rawurlencode("$n caricati, errore: " . self::$errore)]);
                self::vai('documenti', [], $n === 1 ? 'Documento caricato' : "$n documenti caricati");
            case 'doc_elimina':
            case 'bp_elimina':
                $d = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . self::t('documenti') . " WHERE id=%d", (int)$p['id']));
                if ($d) { @unlink(self::cartella() . '/' . $d->file); $wpdb->delete(self::t('documenti'), ['id' => $d->id]); }
                $torna = $p['torna'] ?? '';
                if ($torna) { wp_safe_redirect(add_query_arg('ok', rawurlencode('Eliminato'), esc_url_raw($torna))); exit; }
                self::vai($a === 'bp_elimina' ? 'buste' : 'documenti', [], 'Eliminato');
            case 'docreq_crea':
                $dest = $p['utente'] === 'tutti' ? wp_list_pluck(self::dipendenti(), 'ID') : [(int)$p['utente']];
                foreach ($dest as $uid) $wpdb->insert(self::t('richieste_doc'), ['utente_id' => $uid, 'titolo' => sanitize_text_field($p['titolo']), 'nota' => sanitize_textarea_field($p['nota'] ?? ''),
                    'categoria' => sanitize_text_field($p['categoria'] ?? 'Altro'), 'scadenza' => self::d($p['scadenza'] ?? ''), 'stato' => 'In attesa', 'creata' => current_time('mysql')]);
                foreach ($dest as $uid) self::notifica($uid, 'Ti è stato chiesto un documento', sanitize_text_field($p['titolo']) . (self::d($p['scadenza'] ?? '') ? ' · entro il ' . date_i18n('j F', strtotime($p['scadenza'])) : ''), add_query_arg('sez', 'documenti', self::url_area()));
                self::vai('documenti', ['tab' => 'attesa'], 'Richiesta inviata');
            case 'docreq_annulla':
                $wpdb->delete(self::t('richieste_doc'), ['id' => (int)$p['id'], 'stato' => 'In attesa']);
                self::vai('documenti', ['tab' => 'attesa'], 'Richiesta annullata');
            case 'bp_carica':
                $n = self::salva_buste($p);
                if (self::$errore) self::vai('buste', ['anno' => (int)($p['anno_vista'] ?? current_time('Y')), 'err' => rawurlencode("$n caricate, errore: " . self::$errore)]);
                self::vai('buste', ['anno' => (int)($p['anno_vista'] ?? current_time('Y'))], $n === 1 ? '1 busta paga caricata' : "$n buste paga caricate");
            case 'bp_aggiorna':
                $id = (int)$p['id'];
                $mese = (int)$p['mese']; $anno = (int)$p['anno'];
                $wpdb->update(self::t('documenti'), ['utente_id' => (int)$p['utente'], 'mese' => $mese, 'anno' => $anno, 'netto' => self::num($p['netto']), 'emissione' => self::d($p['emissione']),
                    'note' => sanitize_textarea_field($p['note']), 'categoria' => self::cat_busta($mese), 'titolo' => self::titolo_busta((int)$p['utente'], $mese, $anno)], ['id' => $id]);
                self::vai('buste', ['anno' => $anno, 'mese' => $mese, 'det' => $id], 'Dati aggiornati');
            case 'az_cambia':
                if (isset(self::aziende()[$p['az']])) update_user_meta(get_current_user_id(), 'pdl_azienda_corrente', $p['az']);
                $t = esc_url_raw($p['torna'] ?? ''); wp_safe_redirect(add_query_arg('ok', rawurlencode('Azienda: ' . self::az_nome($p['az'])), $t ?: self::url_gestione())); exit;
            case 'az_salva':
                $az = self::aziende();
                foreach ((array)($p['az'] ?? []) as $k => $n) if (isset($az[$k]) && trim($n) !== '') $az[$k] = sanitize_text_field($n);
                if (!empty($p['az_nuova'])) { $k = sanitize_key(remove_accents($p['az_nuova'])) ?: 'az' . count($az); while (isset($az[$k])) $k .= '2'; $az[$k] = sanitize_text_field($p['az_nuova']); }
                update_option('pdl_aziende', $az);
                self::vai('dipendenti', [], 'Aziende salvate');
            case 'aggiorna':
                $m = self::agg_esegui();
                if (strpos($m, 'ERR ') === 0) { wp_safe_redirect(add_query_arg('err', rawurlencode(substr($m, 4)), self::url_gestione())); exit; }
                self::vai('dipendenti', [], $m);
            case 'agg_controlla':
                self::agg_info(true); self::vai('dipendenti', [], self::agg_info() ? 'C\'è un aggiornamento disponibile' : 'Hai già l\'ultima versione (' . PDL_VER . ')');
            default:
                self::azione_pres($a, $p);
        }
    }

    static function d($s) { $s = trim((string)$s); return preg_match('/^\d{4}-\d{2}-\d{2}$/', $s) ? $s : null; }
    static function num($s) { $s = trim((string)$s); if ($s === '') return null; if (strpos($s, ',') !== false) $s = str_replace(['.', ','], ['', '.'], $s); return round((float)$s, 2); }
    static function cat_busta($m) { return $m === 13 ? 'Tredicesima' : ($m === 14 ? 'Quattordicesima' : 'Busta paga'); }
    static function titolo_busta($uid, $m, $a) { $u = get_userdata($uid); return self::cat_busta($m) . ' - ' . ($u ? trim($u->first_name . ' ' . $u->last_name) : '') . ' - ' . ($m <= 12 ? self::MESI[$m] . ' ' : '') . $a; }

    /** Salva un file caricato nella cartella privata e restituisce il nome interno */
    static function salva_fisico($tmp, $orig, $uid) {
        $ext = strtolower(pathinfo($orig, PATHINFO_EXTENSION));
        if (!in_array($ext, ['pdf', 'jpg', 'jpeg', 'png', 'doc', 'docx', 'xls', 'xlsx', 'p7m', 'txt', 'odt', 'ods'], true)) return false;
        $nome = $uid . '-' . wp_generate_password(24, false) . '.' . $ext;
        return copy($tmp, self::cartella() . '/' . $nome) ? $nome : false;
    }

    static function salva_file_doc($p) {
        global $wpdb;
        $f = $_FILES['file'] ?? null; if (!$f) return 0;
        $dest = $p['utente'] === 'tutti' ? wp_list_pluck(self::dipendenti(), 'ID') : [(int)$p['utente']];
        $n = 0; $tot = count((array)$f['name']); $avv = [];
        foreach ((array)$f['name'] as $i => $orig) {
            if ($f['error'][$i] !== UPLOAD_ERR_OK) continue;
            foreach ($dest as $uid) {
                $nome = self::salva_fisico($f['tmp_name'][$i], $orig, $uid); if (!$nome) continue;
                $titolo = sanitize_text_field($p['titolo'] ?? '');
                if ($tot > 1 || !$titolo) $titolo = $titolo ? $titolo . ' - ' . pathinfo($orig, PATHINFO_FILENAME) : pathinfo($orig, PATHINFO_FILENAME);
                $ok = $wpdb->insert(self::t('documenti'), ['utente_id' => $uid, 'tipo' => 'doc', 'categoria' => sanitize_text_field($p['categoria'] ?? 'Altro'), 'titolo' => $titolo,
                    'anno' => (int)($p['anno'] ?? 0) ?: null, 'competenza' => self::d($p['competenza'] ?? ''), 'scadenza' => self::d($p['scadenza'] ?? ''),
                    'condiviso' => empty($p['condiviso']) ? 0 : 1, 'file' => $nome, 'nome_originale' => sanitize_file_name($orig), 'caricato' => current_time('mysql')]);
                if ($ok) { $n++; if (!empty($p['condiviso'])) $avv[$uid][] = $titolo; } else { @unlink(self::cartella() . '/' . $nome); self::$errore = $wpdb->last_error ?: 'errore database'; }
            }
        }
        foreach ($avv as $uid => $tt) self::notifica($uid, count($tt) > 1 ? count($tt) . ' nuovi documenti' : 'Nuovo documento', implode(', ', array_slice($tt, 0, 3)), add_query_arg('sez', 'documenti', self::url_area()));
        return $n;
    }

    static function salva_buste($p) {
        global $wpdb;
        $f = $_FILES['file'] ?? null; if (!$f) return 0;
        $n = 0; $avv = [];
        foreach ((array)$f['name'] as $i => $orig) {
            if ($f['error'][$i] !== UPLOAD_ERR_OK) continue;
            $uid = (int)($p['bp_u'][$i] ?? 0); $mese = (int)($p['bp_m'][$i] ?? 0); $anno = (int)($p['bp_a'][$i] ?? 0);
            if (!$uid || !$mese || !$anno || !self::is_dip(get_userdata($uid))) continue;
            $nome = self::salva_fisico($f['tmp_name'][$i], $orig, $uid); if (!$nome) continue;
            $ok = $wpdb->insert(self::t('documenti'), ['utente_id' => $uid, 'tipo' => 'busta', 'categoria' => self::cat_busta($mese), 'titolo' => self::titolo_busta($uid, $mese, $anno),
                'anno' => $anno, 'mese' => $mese, 'netto' => self::num($p['bp_n'][$i] ?? ''), 'emissione' => self::d($p['bp_e'][$i] ?? '') ?: current_time('Y-m-d'),
                'condiviso' => 1, 'file' => $nome, 'nome_originale' => sanitize_file_name(basename($orig)), 'caricato' => current_time('mysql')]);
            if ($ok) { $n++; if ($anno * 12 + min($mese, 12) >= (int)current_time('Y') * 12 + (int)current_time('n') - 3) $avv[$uid][] = self::nome_mese($mese) . ' ' . $anno; }
            else { @unlink(self::cartella() . '/' . $nome); self::$errore = $wpdb->last_error ?: 'errore database'; }
        }
        foreach ($avv as $uid => $mm) self::notifica($uid, count($mm) > 1 ? 'Nuove buste paga' : 'Nuova busta paga', implode(', ', $mm) . ' disponibil' . (count($mm) > 1 ? 'i' : 'e'), add_query_arg('sez', 'buste', self::url_area()));
        return $n;
    }

    /* ---------------- vista: elenco dipendenti ---------------- */
    static function v_dipendenti() {
        $f = sanitize_key($_GET['f'] ?? 'attivi');
        $tutti = self::dipendenti(false);
        $att = array_filter($tutti, function ($u) { return get_user_meta($u->ID, 'pdl_attivo', true) !== '0'; });
        $dis = array_filter($tutti, function ($u) { return get_user_meta($u->ID, 'pdl_attivo', true) === '0'; });
        $lista = $f === 'disattivati' ? $dis : ($f === 'tutti' ? $tutti : $att);
        echo '<div class="pg-head"><h1>Dipendenti</h1><div class="az"><div class="pop"><button class="btn verde" data-menu><svg viewBox="0 0 24 24"><path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6z"/></svg>Nuovo dipendente ▾</button><div class="pop-menu"><a href="#" data-apri="dr-nuovo">Aggiungi un dipendente</a><a href="#" data-apri="dr-importa">Importa da file CSV</a></div></div></div></div><div class="pg">';
        $ik = sanitize_key($_GET['imp'] ?? '');
        if ($ik && ($r = get_transient($ik))) { delete_transient($ik); echo '<div class="card"><h3>Importazione completata</h3><p><b>Annota o stampa adesso utenti e password: non verranno più mostrate.</b></p>' . $r . '</div>'; }
        echo '<div class="info"><svg viewBox="0 0 24 24"><path d="M11 7h2v2h-2zm0 4h2v6h-2zm1-9a10 10 0 1 0 10 10A10 10 0 0 0 12 2z"/></svg><span><b>' . esc_html(self::az_nome()) . '</b>: ' . count($att) . ' dipendenti attivi' . ($dis ? ' e ' . count($dis) . ' disattivati' : '') . '.</span></div>';
        echo '<div class="barra"><div class="seg">';
        foreach (['attivi' => 'Attivi (' . count($att) . ')', 'disattivati' => 'Disattivati (' . count($dis) . ')', 'tutti' => 'Tutti (' . count($tutti) . ')'] as $k => $l) echo '<a class="' . ($f === $k ? 'on' : '') . '" href="' . esc_url(self::link('dipendenti', ['f' => $k])) . '">' . $l . '</a>';
        echo '</div><div class="sp"></div><div class="cerca"><svg viewBox="0 0 24 24"><path d="M15.5 14h-.8l-.3-.3A6.5 6.5 0 1 0 14 15.5l.3.3v.8l5 5 1.5-1.5zm-6 0A4.5 4.5 0 1 1 14 9.5 4.5 4.5 0 0 1 9.5 14z"/></svg><input class="inp" placeholder="Cerca" data-cerca=".riga-dip"></div></div>';
        if (!$lista) { echo '<div class="vuoto"><div class="ill"><svg viewBox="0 0 24 24"><path d="M16 11a4 4 0 1 0-4-4 4 4 0 0 0 4 4zm0 2c-2.7 0-8 1.3-8 4v3h16v-3c0-2.7-5.3-4-8-4z"/></svg></div><h3>Nessun dipendente</h3><p>Aggiungi il primo con il pulsante verde in alto.</p></div>'; }
        else {
            echo '<table class="tab"><thead><tr><th>Dipendente ↑</th><th class="nasc">Matricola</th><th>Contratto</th><th>Stato</th></tr></thead><tbody>';
            foreach ($lista as $u) {
                $on = get_user_meta($u->ID, 'pdl_attivo', true) !== '0';
                $mail = substr($u->user_email, -18) === '@dipendenti.invalid' ? '' : $u->user_email;
                $l = esc_url(self::link('dipendente', ['id' => $u->ID]));
                echo '<tr class="riga-dip"><td><a class="chi" href="' . $l . '"><span class="av">' . self::iniziali($u) . '</span><div><div class="nm">' . self::nome($u) . '</div>'
                   . ($mail ? '<small><svg viewBox="0 0 24 24"><path d="M20 4H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zm0 4l-8 5-8-5V6l8 5 8-5z"/></svg>' . esc_html($mail) . '</small>' : '')
                   . (self::m($u, 'codice_fiscale') ? '<small><svg viewBox="0 0 24 24"><path d="M20 4H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zM8 7a2.5 2.5 0 1 1-2.5 2.5A2.5 2.5 0 0 1 8 7zm5 10H3v-1c0-1.7 3.3-2.5 5-2.5s5 .8 5 2.5zm6-3h-4v-2h4zm0-4h-4V8h4z"/></svg>' . esc_html(self::m($u, 'codice_fiscale')) . '</small>' : '')
                   . '</div></a></td><td class="nasc">' . esc_html(self::m($u, 'matricola')) . '</td><td>' . esc_html(self::m($u, 'contratto') ?: '—') . '<br><small class="mut">' . esc_html(self::m($u, 'orario')) . '</small></td>'
                   . '<td><span class="stato ' . ($on ? 'ok' : 'no') . '">' . ($on ? 'Attivo' : 'Disattivato') . '</span></td></tr>';
            }
            echo '</tbody></table>';
        }
        echo '</div>';
        echo '<div class="drawer" id="dr-nuovo"><div class="ombra" data-chiudi></div><form class="pan" method="post">' . self::nonce() . '<input type="hidden" name="pdl_act" value="dip_salva"><input type="hidden" name="scheda" value="nuovo"><div class="ph"><h2>Nuovo dipendente</h2><a href="#" data-chiudi>×</a></div><div class="pc">';
        foreach ([['first_name', 'Nome', 1], ['last_name', 'Cognome', 1], ['user_email', 'Email', 0], ['codice_fiscale', 'Codice fiscale', 0], ['matricola', 'Numero di matricola', 0], ['user_login', 'Nome utente per l\'accesso', 1], ['pass', 'Password iniziale', 1]] as $c)
            echo '<div class="campo"><label>' . $c[1] . ($c[2] ? ' <i>*</i>' : '') . '</label><input class="inp" name="' . $c[0] . '"' . ($c[2] ? ' required' : '') . ($c[0] === 'user_email' ? ' type="email"' : '') . ($c[0] === 'pass' ? ' autocomplete="new-password" minlength="6"' : '') . '></div>';
        echo '<div class="campo"><label>Azienda</label><select class="inp" name="azienda">'; foreach (self::aziende() as $k => $n) echo '<option value="' . esc_attr($k) . '"' . selected(self::az_corr(), $k, false) . '>' . esc_html($n) . '</option>'; echo '</select></div>';
        echo '<p class="mut" style="font-size:13px">Gli altri dati (contratto, IBAN, indirizzo…) li completi poi nella scheda del dipendente.</p></div><div class="pf"><a class="btn" href="#" data-chiudi>Annulla</a><button class="btn blu">Salva</button></div></form></div>';
        echo '<div class="drawer" id="dr-importa"><div class="ombra" data-chiudi></div><form class="pan" method="post" enctype="multipart/form-data">' . self::nonce() . '<input type="hidden" name="pdl_act" value="dip_importa"><div class="ph"><h2>Importa dipendenti</h2><a href="#" data-chiudi>×</a></div><div class="pc">'
           . '<p class="mut">File CSV con colonne separate da punto e virgola: <code>nome;cognome;email;codice_fiscale;matricola;attivo</code> (attivo: si/no). Per ognuno viene creato l\'accesso con una password casuale.</p>'
           . '<label class="dropzone"><input type="file" name="csv" accept=".csv,text/csv" required><div class="t">Trascina qui il file</div><div>oppure <u>scegli un file</u></div><div class="dz-lista"></div></label>'
           . '<p><label class="chk"><input type="checkbox" name="email" value="1"> Invia a ognuno l\'email per scegliere la password</label></p></div><div class="pf"><a class="btn" href="#" data-chiudi>Annulla</a><button class="btn blu">Importa</button></div></form></div>';
    }

    /* ---------------- vista: scheda dipendente ---------------- */
    static function v_dipendente() {
        global $wpdb;
        $id = (int)($_GET['id'] ?? 0); $u = get_userdata($id);
        if (!$u || !self::is_dip($u)) { echo '<div class="pg"><div class="vuoto"><h3>Dipendente non trovato</h3></div></div>'; return; }
        $t = sanitize_key($_GET['t'] ?? 'riepilogo');
        $on = self::m($u, 'attivo') !== '0';
        echo '<div class="pg-head" style="border-bottom:0"><h1><a href="' . esc_url(self::link('dipendenti')) . '">Dipendenti</a><span class="sep">›</span><span class="av" style="width:28px;height:28px;font-size:11px">' . self::iniziali($u) . '</span>' . esc_html(trim($u->first_name . ' ' . $u->last_name)) . '</h1></div>';
        echo '<div class="pg-tabs">';
        foreach (['riepilogo' => 'Riepilogo', 'contratto' => 'Contratto e orari', 'buste' => 'Buste paga', 'documenti' => 'Documenti', 'accesso' => 'Accesso'] as $k => $l) echo '<a class="' . ($t === $k ? 'on' : '') . '" href="' . esc_url(self::link('dipendente', ['id' => $id, 't' => $k])) . '">' . $l . '</a>';
        echo '</div><div class="pg">';
        $v = function ($k) use ($u) { return esc_attr(self::m($u, $k)); };
        $form_ap = '<form method="post">' . self::nonce() . '<input type="hidden" name="pdl_act" value="dip_salva"><input type="hidden" name="id" value="' . $id . '"><input type="hidden" name="scheda" value="' . esc_attr($t) . '">';
        $form_ch = '<div style="display:flex;justify-content:flex-end;gap:8px;margin-top:18px"><a class="btn" href="' . esc_url(self::link('dipendente', ['id' => $id, 't' => $t])) . '">↺ Ripristina</a><button class="btn blu">Salva modifiche</button></div></form>';
        if ($t === 'riepilogo') {
            $mail = substr($u->user_email, -18) === '@dipendenti.invalid' ? '' : $u->user_email;
            echo $form_ap . '<div class="card"><h3>Informazioni</h3><div style="display:flex;gap:24px;flex-wrap:wrap"><div style="text-align:center;width:110px"><span class="av" style="width:96px;height:96px;font-size:30px;border:3px solid var(--blu)">' . self::iniziali($u) . '</span><p><span class="stato ' . ($on ? 'ok' : 'no') . '">' . ($on ? 'Attivo' : 'Disattivato') . '</span></p></div><div class="griglia" style="flex:1;min-width:260px">';
            echo '<div class="campo"><label>Nome <i>*</i></label><input class="inp" name="first_name" required value="' . esc_attr($u->first_name) . '"></div>';
            echo '<div class="campo"><label>Cognome <i>*</i></label><input class="inp" name="last_name" required value="' . esc_attr($u->last_name) . '"></div>';
            echo '<div class="campo"><label>Numero di matricola</label><input class="inp" name="matricola" value="' . $v('matricola') . '"></div>';
            echo '<div class="campo"><label>Codice fiscale</label><input class="inp" name="codice_fiscale" value="' . $v('codice_fiscale') . '" style="text-transform:uppercase"></div>';
            echo '<div class="campo"><label>Data di nascita</label><input class="inp" type="date" name="data_nascita" value="' . $v('data_nascita') . '"></div>';
            echo '<div class="campo"><label>IBAN</label><input class="inp" name="iban" value="' . $v('iban') . '" style="text-transform:uppercase"></div>';
            echo '<div class="campo"><label>Mansione</label><input class="inp" name="mansione" value="' . $v('mansione') . '"></div>';
            echo '<div class="campo"><label>Numero di telefono</label><input class="inp" name="telefono" value="' . $v('telefono') . '"></div>';
            echo '<div class="campo"><label>Email</label><input class="inp" type="email" name="user_email" value="' . esc_attr($mail) . '"></div>';
            echo '<div class="campo larga"><label>Indirizzo</label><input class="inp" name="indirizzo" value="' . $v('indirizzo') . '"></div>';
            echo '<div class="campo"><label>Azienda</label><select class="inp" name="azienda">'; foreach (self::aziende() as $k => $n) echo '<option value="' . esc_attr($k) . '"' . selected(self::az_di($id), $k, false) . '>' . esc_html($n) . '</option>'; echo '</select></div>';
            echo '<div class="campo due"><label>Luogo di lavoro</label><input class="inp" name="luogo" value="' . $v('luogo') . '"></div>';
            echo '<div class="campo larga"><label>Note</label><textarea class="inp" name="note" placeholder="Note sul dipendente (visibili solo a te)">' . esc_textarea(self::m($u, 'note')) . '</textarea></div>';
            echo '</div></div>' . $form_ch . '</div>';
        } elseif ($t === 'contratto') {
            echo $form_ap . '<div class="card"><h3>Contratto e orari</h3><div class="griglia">';
            echo '<div class="campo"><label>Tipo di contratto</label><select class="inp" name="contratto"><option value="">—</option>';
            foreach (['Indeterminato', 'Determinato', 'Apprendistato', 'Part-time indeterminato', 'Part-time determinato', 'Stage / tirocinio', 'Collaborazione'] as $c) echo '<option' . selected(self::m($u, 'contratto'), $c, false) . '>' . $c . '</option>';
            echo '</select></div><div class="campo"><label>Orario</label><select class="inp" name="orario"><option value="">—</option>';
            foreach (['Fisso', 'Flessibile', 'Turni'] as $c) echo '<option' . selected(self::m($u, 'orario'), $c, false) . '>' . $c . '</option>';
            echo '</select></div><div class="campo"><label>Ore al giorno</label><input class="inp" type="number" step="0.5" name="ore_giorno" value="' . ($v('ore_giorno') ?: '8') . '"></div>';
            echo '<div class="campo"><label>Data di assunzione</label><input class="inp" type="date" name="data_assunzione" value="' . $v('data_assunzione') . '"></div>';
            echo '<div class="campo"><label>Fine contratto</label><input class="inp" type="date" name="fine_contratto" value="' . $v('fine_contratto') . '"></div>';
            echo '<div class="campo"><label>Livello / CCNL</label><input class="inp" name="livello" value="' . $v('livello') . '" placeholder="es. 5° livello Commercio"></div>';
            echo '</div><h3 style="margin-top:24px">Orario settimanale</h3><p class="mut" style="font-size:13px;margin-top:-8px">Serve a calcolare le ore di presenza, le ferie a giornata e i giorni non lavorativi. Lascia vuoto il giorno di riposo.</p><div style="overflow-x:auto"><table class="tab" id="orari-tab" style="max-width:760px"><thead><tr><th>Giorno</th><th>Mattina dalle</th><th>alle</th><th>Pomeriggio dalle</th><th>alle</th><th>Ore</th></tr></thead><tbody>';
            echo '<tr style="background:#eef4fd"><td><b>Tutta la settimana</b></td>'; for ($q = 0; $q < 4; $q++) echo '<td><input class="inp tutti" type="time" style="height:32px"></td>';
            echo '<td style="white-space:nowrap"><button type="button" class="btn pic blu" data-applica="5">Lun–Ven</button> <button type="button" class="btn pic" data-applica="6">Lun–Sab</button></td></tr>';
            $O = self::orari($id);
            foreach (['Lunedì', 'Martedì', 'Mercoledì', 'Giovedì', 'Venerdì', 'Sabato', 'Domenica'] as $i => $gn) { $d = $O[$i + 1] ?? [];
                echo '<tr><td>' . $gn . '</td>'; for ($s2 = 0; $s2 < 2; $s2++) for ($e = 0; $e < 2; $e++) echo '<td><input class="inp" type="time" name="orari[' . ($i + 1) . '][' . $s2 . '][' . $e . ']" value="' . esc_attr($d[$s2][$e] ?? '') . '" style="height:32px"></td>';
                echo '<td class="ore-g">' . self::ore_fmt(self::ore_slot($d)) . '</td></tr>'; }
            $tot_sett = 0; foreach ($O as $dd) $tot_sett += self::ore_slot($dd);
            echo '</tbody><tfoot><tr style="background:#f6f8fb"><td colspan="5" style="text-align:right;font-weight:600">Totale settimanale</td><td id="ore-tot" style="font-weight:700;color:var(--blu);font-size:15px">' . self::ore_fmt($tot_sett) . '</td></tr></tfoot></table></div><script>(function(){var t=document.getElementById("orari-tab");if(!t)return;
function m(v){if(!v)return null;var p=v.split(":");return +p[0]*60+ +p[1];}
function calc(){var tot=0;for(var g=1;g<=7;g++){var o=0;for(var s=0;s<2;s++){var a=m(t.querySelector("[name=\'orari["+g+"]["+s+"][0]\']").value),b=m(t.querySelector("[name=\'orari["+g+"]["+s+"][1]\']").value);if(a!==null&&b!==null&&b>a)o+=b-a;}
 var c=t.querySelector("[name=\'orari["+g+"][0][0]\']").closest("tr").querySelector(".ore-g");c.textContent=(Math.round(o/60*100)/100).toString().replace(".",",")+"h";tot+=o;}var T=document.getElementById("ore-tot");if(T)T.textContent=(Math.round(tot/60*100)/100).toString().replace(".",",")+"h";}
t.addEventListener("input",calc);t.addEventListener("change",calc);
t.querySelectorAll("[data-applica]").forEach(function(b){b.addEventListener("click",function(){var v=[].map.call(t.querySelectorAll(".tutti"),function(i){return i.value;}),n=+b.dataset.applica;
 if(!v[0]||!v[1]){alert("Scrivi almeno l\'orario della mattina (dalle e alle).");return;}
 for(var g=1;g<=7;g++)for(var s=0;s<2;s++)for(var e=0;e<2;e++){var i=t.querySelector("[name=\'orari["+g+"]["+s+"]["+e+"]\']");i.value=g<=n?v[s*2+e]:"";}calc();});});})();</script><label class="chk" style="margin-top:14px;background:#fff8e6;border:1px solid #f3d9a4;border-radius:6px;padding:10px 12px"><input type="checkbox" name="orari_tutti" value="1" onchange="if(this.checked&&!confirm(\'L\\\'orario verrà copiato su tutti gli altri dipendenti di ' . esc_js(self::az_nome()) . ', sostituendo il loro. Continuare?\'))this.checked=false"> Applica questo orario anche a <b>tutti gli altri dipendenti di ' . esc_html(self::az_nome()) . '</b></label>' . $form_ch . '</div>';
        } elseif ($t === 'buste' || $t === 'documenti') {
            $bp = $t === 'buste';
            $rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM " . self::t('documenti') . " WHERE utente_id=%d AND tipo=%s ORDER BY anno DESC, mese DESC, id DESC", $id, $bp ? 'busta' : 'doc'));
            echo '<div class="barra" style="margin-top:0"><div class="sp"></div><a class="btn verde" href="' . esc_url(self::link($bp ? 'buste' : 'documenti', $bp ? [] : ['nuovo' => $id])) . '">+ ' . ($bp ? 'Carica buste paga' : 'Carica documento') . '</a></div>';
            if (!$rows) echo '<div class="vuoto"><div class="ill"><svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/></svg></div><h3>Nessun ' . ($bp ? 'busta paga' : 'documento') . '</h3></div>';
            else {
                echo '<table class="tab"><thead><tr>' . ($bp ? '<th>Mese di competenza</th><th>Netto</th><th class="nasc">Data di emissione</th>' : '<th>Titolo</th><th>Categoria</th><th class="nasc">Caricato</th>') . '<th>Visto</th><th></th></tr></thead><tbody>';
                foreach ($rows as $d) {
                    echo '<tr>' . ($bp ? '<td>' . self::nome_mese($d->mese) . ' ' . esc_html($d->anno) . '</td><td>' . self::euro($d->netto) . '</td><td class="nasc">' . self::data_lunga($d->emissione) . '</td>'
                        : '<td>' . esc_html($d->titolo) . '</td><td>' . esc_html($d->categoria) . '</td><td class="nasc">' . self::data_it($d->caricato) . '</td>')
                        . '<td>' . ($d->scaricato ? '<span class="stato ok">Sì</span>' : '<span class="stato grigio">No</span>') . '</td><td style="text-align:right"><a href="' . esc_url($bp ? self::link('buste', ['anno' => $d->anno, 'mese' => $d->mese, 'det' => $d->id]) : self::link_doc($d->id, true)) . '"' . ($bp ? '' : ' target="_blank"') . '>Vedi dettaglio</a></td></tr>';
                }
                echo '</tbody></table>';
            }
        } else {
            echo '<div class="card"><h3>Accesso all\'area dipendenti</h3><p>Nome utente: <b>' . esc_html($u->user_login) . '</b></p><p class="mut">Il dipendente entra da <a href="' . esc_url(self::url_area()) . '" target="_blank">' . esc_html(self::url_area()) . '</a></p>';
            echo $form_ap . '<div class="griglia"><div class="campo"><label>Nuova password</label><input class="inp" name="pass" minlength="6" autocomplete="new-password" placeholder="Lascia vuoto per non cambiarla"></div></div>' . $form_ch;
            echo '</div><div class="card"><h3>' . ($on ? 'Disattiva dipendente' : 'Riattiva dipendente') . '</h3><p class="mut">' . ($on ? 'Il dipendente non potrà più entrare. I suoi documenti restano archiviati.' : 'Il dipendente potrà di nuovo entrare nell\'area dipendenti.') . '</p><form method="post">' . self::nonce() . '<input type="hidden" name="pdl_act" value="dip_stato"><input type="hidden" name="id" value="' . $id . '"><input type="hidden" name="stato" value="' . ($on ? '0' : '1') . '"><button class="btn ' . ($on ? 'rosso' : 'blu') . '"' . ($on ? ' onclick="return confirm(\'Disattivare il dipendente?\')"' : '') . '>' . ($on ? 'Disattiva' : 'Riattiva') . '</button></form></div>';
        }
        echo '</div>';
    }

    static function salva_dipendente($id) {
        $p = wp_unslash($_POST);
        $scheda = $p['scheda'] ?? 'nuovo';
        if ($id) {
            $u = get_userdata($id);
            if (!$u || !self::is_dip($u)) return new WP_Error('x', 'Dipendente non trovato.');
            $dati = ['ID' => $id];
            if ($scheda === 'riepilogo') {
                $dati += ['first_name' => sanitize_text_field($p['first_name']), 'last_name' => sanitize_text_field($p['last_name'])];
                $dati['display_name'] = trim($dati['first_name'] . ' ' . $dati['last_name']);
                $mail = sanitize_email($p['user_email'] ?? '');
                $dati['user_email'] = $mail ?: $u->user_login . '@dipendenti.invalid';
            }
            if (!empty($p['pass'])) $dati['user_pass'] = $p['pass'];
            $r = wp_update_user($dati);
            if (is_wp_error($r)) return $r;
        } else {
            if (empty($p['user_login']) || empty($p['pass'])) return new WP_Error('x', 'Servono nome utente e password iniziale.');
            $login = sanitize_user($p['user_login'], true);
            if (username_exists($login)) return new WP_Error('x', 'Nome utente già usato.');
            $mail = sanitize_email($p['user_email'] ?? '');
            if ($mail && email_exists($mail)) return new WP_Error('x', 'Email già usata da un altro utente del sito.');
            $r = wp_insert_user(['user_login' => $login, 'user_pass' => $p['pass'], 'first_name' => sanitize_text_field($p['first_name']), 'last_name' => sanitize_text_field($p['last_name']),
                'display_name' => trim(sanitize_text_field($p['first_name']) . ' ' . sanitize_text_field($p['last_name'])), 'user_email' => $mail ?: $login . '@dipendenti.invalid', 'role' => 'dipendente']);
            if (is_wp_error($r)) return $r;
            update_user_meta($r, 'pdl_attivo', '1'); update_user_meta($r, 'pdl_ore_giorno', '8');
        }
        if (isset($p['orari']) && is_array($p['orari'])) { $o = [];
            for ($g = 1; $g <= 7; $g++) { $o[$g] = []; foreach ((array)($p['orari'][$g] ?? []) as $sl) if (preg_match('/^\d\d:\d\d$/', $sl[0] ?? '') && preg_match('/^\d\d:\d\d$/', $sl[1] ?? '') && $sl[1] > $sl[0]) $o[$g][] = [$sl[0], $sl[1]]; }
            update_user_meta($r, 'pdl_orari', wp_json_encode($o));
            if (!empty($p['orari_tutti'])) foreach (self::dipendenti(false) as $alt) if ($alt->ID != $r) update_user_meta($alt->ID, 'pdl_orari', wp_json_encode($o)); }
        if (isset($p['azienda']) && isset(self::aziende()[$p['azienda']])) update_user_meta($r, 'pdl_azienda', $p['azienda']);
        $campi = ['matricola', 'codice_fiscale', 'data_nascita', 'iban', 'mansione', 'telefono', 'indirizzo', 'luogo', 'note', 'contratto', 'orario', 'ore_giorno', 'data_assunzione', 'fine_contratto', 'livello'];
        foreach ($campi as $k) if (isset($p[$k])) {
            $val = $k === 'note' ? sanitize_textarea_field($p[$k]) : sanitize_text_field($p[$k]);
            if (in_array($k, ['codice_fiscale', 'iban'], true)) $val = strtoupper(str_replace(' ', '', $val));
            update_user_meta($r, 'pdl_' . $k, $val);
        }
        return $r;
    }

    static function importa() {
        $f = $_FILES['csv']['tmp_name'] ?? '';
        if (!$f || !is_uploaded_file($f)) return '<p>File mancante.</p>';
        $righe = array_map(function ($r) { return str_getcsv($r, ';'); }, preg_split('/\r\n|\n|\r/', trim(preg_replace('/^\xEF\xBB\xBF/', '', file_get_contents($f)))));
        if ($righe && strtolower(trim($righe[0][0])) === 'nome') array_shift($righe);
        $h = '<table class="tab"><thead><tr><th>Dipendente</th><th>Utente</th><th>Password</th><th>Esito</th></tr></thead><tbody>';
        foreach ($righe as $r) {
            [$nome, $cognome, $email, $cf, $matr, $att] = array_map('trim', array_pad($r, 6, ''));
            if (!$nome && !$cognome) continue;
            $chi = esc_html("$cognome $nome");
            if ($email && email_exists($email)) { $h .= "<tr><td>$chi</td><td colspan=2>—</td><td>Già presente</td></tr>"; continue; }
            $base = preg_replace('/[^a-z0-9.]/', '', strtolower(remove_accents($nome . '.' . $cognome))) ?: 'dipendente';
            $user = $base; $i = 2; while (username_exists($user)) $user = $base . $i++;
            $pass = wp_generate_password(10, false);
            $id = wp_insert_user(['user_login' => $user, 'user_pass' => $pass, 'first_name' => $nome, 'last_name' => $cognome, 'display_name' => trim("$nome $cognome"),
                'user_email' => sanitize_email($email) ?: $user . '@dipendenti.invalid', 'role' => 'dipendente']);
            if (is_wp_error($id)) { $h .= "<tr><td>$chi</td><td colspan=2>—</td><td>" . esc_html($id->get_error_message()) . '</td></tr>'; continue; }
            update_user_meta($id, 'pdl_codice_fiscale', strtoupper(sanitize_text_field($cf)));
            update_user_meta($id, 'pdl_matricola', sanitize_text_field($matr));
            update_user_meta($id, 'pdl_ore_giorno', '8'); update_user_meta($id, 'pdl_azienda', self::az_corr());
            $on = !in_array(strtolower($att), ['no', '0', 'disattivato', 'n'], true);
            update_user_meta($id, 'pdl_attivo', $on ? '1' : '0');
            if ($on && !empty($_POST['email']) && $email) wp_new_user_notification($id, null, 'user');
            $h .= "<tr><td>$chi</td><td><code>" . esc_html($user) . '</code></td><td><code>' . esc_html($pass) . '</code></td><td>' . ($on ? 'Creato' : 'Creato (disattivato)') . '</td></tr>';
        }
        return $h . '</tbody></table>';
    }

    /* ---------------- vista: documenti ---------------- */
    static function v_documenti() {
        global $wpdb;
        $tab = sanitize_key($_GET['tab'] ?? 'caricati');
        $docs = $wpdb->get_results("SELECT * FROM " . self::t('documenti') . " WHERE tipo='doc'" . self::in_az() . " ORDER BY id DESC LIMIT 500");
        $req = $wpdb->get_results("SELECT * FROM " . self::t('richieste_doc') . " WHERE stato='In attesa'" . self::in_az() . " ORDER BY id DESC");
        $dip = self::dipendenti();
        $nuovo = (int)($_GET['nuovo'] ?? 0);
        echo '<div class="pg-head"><h1>Documenti</h1><div class="az"><button class="btn" data-apri="dr-richiedi"><svg viewBox="0 0 24 24"><path d="M2 21l21-9L2 3v7l15 2-15 2z"/></svg>Richiedi documento</button><button class="btn verde" data-apri="dr-doc"><svg viewBox="0 0 24 24"><path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6z"/></svg>Carica documento</button></div></div><div class="pg">';
        echo '<div class="barra"><div class="seg"><a class="' . ($tab !== 'attesa' ? 'on' : '') . '" href="' . esc_url(self::link('documenti')) . '">Caricati (' . count($docs) . ')</a><a class="' . ($tab === 'attesa' ? 'on' : '') . '" href="' . esc_url(self::link('documenti', ['tab' => 'attesa'])) . '">In attesa (' . count($req) . ')</a></div><div class="sp"></div>'
           . '<div class="cerca"><svg viewBox="0 0 24 24"><path d="M15.5 14h-.8l-.3-.3A6.5 6.5 0 1 0 14 15.5l.3.3v.8l5 5 1.5-1.5zm-6 0A4.5 4.5 0 1 1 14 9.5 4.5 4.5 0 0 1 9.5 14z"/></svg><input class="inp" placeholder="Cerca" data-cerca=".riga-doc"></div></div>';
        $vuoto = function ($t, $s) { echo '<div class="vuoto"><div class="ill"><svg viewBox="0 0 24 24"><path d="M10 4H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-8z"/></svg></div><h3>' . $t . '</h3><p>' . $s . '</p></div>'; };
        if ($tab === 'attesa') {
            if (!$req) $vuoto('Nessuna richiesta in attesa', 'Con "Richiedi documento" chiedi a un dipendente di caricare un documento dalla sua area.');
            else {
                echo '<table class="tab"><thead><tr><th>Dipendente</th><th>Documento richiesto</th><th class="nasc">Richiesto il</th><th class="nasc">Scadenza</th><th></th></tr></thead><tbody>';
                foreach ($req as $r) { $u = get_userdata($r->utente_id);
                    echo '<tr class="riga-doc"><td>' . ($u ? '<span class="chi"><span class="av">' . self::iniziali($u) . '</span><span class="nm">' . self::nome($u) . '</span></span>' : '—') . '</td><td>' . esc_html($r->titolo) . ($r->nota ? '<br><small class="mut">' . esc_html($r->nota) . '</small>' : '') . '</td><td class="nasc">' . self::data_it($r->creata) . '</td><td class="nasc">' . self::data_it($r->scadenza) . '</td>'
                       . '<td style="text-align:right"><form method="post" onsubmit="return confirm(\'Annullare la richiesta?\')">' . self::nonce() . '<input type="hidden" name="pdl_act" value="docreq_annulla"><input type="hidden" name="id" value="' . $r->id . '"><button class="btn pic rosso">Annulla</button></form></td></tr>'; }
                echo '</tbody></table>';
            }
        } else {
            if (!$docs) $vuoto('Non c\'è nessun documento', 'In questa sezione potrai caricare i documenti relativi a tutti i dipendenti.');
            else {
                echo '<table class="tab"><thead><tr><th>Titolo</th><th>Dipendente</th><th class="nasc">Categoria</th><th class="nasc">Competenza</th><th class="nasc">Scadenza</th><th>Condiviso</th><th></th></tr></thead><tbody>';
                foreach ($docs as $d) { $u = get_userdata($d->utente_id);
                    $scad = $d->scadenza && $d->scadenza < current_time('Y-m-d');
                    echo '<tr class="riga-doc"><td><a href="' . esc_url(self::link_doc($d->id, true)) . '" target="_blank">' . esc_html($d->titolo) . '</a></td><td>' . ($u ? '<a class="chi" href="' . esc_url(self::link('dipendente', ['id' => $u->ID, 't' => 'documenti'])) . '"><span class="av">' . self::iniziali($u) . '</span><span class="nm">' . self::nome($u) . '</span></a>' : '—') . '</td>'
                       . '<td class="nasc">' . esc_html($d->categoria) . '</td><td class="nasc">' . ($d->competenza ? self::data_it($d->competenza) : esc_html($d->anno)) . '</td><td class="nasc">' . ($d->scadenza ? '<span class="stato ' . ($scad ? 'no' : 'grigio') . '">' . self::data_it($d->scadenza) . '</span>' : '') . '</td>'
                       . '<td>' . ($d->condiviso ? ($d->scaricato ? '<span class="stato ok">Visto</span>' : '<span class="stato att">Non visto</span>') : '<span class="stato grigio">No</span>') . '</td>'
                       . '<td style="text-align:right"><div class="pop"><button class="btn pic" data-menu>•••</button><div class="pop-menu"><a href="' . esc_url(self::link_doc($d->id, true)) . '" target="_blank">Apri</a><a href="' . esc_url(self::link_doc($d->id)) . '">Scarica</a>'
                       . '<form method="post" onsubmit="return confirm(\'Eliminare il documento?\')">' . self::nonce() . '<input type="hidden" name="pdl_act" value="doc_elimina"><input type="hidden" name="id" value="' . $d->id . '"><button class="ros">Elimina</button></form></div></div></td></tr>'; }
                echo '</tbody></table>';
            }
        }
        echo '</div>';
        $opz = '<option value="">Seleziona un\'opzione</option><option value="tutti">Tutti i dipendenti attivi</option>';
        foreach ($dip as $u) $opz .= '<option value="' . $u->ID . '"' . selected($nuovo, $u->ID, false) . '>' . self::nome($u) . '</option>';
        $cat = ''; foreach (self::CAT_DOC as $c) $cat .= '<option>' . esc_html($c) . '</option>';
        echo '<div class="drawer' . ($nuovo ? ' on' : '') . '" id="dr-doc"><div class="ombra" data-chiudi></div><form class="pan" method="post" enctype="multipart/form-data">' . self::nonce() . '<input type="hidden" name="pdl_act" value="doc_carica"><div class="ph"><h2>Carica documento</h2><a href="#" data-chiudi>×</a></div><div class="pc">'
           . '<div class="campo"><label>Titolo <i>*</i></label><input class="inp" name="titolo" required></div>'
           . '<div class="campo"><label>Dipendente <i>*</i></label><select class="inp" name="utente" required>' . $opz . '</select></div>'
           . '<div class="campo"><label>Categoria <i>*</i></label><select class="inp" name="categoria" required><option value="">Seleziona un\'opzione</option>' . $cat . '</select></div>'
           . '<div class="campo"><label>Allegati <i>*</i></label><label class="dropzone"><input type="file" name="file[]" multiple required><svg viewBox="0 0 24 24" style="width:30px;height:30px;color:var(--blu)"><path d="M5 20h14v-2H5zm7-16l-5 5h3v6h4V9h3z"/></svg><div class="t">Trascina qui i file</div><div>Oppure <u>scegli un file</u> da caricare</div><div class="dz-lista"></div></label></div>'
           . '<div class="campo"><label class="chk"><input type="checkbox" name="condiviso" value="1" checked> Condividi documento con il dipendente</label></div>'
           . '<div class="campo"><label>Data di competenza</label><input class="inp" type="date" name="competenza"></div>'
           . '<div class="campo"><label>Anno di competenza</label><input class="inp" type="number" name="anno" value="' . current_time('Y') . '"></div>'
           . '<div class="campo"><label>Data di scadenza</label><input class="inp" type="date" name="scadenza"></div>'
           . '</div><div class="pf"><a class="btn" href="#" data-chiudi>↺ Annulla</a><button class="btn blu">Salva</button></div></form></div>';
        echo '<div class="drawer" id="dr-richiedi"><div class="ombra" data-chiudi></div><form class="pan" method="post">' . self::nonce() . '<input type="hidden" name="pdl_act" value="docreq_crea"><div class="ph"><h2>Richiedi documento</h2><a href="#" data-chiudi>×</a></div><div class="pc">'
           . '<p class="mut">Il dipendente vedrà la richiesta nella sua area e potrà caricare il documento da lì.</p>'
           . '<div class="campo"><label>Dipendente <i>*</i></label><select class="inp" name="utente" required>' . $opz . '</select></div>'
           . '<div class="campo"><label>Documento richiesto <i>*</i></label><input class="inp" name="titolo" required placeholder="es. Copia carta d\'identità"></div>'
           . '<div class="campo"><label>Categoria</label><select class="inp" name="categoria">' . $cat . '</select></div>'
           . '<div class="campo"><label>Nota per il dipendente</label><textarea class="inp" name="nota"></textarea></div>'
           . '<div class="campo"><label>Entro il</label><input class="inp" type="date" name="scadenza"></div>'
           . '</div><div class="pf"><a class="btn" href="#" data-chiudi>Annulla</a><button class="btn blu">Invia richiesta</button></div></form></div>';
    }

    /* ---------------- vista: buste paga ---------------- */
    static function v_buste() {
        global $wpdb;
        $anno = (int)($_GET['anno'] ?? current_time('Y'));
        $mese = isset($_GET['mese']) ? (int)$_GET['mese'] : 0;
        $fu = (int)($_GET['u'] ?? 0);
        $tab = self::t('documenti');
        $st = []; foreach ($wpdb->get_results($wpdb->prepare("SELECT mese, COUNT(*) n, SUM(netto) tot FROM $tab WHERE tipo='busta'" . self::in_az() . " AND anno=%d" . ($fu ? ' AND utente_id=' . $fu : '') . " GROUP BY mese", $anno)) as $r) $st[(int)$r->mese] = $r;
        if (!$mese) { for ($i = 12; $i >= 1; $i--) if (!empty($st[$i])) { $mese = $i; break; } if (!$mese) $mese = (int)current_time('n'); }
        $max = 1; foreach ($st as $r) $max = max($max, (float)$r->tot);
        $tutti = self::dipendenti(false);
        echo '<div class="pg-head"><h1>Buste paga <span class="sep">›</span><span class="anno"><a href="' . esc_url(self::link('buste', ['anno' => $anno - 1, 'u' => $fu ?: null])) . '">‹</a>' . $anno . '<a href="' . esc_url(self::link('buste', ['anno' => $anno + 1, 'u' => $fu ?: null])) . '">›</a></span></h1>'
           . '<div class="az"><div class="pop"><button class="btn verde" data-menu><svg viewBox="0 0 24 24"><path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6z"/></svg>Carica buste paga e CU ▾</button><div class="pop-menu"><a href="#" data-apri="dr-auto"><svg viewBox="0 0 24 24"><path d="M16 1H4a2 2 0 0 0-2 2v14h2V3h12zm3 4H8a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h11a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2zm0 16H8V7h11z"/></svg>Carica i PDF con riconoscimento automatico</a><a href="#" data-apri="dr-man"><svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8zm4 18H6V4h7v5h5z"/></svg>Carica manualmente</a></div></div></div></div><div class="pg">';
        echo '<div class="mesi"><div class="ic"><svg viewBox="0 0 24 24"><path d="M19 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2zm-9 14l-5-5 1.4-1.4 3.6 3.6 7.6-7.6L19 8z"/></svg></div>';
        for ($i = 1; $i <= 14; $i++) {
            $r = $st[$i] ?? null; $h = $r ? max(28, round(62 * (float)$r->tot / $max)) + 30 : 0;
            echo '<a class="' . ($i === $mese ? 'on' : '') . '" href="' . esc_url(self::link('buste', ['anno' => $anno, 'mese' => $i, 'u' => $fu ?: null])) . '"><span class="tt">' . self::nome_mese($i) . '</span>' . ($r ? '<span class="bar" style="height:' . $h . 'px"></span>' : '')
               . '<span class="dd"><small>' . ($r ? $r->n : 0) . ' buste</small>' . ($r && $r->tot ? '<b>' . self::euro($r->tot) . '</b>' : '') . '</span></a>';
        }
        echo '</div>';
        echo '<form class="barra" method="get"><input type="hidden" name="v" value="buste"><input type="hidden" name="anno" value="' . $anno . '"><input type="hidden" name="mese" value="' . $mese . '"><select class="inp" name="u" style="width:220px" onchange="this.form.submit()"><option value="">Seleziona dipendente</option>';
        foreach ($tutti as $u) echo '<option value="' . $u->ID . '"' . selected($fu, $u->ID, false) . '>' . self::nome($u) . '</option>';
        echo '</select><div class="sp"></div><div class="cerca"><svg viewBox="0 0 24 24"><path d="M15.5 14h-.8l-.3-.3A6.5 6.5 0 1 0 14 15.5l.3.3v.8l5 5 1.5-1.5zm-6 0A4.5 4.5 0 1 1 14 9.5 4.5 4.5 0 0 1 9.5 14z"/></svg><input class="inp" placeholder="Cerca" data-cerca=".riga-bp"></div>'
           . '<a class="btn" href="' . esc_url(wp_nonce_url(admin_url('admin-post.php?action=pdl_export_bp&anno=' . $anno), 'pdl_export_bp')) . '"><svg viewBox="0 0 24 24"><path d="M5 20h14v-2H5zM19 9h-4V3H9v6H5l7 7z"/></svg>Esporta</a></form>';
        $rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM $tab WHERE tipo='busta'" . self::in_az() . " AND anno=%d AND mese=%d" . ($fu ? ' AND utente_id=' . $fu : '') . " ORDER BY id", $anno, $mese));
        usort($rows, function ($a, $b) { $x = get_userdata($a->utente_id); $y = get_userdata($b->utente_id); return strcasecmp($x ? $x->last_name : '', $y ? $y->last_name : ''); });
        if (!$rows) echo '<div class="vuoto"><div class="ill"><svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/></svg></div><h3>Nessuna busta paga inserita</h3></div>';
        else {
            echo '<table class="tab"><thead><tr><th>Dipendente ↑</th><th>Mese di competenza</th><th>Netto</th><th class="nasc">Descrizione</th><th class="nasc">Data di emissione</th><th>Azioni</th><th></th></tr></thead><tbody>';
            foreach ($rows as $d) { $u = get_userdata($d->utente_id);
                echo '<tr class="riga-bp"><td>' . ($u ? '<span class="chi"><span class="av">' . self::iniziali($u) . '</span><a class="nm" href="' . esc_url(self::link('dipendente', ['id' => $u->ID, 't' => 'buste'])) . '">' . self::nome($u) . '</a>' . ($d->scaricato ? ' <span title="Vista dal dipendente" style="color:var(--verde)">✓✓</span>' : '') . '</span>' : '—') . '</td>'
                   . '<td>' . strtolower(self::nome_mese($d->mese)) . ' ' . esc_html($d->anno) . '</td><td>' . self::euro($d->netto) . '</td><td class="nasc">' . esc_html($d->note) . '</td><td class="nasc">' . self::data_lunga($d->emissione) . '</td>'
                   . '<td><a href="' . esc_url(self::link('buste', ['anno' => $anno, 'mese' => $mese, 'u' => $fu ?: null, 'det' => $d->id])) . '">Vedi dettaglio</a></td>'
                   . '<td style="text-align:right"><div class="pop"><button class="btn pic" data-menu>•••</button><div class="pop-menu"><a href="' . esc_url(self::link_doc($d->id)) . '">Scarica PDF</a><form method="post" onsubmit="return confirm(\'Eliminare la busta paga?\')">' . self::nonce() . '<input type="hidden" name="pdl_act" value="bp_elimina"><input type="hidden" name="id" value="' . $d->id . '"><input type="hidden" name="torna" value="' . esc_attr(self::link('buste', ['anno' => $anno, 'mese' => $mese])) . '"><button class="ros">Elimina</button></form></div></div></td></tr>'; }
            echo '</tbody></table>';
        }
        echo '</div>';
        self::bp_dettaglio($anno, $mese, $fu);
        self::bp_carica_drawers($anno, $tutti);
    }

    static function bp_dettaglio($anno, $mese, $fu) {
        global $wpdb;
        $id = (int)($_GET['det'] ?? 0); if (!$id) return;
        $d = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . self::t('documenti') . " WHERE id=%d AND tipo='busta'", $id)); if (!$d) return;
        $u = get_userdata($d->utente_id);
        $chiudi = esc_url(self::link('buste', ['anno' => $anno, 'mese' => $mese, 'u' => $fu ?: null]));
        echo '<div class="drawer pieno on"><a class="ombra" href="' . $chiudi . '"></a><div class="pan"><div class="split"><div class="prev"><iframe src="' . esc_url(self::link_doc($d->id, true)) . '#view=FitH&toolbar=1"></iframe></div><form class="lato" method="post">' . self::nonce()
           . '<input type="hidden" name="pdl_act" value="bp_aggiorna"><input type="hidden" name="id" value="' . $d->id . '"><div class="ph"><div><h2 style="color:var(--blu)">' . self::nome_mese($d->mese) . ' ' . esc_html($d->anno) . '</h2><span class="mut">' . ($u ? esc_html(trim($u->first_name . ' ' . $u->last_name)) : '') . '</span></div><a href="' . $chiudi . '">×</a></div><div class="pc"><h3 style="margin:0 0 14px;font-size:16px">Informazioni generali</h3><div class="griglia" style="grid-template-columns:1fr 1fr">';
        echo '<div class="campo"><label>Dipendente <i>*</i></label><select class="inp" name="utente">';
        foreach (self::dipendenti(false) as $x) echo '<option value="' . $x->ID . '"' . selected($d->utente_id, $x->ID, false) . '>' . self::nome($x) . '</option>';
        echo '</select></div><div class="campo"><label>Stipendio netto <i>*</i></label><input class="inp" name="netto" value="' . esc_attr($d->netto !== null ? number_format((float)$d->netto, 2, ',', '') : '') . '" placeholder="€"></div>';
        echo '<div class="campo"><label>Mese di competenza <i>*</i></label><select class="inp" name="mese">';
        for ($i = 1; $i <= 14; $i++) echo '<option value="' . $i . '"' . selected($d->mese, $i, false) . '>' . self::nome_mese($i) . '</option>';
        echo '</select></div><div class="campo"><label>Anno di competenza <i>*</i></label><input class="inp" type="number" name="anno" value="' . esc_attr($d->anno) . '"></div>';
        echo '<div class="campo larga"><label>Data di emissione <i>*</i></label><input class="inp" type="date" name="emissione" value="' . esc_attr($d->emissione) . '"></div>';
        echo '<div class="campo larga"><label>Note</label><textarea class="inp" name="note">' . esc_textarea($d->note) . '</textarea></div></div>';
        echo '<h3 style="margin:14px 0 10px;font-size:16px">Allegati</h3><div style="background:#f7f9fc;border-radius:6px;padding:12px 14px;display:flex;align-items:center;gap:10px"><div style="flex:1"><a href="' . esc_url(self::link_doc($d->id, true)) . '" target="_blank">' . esc_html($d->titolo) . '.pdf</a><br><small class="mut">Caricato il ' . self::data_it($d->caricato) . ' alle ore ' . esc_html(date('H:i', strtotime($d->caricato))) . ($d->scaricato ? ' · visto dal dipendente il ' . self::data_it($d->scaricato) : ' · non ancora visto dal dipendente') . '</small></div><a class="btn pic" href="' . esc_url(self::link_doc($d->id)) . '">⬇</a></div>';
        echo '</div><div class="pf"><a class="btn" href="' . $chiudi . '">↺ Annulla</a><button class="btn blu">Aggiorna dati</button></div></form></div></div></div>';
    }

    static function bp_carica_drawers($anno, $tutti) {
        $emp = [];
        foreach ($tutti as $u) $emp[] = ['id' => $u->ID, 'nome' => strtoupper(remove_accents($u->first_name)), 'cognome' => strtoupper(remove_accents($u->last_name)), 'cf' => strtoupper(self::m($u, 'codice_fiscale'))];
        $opz_d = '<option value="">—</option>'; foreach ($tutti as $u) $opz_d .= '<option value="' . $u->ID . '">' . self::nome($u) . '</option>';
        $opz_m = '<option value="">—</option>'; for ($i = 1; $i <= 14; $i++) $opz_m .= '<option value="' . $i . '">' . self::nome_mese($i) . '</option>';
        echo '<div class="drawer" id="dr-man"><div class="ombra" data-chiudi></div><form class="pan" method="post" enctype="multipart/form-data">' . self::nonce() . '<input type="hidden" name="pdl_act" value="bp_carica"><input type="hidden" name="anno_vista" value="' . $anno . '"><div class="ph"><h2>Carica busta paga</h2><a href="#" data-chiudi>×</a></div><div class="pc">'
           . '<div class="campo"><label>Dipendente <i>*</i></label><select class="inp" name="bp_u[0]" required>' . $opz_d . '</select></div>'
           . '<div class="griglia" style="grid-template-columns:1fr 1fr"><div class="campo"><label>Mese di competenza <i>*</i></label><select class="inp" name="bp_m[0]" required>' . $opz_m . '</select></div><div class="campo"><label>Anno <i>*</i></label><input class="inp" type="number" name="bp_a[0]" value="' . $anno . '" required></div>'
           . '<div class="campo"><label>Stipendio netto</label><input class="inp" name="bp_n[0]" placeholder="€"></div><div class="campo"><label>Data di emissione</label><input class="inp" type="date" name="bp_e[0]" value="' . current_time('Y-m-d') . '"></div></div>'
           . '<div class="campo" style="margin-top:14px"><label>Allegato <i>*</i></label><label class="dropzone"><input type="file" name="file[]" accept=".pdf,.jpg,.jpeg,.png" required><div class="t">Trascina qui il PDF</div><div>Oppure <u>scegli un file</u></div><div class="dz-lista"></div></label></div>'
           . '</div><div class="pf"><a class="btn" href="#" data-chiudi>Annulla</a><button class="btn blu">Salva</button></div></form></div>';
        echo '<div class="drawer largo" id="dr-auto"><div class="ombra" data-chiudi></div><form class="pan" method="post" enctype="multipart/form-data" id="bp-form">' . self::nonce() . '<input type="hidden" name="pdl_act" value="bp_carica"><input type="hidden" name="anno_vista" value="' . $anno . '"><input type="file" name="file[]" multiple id="bp-files" style="display:none">'
           . '<div class="ph"><h2>Carica i PDF con riconoscimento automatico</h2><a href="#" data-chiudi>×</a></div><div class="pc">'
           . '<label class="dropzone" id="bp-dz"><input type="file" multiple accept=".pdf,.zip" id="bp-scegli"><svg viewBox="0 0 24 24" style="width:34px;height:34px;color:var(--blu)"><path d="M5 20h14v-2H5zm7-16l-5 5h3v6h4V9h3z"/></svg><div class="t">Trascina qui le buste paga (PDF) o uno .zip</div><div>Oppure <u>scegli i file</u>: puoi selezionarne quanti vuoi</div></label>'
           . '<p class="mut" id="bp-stato" style="margin:12px 0"></p><div style="overflow-x:auto"><table class="tab ric" id="bp-tab" style="display:none"><thead><tr><th>File</th><th>Dipendente</th><th>Mese</th><th>Anno</th><th>Netto €</th><th>Emissione</th><th></th></tr></thead><tbody></tbody></table></div>'
           . '<p class="mut" style="font-size:13px">Il programma legge ogni PDF e cerca codice fiscale o nome del dipendente, mese e anno, netto e data di stampa. Controlla le righe gialle prima di salvare: lì manca qualcosa.</p>'
           . '</div><div class="pf"><a class="btn" href="#" data-chiudi>Annulla</a><button class="btn blu" id="bp-salva" disabled>Salva buste paga</button></div></form></div>';
        ?>
<script>
(function(){
var LIBS=null;function carica(u){return new Promise(function(ok,ko){var s=document.createElement("script");s.src=u;s.onload=ok;s.onerror=ko;document.head.appendChild(s);});}
function librerie(){if(!LIBS)LIBS=Promise.all([carica("https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js"),carica("https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js")]).then(function(){pdfjsLib.GlobalWorkerOptions.workerSrc="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js";});return LIBS;}
document.querySelectorAll('[data-apri="dr-auto"]').forEach(function(a){a.addEventListener("click",function(){librerie();});});
var EMP=<?php echo wp_json_encode($emp); ?>, OD=<?php echo wp_json_encode($opz_d); ?>, OM=<?php echo wp_json_encode($opz_m); ?>, ANNO=<?php echo (int)$anno; ?>;
var MESI=["GENNAIO","FEBBRAIO","MARZO","APRILE","MAGGIO","GIUGNO","LUGLIO","AGOSTO","SETTEMBRE","OTTOBRE","NOVEMBRE","DICEMBRE"];
var scegli=document.getElementById("bp-scegli"),tb=document.querySelector("#bp-tab tbody"),stato=document.getElementById("bp-stato"),salva=document.getElementById("bp-salva"),lista=[];
function norm(s){return s.normalize("NFD").replace(/[̀-ͯ]/g,"").toUpperCase();}
function trovaDip(t){var i,e;for(i=0;i<EMP.length;i++){e=EMP[i];if(e.cf&&t.indexOf(e.cf)>-1)return e.id;}
 var c=EMP.filter(function(e){return e.cognome.length>2&&new RegExp("(^|[^A-Z])"+e.cognome+"([^A-Z]|$)").test(t);});
 if(c.length===1)return c[0].id;for(i=0;i<c.length;i++)if(c[i].nome&&t.indexOf(c[i].nome)>-1)return c[i].id;return "";}
function trovaMese(t){var m=t.match(/(GENNAIO|FEBBRAIO|MARZO|APRILE|MAGGIO|GIUGNO|LUGLIO|AGOSTO|SETTEMBRE|OTTOBRE|NOVEMBRE|DICEMBRE|TREDICESIMA|QUATTORDICESIMA)\s*(20\d\d)/);
 if(m)return[m[1]==="TREDICESIMA"?13:m[1]==="QUATTORDICESIMA"?14:MESI.indexOf(m[1])+1,+m[2]];
 if(/TREDICESIMA|13\s*ESIMA/.test(t)){var y=t.match(/20\d\d/);return[13,y?+y[0]:""];}
 m=t.match(/(20\d\d)[\s._-]?(0[1-9]|1[0-2])(?!\d)/);if(m)return[+m[2],+m[1]];
 m=t.match(/(?:^|[^\d])(0?[1-9]|1[0-2])[\s._\/-](20\d\d)/);if(m)return[+m[1],+m[2]];
 for(var i=0;i<12;i++)if(t.indexOf(MESI[i])>-1){var y2=t.match(/20\d\d/);return[i+1,y2?+y2[0]:""];}return["",""];}
function trovaNetto(t){var re=/NETTO(?:\s+(?:IN\s+BUSTA|DEL\s+MESE|A\s+PAGARE|BUSTA))?[^0-9]{0,40}?(\d{1,3}(?:\.\d{3})*,\d{2})/g,m,u="";while((m=re.exec(t)))u=m[1];return u;}
function trovaData(t){var m=t.match(/STAMPAT[OA]\s+IL\s*(\d{2})[\/.-](\d{2})[\/.-](\d{4})/);return m?m[3]+"-"+m[2]+"-"+m[1]:"";}
var PB="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/";
function testoPdf(buf){if(!window.pdfjsLib)return Promise.resolve({t:"",I:[]});return pdfjsLib.getDocument({data:buf,cMapUrl:PB+"cmaps/",cMapPacked:true,standardFontDataUrl:PB+"standard_fonts/"}).promise.then(function(pdf){var p=[];for(var i=1;i<=Math.min(pdf.numPages,3);i++)p.push(pdf.getPage(i).then(function(pg){return pg.getTextContent();}).then(function(c,k){return c.items.map(function(x){return {s:x.str,x:x.transform[4],y:x.transform[5]};});}));return Promise.all(p);})
 .then(function(pg){var I=[];pg.forEach(function(items,n){items.forEach(function(o){o.p=n;I.push(o);});});return {t:I.map(function(o){return o.s;}).join(" "),I:I};}).catch(function(){return {t:"",I:[]};});}
/* cerca il valore vicino a un'etichetta in base alla posizione sulla pagina (le buste paga mettono etichette e valori in pezzi separati) */
function vicino(I,re,valRe,dyMin,dyMax){var Ls=I.filter(function(o){return o.s.trim().length<28&&re.test(o.s);});
 for(var k=0;k<Ls.length;k++){var L=Ls[k],c=I.filter(function(o){return o.p===L.p&&valRe.test(o.s.trim())&&o.y>=L.y+dyMin&&o.y<=L.y+dyMax&&o.x>=L.x-5;}).sort(function(a,b){return (Math.abs(a.y-L.y)>3)-(Math.abs(b.y-L.y)>3)||a.x-b.x;});if(c.length)return c[0].s.trim();}return "";}
function nettoPos(I){return vicino(I,/NETTO\s+IN\s+BUSTA|NETTO\s+A\s+PAGARE|NETTO\s+DEL\s+MESE|^\s*NETTO\s*$/i,/^[\d.]+,\d{2}$/,-25,3);}
function dataPos(I){var d=vicino(I,/STAMPAT[OA]\s+IL|DATA\s+(?:DI\s+)?(?:STAMPA|EMISSIONE|ELABORAZIONE)/i,/^\d{2}[\/.-]\d{2}[\/.-]\d{4}$/,-14,3);if(!d)return "";var m=d.split(/[\/.-]/);return m[2]+"-"+m[1]+"-"+m[0];}
var SALTATI=[];
function dividi(items){var out=[];return items.reduce(function(pr,it){return pr.then(function(){return it.file.arrayBuffer().then(function(ab){return pdfjsLib.getDocument({data:new Uint8Array(ab.slice(0))}).promise.then(function(d){if(d.numPages<2){out.push(it);return;}
 var cf=[],q=Promise.resolve();for(var i=1;i<=d.numPages;i++)(function(i){q=q.then(function(){return d.getPage(i).then(function(p){return p.getTextContent();}).then(function(c){var m=c.items.map(function(x){return x.str;}).join(" ").match(/[A-Z]{6}\d\d[A-Z]\d\d[A-Z]\d{3}[A-Z]/);cf[i]=m?m[0]:(cf[i-1]||"");});});})(i);
 return q.then(function(){var gr=[];for(var i=1;i<=d.numPages;i++){if(!gr.length||cf[i]!==gr[gr.length-1].cf)gr.push({cf:cf[i],p:[]});gr[gr.length-1].p.push(i-1);}
  if(gr.length<2){out.push(it);return;}
  return carica("https://cdnjs.cloudflare.com/ajax/libs/pdf-lib/1.17.1/pdf-lib.min.js").then(function(){return PDFLib.PDFDocument.load(ab);}).then(function(src){return gr.reduce(function(p2,g,k){return p2.then(function(){return PDFLib.PDFDocument.create().then(function(nd){return nd.copyPages(src,g.p).then(function(pp){pp.forEach(function(x){nd.addPage(x);});return nd.save();}).then(function(by){var nome=it.file.name.replace(/\.pdf$/i,"")+" - "+(k+1)+".pdf";out.push({file:new File([by],nome,{type:"application/pdf"}),path:nome});});});});},Promise.resolve());});});});}).catch(function(){out.push(it);});});},Promise.resolve()).then(function(){return out;});}
function isPdf(b){return b.slice(0,5).arrayBuffer().then(function(a){var u=new Uint8Array(a);return u[0]===0x25&&u[1]===0x50&&u[2]===0x44&&u[3]===0x46;});}
function apriZip(blob,pref,out,liv){return blob.arrayBuffer().then(function(buf){return JSZip.loadAsync(buf);}).then(function(z){var ps=[];z.forEach(function(path,e){if(e.dir||path.indexOf("__MACOSX")>-1||/(^|\/)\./.test(path))return;
 ps.push(e.async("uint8array").then(function(u8){var b=new Blob([u8]),nome=path.split("/").pop(),full=pref+path;
  if(/\.zip$/i.test(nome)&&liv<3)return apriZip(b,full.replace(/\.zip$/i,"")+"/",out,liv+1);
  return isPdf(b).then(function(ok){if(ok)out.push({file:new File([b],/\.pdf$/i.test(nome)?nome:nome+".pdf",{type:"application/pdf"}),path:full});else SALTATI.push(full);});}));});return Promise.all(ps);});}
function espandi(files){var out=[];SALTATI=[];return Promise.all(Array.prototype.map.call(files,function(f){
 if(/\.zip$/i.test(f.name))return apriZip(f,"",out,0).catch(function(){SALTATI.push(f.name+" (zip non leggibile)");});
 return isPdf(f).then(function(ok){if(ok)out.push({file:f,path:f.name});else SALTATI.push(f.name);});})).then(function(){return out;});}
function riga(it,i){var tr=document.createElement("tr");
 tr.innerHTML='<td class="fn"></td><td><select class="inp" name="bp_u['+i+']">'+OD+'</select></td><td><select class="inp" name="bp_m['+i+']">'+OM+'</select></td><td><input class="inp" type="number" name="bp_a['+i+']" style="width:80px"></td><td><input class="inp" name="bp_n['+i+']" style="width:100px"></td><td><input class="inp" type="date" name="bp_e['+i+']"></td><td><a href="#" class="tog" title="Escludi">✕</a></td>';
 tr.querySelector(".fn").textContent=it.file.name;tr.querySelector(".fn").title=it.path;
 tr.querySelector("[name^=bp_u]").value=it.u;tr.querySelector("[name^=bp_m]").value=it.m;tr.querySelector("[name^=bp_a]").value=it.a;tr.querySelector("[name^=bp_n]").value=it.n;tr.querySelector("[name^=bp_e]").value=it.e;
 function ch(){var ok=tr.querySelector("[name^=bp_u]").value&&tr.querySelector("[name^=bp_m]").value&&tr.querySelector("[name^=bp_a]").value;tr.className=ok?"ok":"ko";}
 tr.addEventListener("change",ch);ch();tr.querySelector(".tog").addEventListener("click",function(e){e.preventDefault();it.via=!it.via;tr.style.opacity=it.via?.35:1;tr.querySelectorAll("select,input").forEach(function(x){x.disabled=it.via;});});return tr;}
scegli.addEventListener("change",function(){var fs=Array.prototype.slice.call(scegli.files);if(!fs.length)return;stato.textContent="Lettura dei file in corso…";salva.disabled=true;
 librerie().then(function(){return espandi(fs);}).then(dividi).then(function(items){var n=0;stato.textContent="Lettura di "+items.length+" PDF…";
  return items.reduce(function(pr,it){return pr.then(function(){return it.file.arrayBuffer().then(testoPdf).then(function(r){var T=norm(r.t),P=norm(it.path.replace(/[_\/.-]/g," "));
   it.u=trovaDip(T)||trovaDip(P);var mm=trovaMese(T);if(!mm[0])mm=trovaMese(norm(it.path.replace(/[_\/]/g," ")));it.m=mm[0];it.a=mm[1]||ANNO;it.n=nettoPos(r.I)||trovaNetto(T);it.e=dataPos(r.I)||trovaData(T);
   lista.push(it);tb.appendChild(riga(it,lista.length-1));n++;stato.textContent="Letti "+n+" di "+items.length+"…";});});},Promise.resolve()).then(function(){
   document.getElementById("bp-tab").style.display="";var ko=tb.querySelectorAll("tr.ko").length;stato.innerHTML=(lista.length?"<b>"+lista.length+" buste paga lette.</b> "+(ko?ko+" da completare (righe gialle).":"Tutte riconosciute: controlla e salva."):"<b>Nessun PDF trovato.</b>")+(SALTATI.length?"<br><small>File saltati perché non sono PDF ("+SALTATI.length+"): "+SALTATI.slice(0,8).map(function(x){return x.replace(/</g,"");}).join(", ")+(SALTATI.length>8?"…":"")+"</small>":"");salva.disabled=!lista.length;});});
 scegli.value="";});
document.getElementById("bp-form").addEventListener("submit",function(e){e.preventDefault();var f=this,righe=[],mancano=0;
 Array.prototype.forEach.call(tb.querySelectorAll("tr"),function(tr,i){var it=lista[i];if(it.via)return;if(tr.className==="ko"){mancano++;return;}
  righe.push({file:it.file,u:tr.querySelector("[name^=bp_u]").value,m:tr.querySelector("[name^=bp_m]").value,a:tr.querySelector("[name^=bp_a]").value,n:tr.querySelector("[name^=bp_n]").value,e:tr.querySelector("[name^=bp_e]").value});});
 if(!righe.length){alert("Nessuna busta completa da salvare.");return;}
 if(mancano&&!confirm(mancano+" buste non hanno dipendente o mese e verranno saltate. Continuare?"))return;
 salva.disabled=true;var fatte=0,errori=[],G=10,nonce=f.querySelector("[name=_pdlnonce]").value,av=f.querySelector("[name=anno_vista]").value;
 function lotto(k){if(k>=righe.length){var u=new URL(location.href);u.searchParams.delete("det");u.searchParams.set(errori.length?"err":"ok",errori.length?fatte+" caricate, problemi: "+errori.join("; "):fatte+" buste paga caricate");location.href=u.toString();return;}
  var fd=new FormData();fd.append("_pdlnonce",nonce);fd.append("pdl_act","bp_carica");fd.append("anno_vista",av);
  righe.slice(k,k+G).forEach(function(r,i){fd.append("file[]",r.file,r.file.name);["u","m","a","n","e"].forEach(function(c){fd.append("bp_"+c+"["+i+"]",r[c]);});});
  salva.textContent="Caricamento "+Math.min(k+G,righe.length)+" di "+righe.length+"…";
  fetch(location.pathname+location.search,{method:"POST",body:fd,credentials:"same-origin"}).then(function(r){var q=new URL(r.url).searchParams,ok=q.get("ok"),er=q.get("err");
   if(er)errori.push(er);var m=(ok||er||"").match(/(\d+)/);fatte+=m?+m[1]:0;if(!ok&&!er&&r.status>=400)errori.push("errore "+r.status);lotto(k+G);})
  .catch(function(){errori.push("connessione interrotta");lotto(k+G);});}
 lotto(0);});
})();
</script>
        <?php
    }

    static function export_bp() {
        global $wpdb;
        if (!current_user_can('manage_options') || !check_admin_referer('pdl_export_bp')) wp_die('Non autorizzato');
        self::$fe = true;
        $anno = (int)$_GET['anno'];
        $rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM " . self::t('documenti') . " WHERE tipo='busta'" . self::in_az() . " AND anno=%d ORDER BY mese, utente_id", $anno));
        header('Content-Type: text/csv; charset=utf-8'); header("Content-Disposition: attachment; filename=buste_paga_$anno.csv");
        $f = fopen('php://output', 'w'); fwrite($f, "\xEF\xBB\xBF");
        fputcsv($f, ['Dipendente', 'Codice fiscale', 'Mese', 'Anno', 'Netto', 'Data emissione', 'Vista dal dipendente'], ';');
        foreach ($rows as $d) { $u = get_userdata($d->utente_id);
            fputcsv($f, [$u ? trim($u->last_name . ' ' . $u->first_name) : '', $u ? self::m($u, 'codice_fiscale') : '', self::nome_mese($d->mese), $d->anno, $d->netto !== null ? number_format((float)$d->netto, 2, ',', '') : '', $d->emissione ? date('d/m/Y', strtotime($d->emissione)) : '', $d->scaricato ? 'Sì' : 'No'], ';'); }
        exit;
    }

    /* =====================================================================
       AREA DIPENDENTI (shortcode [area_dipendenti])
       ===================================================================== */

    /* =====================================================================
       PRESENZE: giustificativi, calendario, richieste, bilancio
       ===================================================================== */
    // nome => [sigla, colore, a ore, conto del bilancio, è un'assenza, icona]
    const TIPI = [
        'Aspettativa Non Retribuita' => ['AS', '#64748b', false, '', true, 'pausa'],
        'Assenza Ingiustificata'     => ['AI', '#dc2626', false, '', true, 'x'],
        'Ferie'                      => ['F', '#2563eb', false, 'ferie', true, 'ombrellone'],
        'Ferie (ore)'                => ['Fh', '#3b82f6', true, 'ferie', true, 'ombrellone'],
        'Malattia'                   => ['M', '#e11d48', false, '', true, 'croce'],
        'Malattia figlio < 3 anni'   => ['MF', '#be185d', false, '', true, 'croce'],
        'Malattia figlio 3+ anni'    => ['MF', '#9d174d', false, '', true, 'croce'],
        'Permessi'                   => ['P', '#9333ea', true, 'permessi', true, 'orologio'],
        'Permessi Ex Festività'      => ['EF', '#7c3aed', true, 'exfs', true, 'orologio'],
        'ROL'                        => ['R', '#0891b2', true, 'rol', true, 'orologio'],
        'Smart Working'              => ['SW', '#0d9488', false, '', false, 'casa'],
        'Straordinari'               => ['ST', '#ea580c', true, '', false, 'piu'],
    ];
    const CONTI = ['ferie' => 'Ferie', 'rol' => 'ROL', 'exfs' => 'Perm. ex-fs', 'permessi' => 'Permessi'];
    const ICONE = [
        'ombrellone' => '<path d="M13.1 14.6l1.4-1.4 6.5 6.4L19.6 21zm4.3-5.8l2.9-2.8a10.1 10.1 0 0 0-14.3 0c3.9-1.3 8.3-.3 11.4 2.8zM6 6a10.1 10.1 0 0 0 0 14.3l2.8-2.9C5.7 14.3 4.7 9.9 6 6zm0 0c-.4 3 1.2 6.9 4.3 10l5.7-5.7C12.9 7.2 9 5.6 6 6z"/>',
        'croce' => '<path d="M19 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2zm-2 10h-4v4h-2v-4H7v-2h4V7h2v4h4z"/>',
        'orologio' => '<path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm4.2 14.2L11 13V7h1.5v5.2l4.5 2.7z"/>',
        'casa' => '<path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/>',
        'piu' => '<path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm5 11h-4v4h-2v-4H7v-2h4V7h2v4h4z"/>',
        'x' => '<path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm5 13.6L15.6 17 12 13.4 8.4 17 7 15.6 10.6 12 7 8.4 8.4 7 12 10.6 15.6 7 17 8.4 13.4 12z"/>',
        'pausa' => '<path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm-1 14H9V8h2zm4 0h-2V8h2z"/>',
        'festa' => '<path d="M19 4h-1V2h-2v2H8V2H6v2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zm0 16H5V9h14zM9.5 11l1.4 1.4L12 11.3l1.1 1.1 1.4-1.4L13.4 9.9l-1.4 1.4zM8 13h8v5H8z"/>',
        'tag' => '<path d="M21.4 11.6l-9-9A2 2 0 0 0 11 2H4a2 2 0 0 0-2 2v7a2 2 0 0 0 .6 1.4l9 9a2 2 0 0 0 2.8 0l7-7a2 2 0 0 0 0-2.8zM6.5 8A1.5 1.5 0 1 1 8 6.5 1.5 1.5 0 0 1 6.5 8z"/>',
    ];

    static function tipi() {
        $t = self::TIPI;
        foreach ((array)get_option('pdl_tipi_extra', []) as $n => $o) $t[$n] = [mb_substr($n, 0, 2), '#475569', !empty($o['ore']), '', !isset($o['assenza']) || $o['assenza'], 'tag'];
        return $t;
    }
    static function ico($tipo, $px = 18) {
        $t = self::tipi()[$tipo] ?? ['?', '#64748b', false, '', true, 'tag'];
        return '<svg viewBox="0 0 24 24" style="width:' . $px . 'px;height:' . $px . 'px;color:' . $t[1] . '"><title>' . esc_attr($tipo) . '</title>' . self::ICONE[$t[5]] . '</svg>';
    }

    /* ---------- orari di contratto e festivi ---------- */
    /** Orari settimanali: [1..7 => [['09:00','13:00'], ...]] */
    static function orari($uid) {
        $o = json_decode((string)get_user_meta($uid, 'pdl_orari', true), true);
        if (is_array($o) && $o) return $o;
        $h = (float)(get_user_meta($uid, 'pdl_ore_giorno', true) ?: 8);
        $fine = $h > 4 ? sprintf('%02d:%02d', 14 + floor($h - 4), round(fmod($h - 4, 1) * 60)) : sprintf('%02d:%02d', 9 + floor($h), round(fmod($h, 1) * 60));
        $slot = $h > 4 ? [['09:00', '13:00'], ['14:00', $fine]] : [['09:00', $fine]];
        return [1 => $slot, 2 => $slot, 3 => $slot, 4 => $slot, 5 => $slot, 6 => [], 7 => []];
    }
    static function min($hhmm) { $p = explode(':', $hhmm); return (int)$p[0] * 60 + (int)($p[1] ?? 0); }
    static function ore_slot($slots) { $t = 0; foreach ((array)$slots as $s) if (!empty($s[0]) && !empty($s[1])) $t += max(0, self::min($s[1]) - self::min($s[0])); return round($t / 60, 2); }
    static function ore_contratto($uid, $giorno) { if (self::festivo($giorno)) return 0; return self::ore_slot(self::orari($uid)[(int)date('N', strtotime($giorno))] ?? []); }
    static function pasqua($a) { $b = $a % 19; $c = intdiv($a, 100); $d = $a % 100; $e = intdiv($c, 4); $f = $c % 4; $g = intdiv($c + 8, 25); $h = intdiv($c - $g + 1, 3);
        $i = (19 * $b + $c - $e - $h + 15) % 30; $k = intdiv($d, 4); $l = $d % 4; $m = (32 + 2 * $f + 2 * $k - $i - $l) % 7; $n = intdiv($b + 11 * $i + 22 * $m, 451);
        $mese = intdiv($i + $m - 7 * $n + 114, 31); $giorno = (($i + $m - 7 * $n + 114) % 31) + 1; return sprintf('%04d-%02d-%02d', $a, $mese, $giorno); }
    static function festivi($a) {
        static $c = [];
        if (isset($c[$a])) return $c[$a];
        $f = [];
        foreach (['01-01' => 'Capodanno', '01-06' => 'Epifania', '04-25' => 'Festa della Liberazione', '05-01' => 'Festa dei Lavoratori', '06-02' => 'Festa della Repubblica', '08-15' => 'Ferragosto', '11-01' => 'Ognissanti', '12-08' => 'Immacolata', '12-25' => 'Natale', '12-26' => 'Santo Stefano'] as $md => $n) $f["$a-$md"] = $n;
        $p = self::pasqua($a); $f[$p] = 'Pasqua'; $f[date('Y-m-d', strtotime($p . ' +1 day'))] = 'Lunedì dell\'Angelo';
        foreach ((array)get_option('pdl_festivi_extra', []) as $md => $n) if (preg_match('/^\d\d-\d\d$/', $md)) $f["$a-$md"] = $n;
        return $c[$a] = $f;
    }
    static function festivo($g) { return self::festivi((int)substr($g, 0, 4))[$g] ?? ''; }
    static function chiuso($a, $m) { return in_array(sprintf('%04d-%02d', $a, $m), (array)get_option('pdl_mesi_chiusi', []), true); }

    /* ---------- dati ---------- */
    static function giust($da, $a, $uids = null, $stati = ['Approvato', 'In attesa']) {
        global $wpdb;
        $q = $wpdb->prepare("SELECT * FROM " . self::t('giust') . " WHERE giorno BETWEEN %s AND %s", $da, $a);
        if ($uids) $q .= ' AND utente_id IN (' . implode(',', array_map('intval', (array)$uids)) . ')';
        if ($stati) $q .= " AND stato IN ('" . implode("','", array_map('esc_sql', $stati)) . "')";
        $out = [];
        foreach ($wpdb->get_results($q . ' ORDER BY giorno, dalle, id') as $r) $out[$r->utente_id][$r->giorno][] = $r;
        return $out;
    }
    /** Ore di presenza effettive di un giorno */
    static function presenza($uid, $g, $lista) {
        $h = self::ore_contratto($uid, $g); $T = self::tipi();
        foreach ((array)$lista as $x) { if ($x->stato !== 'Approvato') continue; $t = $T[$x->tipo] ?? null; if (!$t) continue;
            if ($t[4]) $h -= (float)$x->ore; elseif ($x->tipo === 'Straordinari') $h += (float)$x->ore; }
        return max(0, round($h, 2));
    }
    static function ore_fmt($h) { $h = (float)$h; return rtrim(rtrim(number_format($h, 2, ',', ''), '0'), ',') . 'h'; }

    /** Inserisce giustificativi per uno o più giorni; restituisce il numero creato */
    static $protocollo = '';
    static function crea_giust($uid, $tipo, $dal, $al, $dalle, $alle, $ore, $stato, $nota = '', $gruppo = '', $forza_singolo = false) {
        global $wpdb;
        $T = self::tipi(); if (!isset($T[$tipo])) return 0;
        $oraria = $T[$tipo][2]; $n = 0;
        $dalle = preg_match('/^\d\d:\d\d$/', (string)$dalle) ? $dalle : null; $alle = preg_match('/^\d\d:\d\d$/', (string)$alle) ? $alle : null;
        if ($oraria && $dalle && $alle) $ore = round(max(0, self::min($alle) - self::min($dalle)) / 60, 2);
        for ($t = strtotime($dal); $t <= strtotime($al); $t += DAY_IN_SECONDS) {
            $g = date('Y-m-d', $t);
            if (self::chiuso((int)date('Y', $t), (int)date('n', $t))) continue;
            $oc = self::ore_contratto($uid, $g);
            if (!$oc && !($forza_singolo && $dal === $al) && $tipo !== 'Straordinari') continue; // salta festivi e giorni non lavorativi
            $h = ($oraria || (float)$ore > 0) ? (float)$ore : $oc;
            if (!$oraria && $wpdb->get_var($wpdb->prepare("SELECT id FROM " . self::t('giust') . " WHERE utente_id=%d AND giorno=%s AND tipo=%s AND stato<>'Rifiutato' LIMIT 1", $uid, $g, $tipo))) continue; // già segnato
            $ok = $wpdb->insert(self::t('giust'), ['utente_id' => $uid, 'giorno' => $g, 'tipo' => $tipo, 'ore' => $h, 'dalle' => $oraria ? $dalle : null, 'alle' => $oraria ? $alle : null,
                'intero' => $oraria ? 0 : 1, 'stato' => $stato, 'nota' => $nota, 'protocollo' => strpos($tipo, 'Malattia') === 0 && self::$protocollo !== '' ? self::$protocollo : null, 'gruppo' => $gruppo ?: wp_generate_password(10, false), 'creato' => current_time('mysql'), 'creato_da' => get_current_user_id()]);
            if ($ok) $n++; else self::$errore = $wpdb->last_error ?: 'errore database';
        }
        return $n;
    }

    /* ---------- azioni ---------- */
    static function azione_pres($a, $p) {
        global $wpdb;
        $tab = self::t('giust');
        $torna = function ($args, $msg) { wp_safe_redirect(add_query_arg(array_merge($args, ['ok' => rawurlencode($msg)]), self::url_gestione())); exit; };
        $base = ['v' => 'presenze', 'anno' => (int)($p['anno'] ?? 0) ?: null, 'mese' => (int)($p['mese'] ?? 0) ?: null, 'vista' => sanitize_key($p['vista'] ?? '') ?: null, 'sett' => self::d($p['sett'] ?? '') ?: null];
        self::$protocollo = sanitize_text_field($p['protocollo'] ?? '');
        switch ($a) {
            case 'g_protocollo':
                $r = $wpdb->get_row($wpdb->prepare("SELECT * FROM $tab WHERE id=%d", (int)$p['id']));
                if ($r) $wpdb->update($tab, ['protocollo' => sanitize_text_field($p['protocollo'] ?? '')], ['gruppo' => $r->gruppo, 'utente_id' => $r->utente_id]);
                $torna($base + ['g' => $r ? $r->giorno : null, 'du' => $r ? $r->utente_id : null], 'Protocollo salvato');
            case 'g_multi':
                $uids = array_map('intval', (array)($p['dip'] ?? []));
                $dal = self::d($p['dal'] ?? '') ?: self::d($p['data'] ?? ''); $al = !empty($p['piu']) ? (self::d($p['al'] ?? '') ?: $dal) : $dal;
                if (!$uids || !$dal || $al < $dal) { wp_safe_redirect(add_query_arg(array_merge($base, ['err' => rawurlencode('Scegli dipendenti e date')]), self::url_gestione())); exit; }
                $n = 0;
                if (($p['modo'] ?? 'aggiungi') === 'elimina') {
                    foreach ($uids as $u) { $q = $wpdb->prepare("DELETE FROM $tab WHERE utente_id=%d AND giorno BETWEEN %s AND %s", $u, $dal, $al); if (!empty($p['tipo'])) $q .= $wpdb->prepare(' AND tipo=%s', $p['tipo']); $n += (int)$wpdb->query($q); }
                    $torna($base, "$n giustificativi eliminati");
                }
                foreach ($uids as $u) $n += self::crea_giust($u, $p['tipo'], $dal, $al, $p['dalle'] ?? '', $p['alle'] ?? '', self::num($p['ore'] ?? ''), 'Approvato', sanitize_text_field($p['nota'] ?? ''), wp_generate_password(10, false), $dal === $al);
                if (self::$errore) { wp_safe_redirect(add_query_arg(array_merge($base, ['err' => rawurlencode("$n inseriti, errore: " . self::$errore)]), self::url_gestione())); exit; }
                $torna($base, "$n giustificativi inseriti");
            case 'g_sel':
                $n = 0; $del = ($p['modo'] ?? '') === 'elimina'; $grp = [];
                foreach ((array)($p['sel'] ?? []) as $it) { [$u, $g] = array_pad(explode('|', $it), 2, ''); $u = (int)$u; $g = self::d($g); if (!$u || !$g) continue;
                    if ($del) { if (!self::chiuso((int)substr($g, 0, 4), (int)substr($g, 5, 2))) $n += (int)$wpdb->query($wpdb->prepare("DELETE FROM $tab WHERE utente_id=%d AND giorno=%s", $u, $g)); continue; }
                    $grp[$u] = $grp[$u] ?? wp_generate_password(10, false);
                    if (!self::chiuso((int)substr($g, 0, 4), (int)substr($g, 5, 2))) $wpdb->query($wpdb->prepare("DELETE FROM $tab WHERE utente_id=%d AND giorno=%s AND tipo=%s", $u, $g, $p['tipo'])); // sostituisce quello già segnato
                    $n += self::crea_giust($u, $p['tipo'], $g, $g, $p['dalle'] ?? '', $p['alle'] ?? '', self::num($p['ore'] ?? ''), 'Approvato', sanitize_text_field($p['nota'] ?? ''), $grp[$u], false); }
                if (self::$errore) { wp_safe_redirect(add_query_arg(array_merge($base, ['err' => rawurlencode("$n salvati, errore: " . self::$errore)]), self::url_gestione())); exit; }
                $torna($base, $del ? "$n giustificativi eliminati" : "$n giorni segnati" . ($n < count((array)($p['sel'] ?? [])) ? ' (saltati festivi e riposi)' : ''));
            case 'g_giorno':
                $u = (int)$p['u']; $g = self::d($p['g']);
                $n = self::crea_giust($u, $p['tipo'], $g, $g, $p['dalle'] ?? '', $p['alle'] ?? '', self::num($p['ore'] ?? ''), 'Approvato', sanitize_text_field($p['nota'] ?? ''), '', true);
                if (self::$errore) { wp_safe_redirect(add_query_arg(array_merge($base, ['g' => $g, 'du' => $u, 'err' => rawurlencode('Non salvato: ' . self::$errore)]), self::url_gestione())); exit; }
                $torna($base + ['g' => $g, 'du' => $u], $n ? 'Giustificativo aggiunto' : 'Non aggiunto: mese chiuso, festivo o giorno di riposo');
            case 'g_modifica':
                $r = $wpdb->get_row($wpdb->prepare("SELECT * FROM $tab WHERE id=%d", (int)$p['id'])); $T = self::tipi();
                if ($r && isset($T[$p['tipo'] ?? '']) && !self::chiuso((int)substr($r->giorno, 0, 4), (int)substr($r->giorno, 5, 2))) {
                    $da = preg_match('/^\d\d:\d\d$/', $p['dalle'] ?? '') ? $p['dalle'] : null; $al = preg_match('/^\d\d:\d\d$/', $p['alle'] ?? '') ? $p['alle'] : null;
                    $ore = ($da && $al) ? round(max(0, self::min($al) - self::min($da)) / 60, 2) : (float)self::num($p['ore'] ?? $r->ore);
                    $wpdb->update($tab, ['tipo' => $p['tipo'], 'ore' => $ore, 'dalle' => $da, 'alle' => $al, 'nota' => sanitize_text_field($p['nota'] ?? '')], ['id' => $r->id]);
                }
                $torna($base + ['g' => $r ? $r->giorno : null, 'du' => $r ? $r->utente_id : null], 'Giustificativo modificato');
            case 'g_elimina':
                $r = $wpdb->get_row($wpdb->prepare("SELECT * FROM $tab WHERE id=%d", (int)$p['id']));
                if ($r && !self::chiuso((int)substr($r->giorno, 0, 4), (int)substr($r->giorno, 5, 2))) $wpdb->delete($tab, ['id' => $r->id]);
                $torna($base + ['g' => $r ? $r->giorno : null, 'du' => $r ? $r->utente_id : null], 'Giustificativo eliminato');
            case 'g_stato':
                $ids = array_filter(array_map('sanitize_text_field', (array)($p['gruppi'] ?? [])));
                $st = $p['stato'] === 'Approvato' ? 'Approvato' : 'Rifiutato';
                foreach ($ids as $gr) foreach ($wpdb->get_results($wpdb->prepare("SELECT utente_id, tipo, MIN(giorno) dal, MAX(giorno) al FROM $tab WHERE gruppo=%s AND stato='In attesa' AND creato_da=utente_id GROUP BY utente_id, tipo", $gr)) as $rq)
                    self::notifica($rq->utente_id, $st === 'Approvato' ? 'Richiesta approvata ✓' : 'Richiesta rifiutata', $rq->tipo . ' ' . self::periodo($rq->dal, $rq->al) . (!empty($p['nota']) ? ' · ' . sanitize_text_field($p['nota']) : ''), add_query_arg('sez', 'richieste', self::url_area()));
                foreach ($ids as $gr) $wpdb->update($tab, ['stato' => $st, 'nota_admin' => sanitize_text_field($p['nota'] ?? '')], ['gruppo' => $gr, 'stato' => 'In attesa']);
                $torna(['v' => 'presenze', 'tab' => 'richieste'], count($ids) === 1 ? ($st === 'Approvato' ? 'Richiesta approvata' : 'Richiesta rifiutata') : count($ids) . ($st === 'Approvato' ? ' richieste approvate' : ' richieste rifiutate'));
            case 'mese_chiudi':
                $k = sprintf('%04d-%02d', (int)$p['anno'], (int)$p['mese']); $c = (array)get_option('pdl_mesi_chiusi', []);
                $c = in_array($k, $c, true) ? array_values(array_diff($c, [$k])) : array_merge($c, [$k]);
                update_option('pdl_mesi_chiusi', $c);
                $torna($base, in_array($k, $c, true) ? 'Mese chiuso: non è più modificabile' : 'Mese riaperto');
            case 'bil_salva':
                $u = (int)$p['u'];
                $b = ['da' => preg_match('/^\d{4}-\d{2}$/', $p['da'] ?? '') ? $p['da'] : current_time('Y-m'), 'ini' => [], 'mat' => []];
                foreach (self::CONTI as $k => $l) { $b['ini'][$k] = (float)self::num($p['ini'][$k] ?? ''); $b['mat'][$k] = (float)self::num($p['mat'][$k] ?? ''); }
                update_user_meta($u, 'pdl_bil', wp_json_encode($b));
                if (!empty($p['c_ore']) && isset(self::CONTI[$p['c_conto'] ?? '']))
                    $wpdb->insert(self::t('correzioni'), ['utente_id' => $u, 'anno' => (int)substr($p['c_mese'], 0, 4), 'mese' => (int)substr($p['c_mese'], 5, 2), 'conto' => $p['c_conto'], 'ore' => self::num($p['c_ore']), 'nota' => sanitize_text_field($p['c_nota'] ?? ''), 'creato' => current_time('mysql')]);
                $torna(['v' => 'presenze', 'tab' => 'bilancio', 'anno' => (int)($p['anno'] ?? 0) ?: null, 'mese' => (int)($p['mese'] ?? 0) ?: null, 'bu' => $u], 'Bilancio aggiornato');
            case 'bil_da_buste':
                $n = 0;
                foreach ((array)json_decode(wp_unslash($p['dati'] ?? ''), true) as $r) {
                    $u = (int)($r['u'] ?? 0); $d = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . self::t('documenti') . " WHERE id=%d AND utente_id=%d AND tipo='busta'", (int)($r['id'] ?? 0), $u));
                    if (!$d || !is_array($r['v'] ?? null)) continue;
                    $b = self::bil_imp($u); $b['da'] = date('Y-m', strtotime(sprintf('%04d-%02d-01', $d->anno, $d->mese) . ' +1 month'));
                    foreach (['ferie', 'rol', 'exfs'] as $k) $b['ini'][$k] = round((float)($r['v'][$k] ?? 0), 2);
                    update_user_meta($u, 'pdl_bil', wp_json_encode($b)); update_user_meta($u, 'pdl_ratei_src', (int)$d->id); $n++;
                }
                $torna(['v' => 'presenze', 'tab' => 'bilancio'], $n ? "Bilancio aggiornato dalle buste paga ($n dipendenti)" : 'Nessun dato letto dalle buste paga');
            case 'corr_elimina':
                $wpdb->delete(self::t('correzioni'), ['id' => (int)$p['id']]);
                $torna(['v' => 'presenze', 'tab' => 'bilancio', 'bu' => (int)$p['u']], 'Correzione eliminata');
            case 'imp_salva':
                $fe = []; foreach (preg_split('/\r\n|\n/', (string)($p['festivi'] ?? '')) as $r) if (preg_match('/^\s*(\d{1,2})[\/.-](\d{1,2})\s*[-–:]?\s*(.*)$/', $r, $m)) $fe[sprintf('%02d-%02d', $m[2], $m[1])] = sanitize_text_field($m[3] ?: 'Festività');
                update_option('pdl_festivi_extra', $fe);
                $ex = []; foreach (preg_split('/\r\n|\n/', (string)($p['tipi'] ?? '')) as $r) { $r = trim($r); if (!$r) continue; $ore = (bool)preg_match('/\(ore\)\s*$/i', $r); $nome = sanitize_text_field(trim(preg_replace('/\(ore\)\s*$/i', '', $r))); if ($nome && !isset(self::TIPI[$nome])) $ex[$nome] = ['ore' => $ore]; }
                update_option('pdl_tipi_extra', $ex);
                $torna(['v' => 'presenze'], 'Impostazioni salvate');
        }
    }

    /* ---------- vista principale Presenze ---------- */
    static function v_presenze() {
        global $wpdb;
        $tab = sanitize_key($_GET['tab'] ?? 'calendario');
        $n = (int)$wpdb->get_var("SELECT COUNT(DISTINCT gruppo) FROM " . self::t('giust') . " WHERE stato='In attesa'" . self::in_az());
        echo '<div class="pg-head" style="border-bottom:0;padding-bottom:4px"><h1>Presenze</h1><div class="az"><button class="btn" data-apri="dr-imp"><svg viewBox="0 0 24 24"><path d="M19.4 13a7.6 7.6 0 0 0 0-2l2.1-1.6-2-3.5-2.5 1a7.4 7.4 0 0 0-1.7-1L15 3h-4l-.4 2.7a7.4 7.4 0 0 0-1.7 1l-2.5-1-2 3.5L6.6 11a7.6 7.6 0 0 0 0 2l-2.1 1.6 2 3.5 2.5-1a7.4 7.4 0 0 0 1.7 1L11 21h4l.4-2.7a7.4 7.4 0 0 0 1.7-1l2.5 1 2-3.5zM13 15.5A3.5 3.5 0 1 1 16.5 12 3.5 3.5 0 0 1 13 15.5z"/></svg>Impostazioni</button></div></div>';
        echo '<div class="pg-tabs">';
        foreach (['calendario' => 'Calendario', 'richieste' => 'Richieste' . ($n ? ' <span class="cnt">' . $n . '</span>' : ''), 'bilancio' => 'Bilancio'] as $k => $l) echo '<a class="' . ($tab === $k ? 'on' : '') . '" href="' . esc_url(self::link('presenze', ['tab' => $k === 'calendario' ? null : $k])) . '">' . $l . '</a>';
        echo '</div><div class="pg" style="max-width:none">';
        if ($tab === 'richieste') self::p_richieste(); elseif ($tab === 'bilancio') self::p_bilancio(); else self::p_calendario();
        echo '</div>';
        self::p_impostazioni();
    }

    static function p_css() {
        return '<style>.cnt{background:#e2e9f5;color:var(--blu);border-radius:3px;padding:0 6px;font-size:12px;margin-left:4px}
.calbox{background:#fff;border-radius:6px;box-shadow:0 1px 3px rgba(16,24,40,.08)}.calbar{display:flex;align-items:center;gap:10px;flex-wrap:wrap;padding:14px 16px}.calbar .sp{flex:1}
.ibtn{width:34px;height:34px;display:inline-flex;align-items:center;justify-content:center;border:1px solid var(--line);border-radius:4px;background:#fff;color:#3d4753;cursor:pointer;position:relative}.ibtn:hover{background:#f5f7fb}.ibtn.on{background:var(--blu-ch);color:var(--blu);border-color:#b9cff5}
.ibtn.verde{background:var(--verde);border-color:var(--verde);color:#fff}.ibtn[data-tip]:hover:after{content:attr(data-tip);position:absolute;top:-34px;right:0;background:#0f2a5c;color:#fff;font-size:12px;padding:5px 9px;border-radius:4px;white-space:nowrap;z-index:5}
.mesenav{display:inline-flex;align-items:center;gap:6px}.mesenav a,.mesenav span{height:34px;display:inline-flex;align-items:center;border:1px solid var(--line);border-radius:4px;padding:0 10px;color:var(--txt);background:#fff}.mesenav span{gap:6px;min-width:160px;justify-content:center}
.calscroll{overflow-x:auto}table.cal{border-collapse:collapse;width:100%;min-width:max-content}
table.cal th,table.cal td{border:1px solid #edf0f4;text-align:center;padding:0;font-size:12px}table.cal thead th{color:var(--mut);font-weight:400;padding:4px 0;min-width:31px;line-height:1.3}table.cal thead th b{display:block;color:#3d4753;font-weight:500}
table.cal th.oggi,table.cal td.oggi{background:#eef4fd}table.cal thead th.oggi b,table.cal thead th.oggi{color:var(--blu)}
table.cal .nm{text-align:left;padding:8px 12px;min-width:200px;font-size:14px;position:sticky;left:0;background:#fff;z-index:2;white-space:nowrap}table.cal thead .nm{font-weight:600;color:#3d4753;font-size:13px}
table.cal td.no{background:repeating-linear-gradient(135deg,#f6f7f9 0 4px,#eceff3 4px 5px)}table.cal td a.c{display:flex;flex-wrap:wrap;align-items:center;justify-content:center;gap:1px;min-height:37px;color:inherit}table.cal td a.c:hover{outline:2px solid var(--blu);outline-offset:-2px}
table.cal td .pend{border:1.5px dashed #6f8fc9;border-radius:4px;background:#eef3fc;padding:1px;display:inline-flex}body.evid table.cal td .pend{background:#ffe9a8;border-color:#d39b00}
table.cal.sett td a.c{min-height:74px;flex-direction:column;gap:3px;padding:4px}table.cal.sett thead th{min-width:120px}table.cal.sett .det{font-size:11px;color:#4a5562;line-height:1.25}
.leg{position:sticky;bottom:10px;margin:18px auto 0;width:max-content;max-width:100%;background:#fff;border:1px solid var(--line);border-radius:6px;padding:8px 16px;display:flex;gap:16px;flex-wrap:wrap;align-items:center;box-shadow:0 2px 10px rgba(0,0,0,.06)}.leg span{display:inline-flex;align-items:center;gap:5px;font-size:13px;color:var(--blu)}.leg b{color:var(--mut);font-weight:400}
.giorno-pan .riga{display:flex;align-items:center;justify-content:space-between;background:#f3f6fa;border-radius:4px;padding:12px 14px;margin:6px 0}.giorno-pan h3{display:flex;justify-content:space-between;align-items:center;font-size:18px;font-weight:500;margin:6px 0 10px}
.giorno-pan .gi{display:flex;align-items:center;gap:10px;background:#f3f6fa;border-radius:4px;padding:10px 12px;margin:6px 0}.giorno-pan .gi .t{flex:1}.giorno-pan .gi small{display:block;color:var(--mut)}
.req{background:#fff;border-bottom:1px solid var(--line);display:flex;gap:16px;align-items:center;padding:16px 18px;flex-wrap:wrap}.req .tx{flex:1;min-width:240px}.req .when{background:#f6f8fb;border:1px solid var(--line);border-radius:4px;padding:10px 14px;color:#3d4753;font-size:13px}.req .az{display:flex;flex-direction:column;gap:6px;width:150px}
.req .az .btn{justify-content:center}.btn.rosa{background:#fde8e7;border-color:#fde8e7;color:var(--rosso)}
.bil{width:100%;border-collapse:collapse;background:#fff;border-radius:6px;overflow:hidden;box-shadow:0 1px 3px rgba(16,24,40,.08)}.bil th,.bil td{padding:9px 12px;border-bottom:1px solid var(--line);text-align:center;font-size:13px}.bil th{font-weight:500;color:#3d4753}.bil td:first-child,.bil th:first-child{text-align:left}
.bil tr.det td{background:#eef4fd;font-size:12px;padding:5px 12px;color:#3d4753}.bil tr.det td:first-child{text-align:right;padding-right:30px}.bil .neg{color:var(--rosso)}.bil .tog{cursor:pointer;color:var(--blu);margin-left:6px;font-size:11px;border:0;background:#dbe7fb;border-radius:50%;width:18px;height:18px}
table.cal:not(.sett) thead th{min-width:46px;width:46px;font-size:12px;padding:6px 0}table.cal:not(.sett) thead th b{font-size:15px}table.cal:not(.sett) td{width:46px}table.cal:not(.sett) td a.c{min-height:58px;flex-direction:column;gap:2px;padding:3px 2px}table.cal .nm{font-size:15px;min-width:210px}
table.cal td .bdg{display:flex;flex-direction:column;align-items:center;justify-content:center;width:40px;min-height:40px;border-radius:6px;background:var(--c);color:#fff;line-height:1.05;padding:2px 0}table.cal td .bdg b{font-size:13px;font-weight:700}table.cal td .bdg i{font-style:normal;font-size:11px;opacity:.95}
table.cal td .bdg.pend{background:#fff;color:var(--c);border:2px dashed var(--c)}body.evid table.cal td .bdg.pend{background:#ffe9a8}table.cal tbody tr:nth-child(even) td.nm{background:#fafbfd}table.cal tbody tr:hover td{background-color:#f7faff}
.chips{display:flex;flex-wrap:wrap;gap:6px}.chips label{display:inline-flex;align-items:center;gap:6px;border:1px solid var(--line);border-radius:4px;padding:6px 10px;font-size:13px;cursor:pointer}.chips input{accent-color:var(--blu)}
</style>';
    }

    static function p_calendario() {
        $vista = ($_GET['vista'] ?? '') === 'settimanale' ? 'settimanale' : 'mensile';
        [$a, $m] = self::mese();
        if ($vista === 'settimanale') {
            $lun = self::d($_GET['sett'] ?? '') ?: date('Y-m-d', strtotime('monday this week', strtotime(current_time('Y-m-d'))));
            $lun = date('Y-m-d', strtotime('monday this week', strtotime($lun)));
            $giorni = []; for ($i = 0; $i < 7; $i++) $giorni[] = date('Y-m-d', strtotime("$lun +$i day"));
            $a = (int)substr($lun, 0, 4); $m = (int)substr($lun, 5, 2);
        } else $giorni = self::giorni($a, $m);
        $dip = self::dipendenti();
        $G = self::giust($giorni[0], end($giorni), wp_list_pluck($dip, 'ID'));
        $T = self::tipi(); $oggi = current_time('Y-m-d'); $chiuso = self::chiuso($a, $m);
        $gs = ['L', 'M', 'M', 'G', 'V', 'S', 'D']; $gl = ['lun', 'mar', 'mer', 'gio', 'ven', 'sab', 'dom'];
        $nav = $vista === 'settimanale'
            ? ['p' => ['vista' => 'settimanale', 'sett' => date('Y-m-d', strtotime("$lun -7 day"))], 'n' => ['vista' => 'settimanale', 'sett' => date('Y-m-d', strtotime("$lun +7 day"))], 't' => date_i18n('j M', strtotime($lun)) . ' – ' . date_i18n('j M Y', strtotime(end($giorni)))]
            : ['p' => ['anno' => $m === 1 ? $a - 1 : $a, 'mese' => $m === 1 ? 12 : $m - 1], 'n' => ['anno' => $m === 12 ? $a + 1 : $a, 'mese' => $m === 12 ? 1 : $m + 1], 't' => self::MESI[$m] . ' ' . $a];
        $stato_qs = $vista === 'settimanale' ? ['vista' => 'settimanale', 'sett' => $lun] : ['anno' => $a, 'mese' => $m];
        echo self::p_css() . '<div class="calbox"><div class="calbar"><div class="seg"><a class="' . ($vista === 'mensile' ? 'on' : '') . '" href="' . esc_url(self::link('presenze', ['anno' => $a, 'mese' => $m])) . '">Mensile</a><a class="' . ($vista === 'settimanale' ? 'on' : '') . '" href="' . esc_url(self::link('presenze', ['vista' => 'settimanale'])) . '">Settimanale</a></div>';
        echo '<span class="mut" style="font-size:13px">' . esc_html(self::az_nome()) . ' · ' . count($dip) . ' dipendenti</span><div class="sp"></div>';
        echo '<div class="mesenav"><a href="' . esc_url(self::link('presenze', $nav['p'])) . '">‹</a><span><svg viewBox="0 0 24 24" style="width:15px;height:15px;color:var(--mut)">' . self::ICONE['festa'] . '</svg>' . esc_html($nav['t']) . '</span><a href="' . esc_url(self::link('presenze', $nav['n'])) . '">›</a></div><div class="sp"></div>';
        echo '<form method="post" style="display:inline">' . self::nonce() . '<input type="hidden" name="pdl_act" value="mese_chiudi"><input type="hidden" name="anno" value="' . $a . '"><input type="hidden" name="mese" value="' . $m . '"><button class="ibtn' . ($chiuso ? ' on' : '') . '" data-tip="' . ($chiuso ? 'Mese chiuso: clicca per riaprire' : 'Mese modificabile: clicca per chiuderlo') . '" onclick="return confirm(\'' . ($chiuso ? 'Riaprire il mese?' : 'Chiudere il mese? Non si potranno più modificare i giustificativi.') . '\')"><svg viewBox="0 0 24 24"><path d="' . ($chiuso ? 'M18 8h-1V6a5 5 0 0 0-10 0v2H6a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V10a2 2 0 0 0-2-2zM9 6a3 3 0 0 1 6 0v2H9zm3 11a2 2 0 1 1 2-2 2 2 0 0 1-2 2z' : 'M18 8h-1V6a5 5 0 0 0-9.6-2l1.8.9A3 3 0 0 1 15 6v2H6a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V10a2 2 0 0 0-2-2zm-6 9a2 2 0 1 1 2-2 2 2 0 0 1-2 2z') . '"/></svg></button></form>';
        echo '<button class="ibtn" data-tip="Evidenzia i giustificativi da approvare" onclick="document.body.classList.toggle(\'evid\');this.classList.toggle(\'on\')"><svg viewBox="0 0 24 24"><path d="M6 2v6l4 4-4 4v6h12v-6l-4-4 4-4V2zm10 14.5V20H8v-3.5l4-4z"/></svg></button>';
        echo '<div class="pop"><button class="ibtn" data-menu data-tip="Filtra i giustificativi visibili"><svg viewBox="0 0 24 24"><path d="M3 17v2h6v-2zM3 5v2h10V5zm10 16v-2h8v-2h-8v-2h-2v6zM7 9v2H3v2h4v2h2V9zm14 4v-2H11v2zm-6-4h2V7h4V5h-4V3h-2z"/></svg></button><div class="pop-menu" style="padding:10px;min-width:280px" onclick="event.stopPropagation()"><b style="font-size:13px">Giustificativi visibili</b>';
        foreach ($T as $k => $t) echo '<label class="chk" style="padding:4px 0"><input type="checkbox" checked data-filtro="' . esc_attr(md5($k)) . '"> ' . self::ico($k, 16) . esc_html($k) . '</label>';
        echo '</div></div>';
        echo '<a class="ibtn" data-tip="Scarica il PDF per il commercialista" href="' . esc_url(wp_nonce_url(admin_url('admin-post.php?action=pdl_export&anno=' . $a . '&mese=' . $m), 'pdl_export')) . '"><svg viewBox="0 0 24 24"><path d="M5 20h14v-2H5zM19 9h-4V3H9v6H5l7 7z"/></svg></a>';
        echo '<button class="ibtn verde" data-apri="dr-multi" data-tip="Selezione multipla"><svg viewBox="0 0 24 24"><path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6z"/></svg></button></div>';
        echo '<div class="calscroll"><table class="cal' . ($vista === 'settimanale' ? ' sett' : '') . '"><thead><tr><th class="nm">' . esc_html(self::az_nome()) . '</th>';
        foreach ($giorni as $g) { $w = (int)date('N', strtotime($g)); echo '<th class="' . ($g === $oggi ? 'oggi' : '') . '">' . ($vista === 'settimanale' ? $gl[$w - 1] . ' ' : $gs[$w - 1] . '<b>') . date('d', strtotime($g)) . ($vista === 'settimanale' ? '' : '</b>') . '</th>'; }
        echo '</tr></thead><tbody>';
        $usati = [];
        foreach ($dip as $u) {
            echo '<tr><td class="nm"><span class="chi"><span class="av" style="width:26px;height:26px;font-size:10px">' . self::iniziali($u) . '</span>' . self::nome($u) . '</span></td>';
            foreach ($giorni as $g) {
                $L = $G[$u->ID][$g] ?? []; $fest = self::festivo($g); $oc = self::ore_contratto($u->ID, $g);
                $cl = []; if ($g === $oggi) $cl[] = 'oggi'; if (!$oc && !$fest) $cl[] = 'no';
                $ic = '';
                if ($fest) $ic .= '<span title="' . esc_attr($fest) . '"><svg viewBox="0 0 24 24" style="width:17px;height:17px;color:#16a34a">' . self::ICONE['festa'] . '</svg></span>';
                if ($vista !== 'settimanale') { $agg = [];
                    foreach ($L as $x) { $usati[$x->tipo] = 1; $agg[$x->tipo]['o'] = ($agg[$x->tipo]['o'] ?? 0) + (float)$x->ore; if ($x->stato === 'In attesa') $agg[$x->tipo]['p'] = 1; }
                    foreach ($agg as $tp => $v) { $tt = $T[$tp] ?? ['?', '#64748b'];
                        $ic .= '<span class="bdg' . (!empty($v['p']) ? ' pend' : '') . '" data-t="' . esc_attr(md5($tp)) . '" style="--c:' . $tt[1] . '" title="' . esc_attr($tp . ' · ' . self::ore_fmt($v['o']) . (!empty($v['p']) ? ' · da approvare' : '')) . '"><b>' . esc_html($tt[0]) . '</b>' . ($v['o'] ? '<i>' . esc_html(rtrim(rtrim(number_format($v['o'], 2, ',', ''), '0'), ',')) . 'h</i>' : '') . '</span>'; }
                    $L = []; }
                foreach ($L as $x) { $usati[$x->tipo] = 1; $i = self::ico($x->tipo, 17);
                    $ic .= '<span data-t="' . esc_attr(md5($x->tipo)) . '"' . ($x->stato === 'In attesa' ? ' class="pend" title="Da approvare"' : '') . '>' . $i . ($vista === 'settimanale' ? '' : '') . '</span>';
                    if ($vista === 'settimanale') $ic .= '<span class="det" data-t="' . esc_attr(md5($x->tipo)) . '">' . esc_html($x->tipo) . ($x->dalle ? ' ' . substr($x->dalle, 0, 5) . '–' . substr($x->alle, 0, 5) : ' ' . self::ore_fmt($x->ore)) . '</span>'; }
                if ($vista === 'settimanale') { $pr = self::presenza($u->ID, $g, $L); $ic .= '<span class="det" style="color:var(--mut)">' . ($fest ? esc_html($fest) : ($oc ? 'Presenza ' . self::ore_fmt($pr) : 'Non lavorativo')) . '</span>'; }
                echo '<td class="' . implode(' ', $cl) . '"><a class="c" draggable="false" data-u="' . $u->ID . '" data-g="' . $g . '" href="' . esc_url(self::link('presenze', $stato_qs + ['g' => $g, 'du' => $u->ID])) . '">' . $ic . '</a></td>';
            }
            echo '</tr>';
        }
        if (!$dip) echo '<tr><td class="nm" colspan="40">Nessun dipendente attivo.</td></tr>';
        echo '</tbody></table></div></div>';
        echo '<div class="leg"><b>Legenda</b><span><svg viewBox="0 0 24 24" style="width:16px;height:16px;color:#16a34a">' . self::ICONE['festa'] . '</svg>Festivo</span>';
        foreach (array_keys($usati) as $k) echo '<span><i style="background:' . ($T[$k][1] ?? '#64748b') . ';color:#fff;font-style:normal;font-weight:700;font-size:11px;border-radius:4px;padding:2px 5px">' . esc_html($T[$k][0] ?? '?') . '</i>' . esc_html($k) . '</span>';
        echo '<span><i class="pend" style="border:1.5px dashed #6f8fc9;border-radius:3px;width:14px;height:14px;display:inline-block"></i>Da approvare</span></div>';
        echo '<script>document.querySelectorAll("[data-filtro]").forEach(function(c){c.addEventListener("change",function(){document.querySelectorAll("[data-t=\'"+c.dataset.filtro+"\']").forEach(function(e){e.style.display=c.checked?"":"none";});});});</script>';
        echo '<p class="mut" style="font-size:13px;text-align:center;margin-top:10px">Clicca un giorno per i dettagli, oppure <b>tieni premuto e trascina</b> su più giorni (anche su più dipendenti) per segnarli tutti insieme.</p>';
        echo '<style>table.cal td.sel{background:#cfe0fb!important;outline:2px solid var(--blu);outline-offset:-2px}#selbar{position:fixed;left:50%;bottom:16px;transform:translateX(-50%);z-index:70;background:#fff;border:1px solid #b9cff5;border-radius:10px;box-shadow:0 10px 30px rgba(16,24,40,.2);padding:12px 16px;display:none;width:min(860px,94vw)}#selbar.on{display:block}#selbar .riga{display:flex;gap:10px;align-items:flex-end;flex-wrap:wrap}#selbar .campo{margin:0;min-width:160px;flex:1}#selbar .campo label{font-size:12px}table.cal{user-select:none}</style>';
        echo '<form method="post" id="selbar">' . self::nonce() . '<input type="hidden" name="pdl_act" value="g_sel"><input type="hidden" name="modo" value="aggiungi">';
        foreach ($stato_qs as $k => $v) echo '<input type="hidden" name="' . esc_attr($k) . '" value="' . esc_attr($v) . '">';
        echo '<div id="sel-hid"></div><div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px"><b id="sel-n" style="color:var(--blu)"></b><a href="#" id="sel-x" class="mut">✕ Annulla selezione</a></div><div class="riga">' . self::form_tipo() . '<div class="campo"><label>Nota</label><input class="inp" name="nota"></div>'
           . '<button class="btn blu" style="height:38px">Applica</button><button class="btn rosso" style="height:38px" onclick="this.form.modo.value=\'elimina\';var t=this.form.querySelector(\'.sel-tipo\');t.required=false;return confirm(\'Eliminare tutti i giustificativi dei giorni selezionati?\')">Svuota giorni</button></div></form>' . self::js_tipo();
        echo '<script>(function(){var bar=document.getElementById("selbar"),hid=document.getElementById("sel-hid"),giu=false,start=null,mosso=false,sel=[];
var celle=[].slice.call(document.querySelectorAll("table.cal a.c"));
function pos(a){var td=a.parentNode,tr=td.parentNode;return{r:[].indexOf.call(tr.parentNode.children,tr),c:[].indexOf.call(tr.children,td)};}
function pulisci(){celle.forEach(function(a){a.parentNode.classList.remove("sel");});}
function area(a,b){var p=pos(a),q=pos(b),r1=Math.min(p.r,q.r),r2=Math.max(p.r,q.r),c1=Math.min(p.c,q.c),c2=Math.max(p.c,q.c);pulisci();sel=[];
 celle.forEach(function(x){var z=pos(x);if(z.r>=r1&&z.r<=r2&&z.c>=c1&&z.c<=c2){x.parentNode.classList.add("sel");sel.push(x);}});}
celle.forEach(function(a){a.addEventListener("mousedown",function(e){if(e.button!==0)return;e.preventDefault();bar.classList.remove("on");giu=true;mosso=false;start=a;area(a,a);});
 a.addEventListener("mouseenter",function(){if(giu&&start){if(a!==start)mosso=true;area(start,a);}});
 a.addEventListener("click",function(e){if(mosso||bar.classList.contains("on")){e.preventDefault();}});});
document.addEventListener("mouseup",function(){if(!giu)return;giu=false;
 if(mosso&&sel.length>1){hid.innerHTML="";sel.forEach(function(x){var i=document.createElement("input");i.type="hidden";i.name="sel[]";i.value=x.dataset.u+"|"+x.dataset.g;hid.appendChild(i);});
  document.getElementById("sel-n").textContent=sel.length+" giorni selezionati";bar.classList.add("on");bar.modo.value="aggiungi";bar.querySelector(".sel-tipo").required=true;}
 else if(!bar.classList.contains("on")){pulisci();sel=[];}});
document.getElementById("sel-x").addEventListener("click",function(e){e.preventDefault();bar.classList.remove("on");pulisci();sel=[];mosso=false;});
})();</script>';
        self::p_giorno($stato_qs);
        self::p_multi($a, $m, $stato_qs);
    }

    static function form_tipo($nome_prefix = '') {
        $T = self::tipi(); $o = '<option value="">Seleziona un\'opzione</option>';
        $prot = '<div class="campo campo-prot" style="display:none"><label>N. protocollo certificato di malattia</label><input class="inp" name="protocollo" placeholder="es. 123456789"></div>';
        foreach ($T as $k => $t) $o .= '<option value="' . esc_attr($k) . '" data-ore="' . ($t[2] ? 1 : 0) . '">' . esc_html($k) . '</option>';
        return '<div class="campo"><label>Giustificativo <i>*</i></label><select class="inp sel-tipo" name="tipo" required>' . $o . '</select></div>'
             . '<div class="griglia campi-ore" style="grid-template-columns:1fr 1fr 1fr;display:none"><div class="campo"><label>Dalle</label><input class="inp" type="time" name="dalle"></div><div class="campo"><label>Alle</label><input class="inp" type="time" name="alle"></div><div class="campo"><label>oppure ore</label><input class="inp" name="ore" placeholder="vuoto = giornata intera"></div></div>' . $prot;
    }
    static function js_tipo() {
        return '<script>document.querySelectorAll(".sel-tipo").forEach(function(s){function f(){var o=s.options[s.selectedIndex],b=s.closest("form").querySelector(".campi-ore");if(b)b.style.display=o&&o.value?"grid":"none";var pr=s.closest("form").querySelector(".campo-prot");if(pr)pr.style.display=o&&/^Malattia/.test(o.value)?"":"none";}s.addEventListener("change",f);f();});</script>';
    }

    static function p_giorno($stato_qs) {
        $g = self::d($_GET['g'] ?? ''); $uid = (int)($_GET['du'] ?? 0); $u = get_userdata($uid);
        if (!$g || !$u) return;
        $L = self::giust($g, $g, [$uid], ['Approvato', 'In attesa'])[$uid][$g] ?? [];
        $orari = self::orari($uid)[(int)date('N', strtotime($g))] ?? []; $fest = self::festivo($g);
        $chiudi = esc_url(self::link('presenze', $stato_qs));
        $prec = date('Y-m-d', strtotime("$g -1 day")); $succ = date('Y-m-d', strtotime("$g +1 day"));
        $ch = self::chiuso((int)substr($g, 0, 4), (int)substr($g, 5, 2));
        echo '<div class="drawer on giorno-pan"><a class="ombra" href="' . $chiudi . '"></a><div class="pan"><div class="ph" style="align-items:flex-start"><div><b style="font-size:16px">' . esc_html(ucfirst(date_i18n('l j F Y', strtotime($g)))) . '</b><div class="chi" style="margin-top:6px"><span class="av" style="width:24px;height:24px;font-size:10px">' . self::iniziali($u) . '</span>' . esc_html(trim($u->first_name . ' ' . $u->last_name)) . '</div><small class="mut"><i>Orario contratto: ' . esc_html(self::m($u, 'orario') ?: 'Fisso') . '</i></small></div><a href="' . $chiudi . '">×</a></div><div class="pc">';
        echo '<h3>Presenza <span>' . self::ore_fmt(self::presenza($uid, $g, $L)) . '</span></h3>';
        if ($fest) echo '<div class="riga"><span>Festività</span><b>' . esc_html($fest) . '</b></div>';
        elseif (!$orari) echo '<div class="riga"><span class="mut">Giorno non lavorativo</span></div>';
        else foreach ($orari as $s) echo '<div class="riga"><span>Orario di lavoro</span><span>' . esc_html($s[0] . ' - ' . $s[1]) . '</span></div>';
        echo '<h3 style="margin-top:22px;border-top:1px solid var(--line);padding-top:16px">Giustificativi ' . ($ch ? '<span class="stato grigio">Mese chiuso</span>' : '<button class="ibtn verde" style="background:var(--blu);border-color:var(--blu)" onclick="document.getElementById(\'g-nuovo\').style.display=\'block\';this.style.display=\'none\'">+</button>') . '</h3>';
        echo '<form method="post" id="g-nuovo" style="display:none;background:#f7f9fc;border:1px solid var(--line);border-radius:6px;padding:14px;margin-bottom:10px">' . self::nonce() . '<input type="hidden" name="pdl_act" value="g_giorno"><input type="hidden" name="u" value="' . $uid . '"><input type="hidden" name="g" value="' . $g . '">';
        foreach ($stato_qs as $k => $v) echo '<input type="hidden" name="' . esc_attr($k) . '" value="' . esc_attr($v) . '">';
        echo '<b style="color:var(--blu)">Aggiungi nuovo giustificativo</b>' . self::form_tipo() . '<div class="campo"><label>Nota</label><input class="inp" name="nota"></div><p style="font-size:13px"><a href="#" data-apri="dr-imp">+ Aggiungi nuovi giustificativi alla lista</a></p><div style="display:flex;justify-content:flex-end;gap:8px"><button type="button" class="btn" onclick="this.closest(\'form\').style.display=\'none\'">↺ Annulla</button><button class="btn verde">Conferma</button></div></form>' . self::js_tipo();
        if (!$L) echo '<div class="riga mut" style="font-size:13px">Nessun giustificativo per questo giorno</div>';
        foreach ($L as $x) {
            $protf = strpos($x->tipo, 'Malattia') === 0 ? '<form method="post" style="display:flex;gap:6px;margin-top:6px">' . self::nonce() . '<input type="hidden" name="pdl_act" value="g_protocollo"><input type="hidden" name="id" value="' . $x->id . '">' . implode('', array_map(function ($k, $v) { return '<input type="hidden" name="' . esc_attr($k) . '" value="' . esc_attr($v) . '">'; }, array_keys($stato_qs), $stato_qs)) . '<input class="inp" name="protocollo" value="' . esc_attr($x->protocollo ?? '') . '" placeholder="N. protocollo certificato" style="height:30px;font-size:13px"><button class="btn pic">Salva</button></form>' : '';
            echo '<div class="gi" style="flex-wrap:wrap">' . self::ico($x->tipo, 22) . '<div class="t"><b>' . esc_html($x->tipo) . '</b>' . ($x->stato === 'In attesa' ? ' <span class="stato att">Da approvare</span>' : '') . '<small>' . ($x->dalle ? 'dalle ' . substr($x->dalle, 0, 5) . ' alle ' . substr($x->alle, 0, 5) . ' · ' : '') . self::ore_fmt($x->ore) . ($x->nota ? ' · ' . esc_html($x->nota) : '') . '</small>' . $protf . '</div>';
            if (!$ch) { echo '<form method="post" onsubmit="return confirm(\'Eliminare il giustificativo?\')">' . self::nonce() . '<input type="hidden" name="pdl_act" value="g_elimina"><input type="hidden" name="id" value="' . $x->id . '">';
                foreach ($stato_qs as $k => $v) echo '<input type="hidden" name="' . esc_attr($k) . '" value="' . esc_attr($v) . '">';
                echo '<button class="btn pic rosso" title="Elimina">🗑</button></form>';
                echo '<button type="button" class="btn pic" title="Modifica" onclick="var f=this.parentNode.querySelector(\'.gmod\');f.style.display=f.style.display===\'flex\'?\'none\':\'flex\'">✎</button>';
                $opt = ''; foreach (self::tipi() as $k => $t) $opt .= '<option' . selected($k, $x->tipo, false) . '>' . esc_html($k) . '</option>';
                echo '<form method="post" class="gmod" style="display:none;flex-wrap:wrap;gap:8px;align-items:flex-end;width:100%;margin-top:8px;padding-top:8px;border-top:1px solid var(--line)">' . self::nonce() . '<input type="hidden" name="pdl_act" value="g_modifica"><input type="hidden" name="id" value="' . $x->id . '">';
                foreach ($stato_qs as $k => $v) echo '<input type="hidden" name="' . esc_attr($k) . '" value="' . esc_attr($v) . '">';
                echo '<div class="campo" style="margin:0;flex:2;min-width:140px"><label>Tipo</label><select class="inp" name="tipo">' . $opt . '</select></div><div class="campo" style="margin:0;flex:1;min-width:80px"><label>Ore</label><input class="inp" name="ore" inputmode="decimal" value="' . esc_attr(str_replace('.', ',', (float)$x->ore)) . '"></div><div class="campo" style="margin:0;flex:1;min-width:90px"><label>Dalle</label><input class="inp" type="time" name="dalle" value="' . esc_attr(substr((string)$x->dalle, 0, 5)) . '"></div><div class="campo" style="margin:0;flex:1;min-width:90px"><label>Alle</label><input class="inp" type="time" name="alle" value="' . esc_attr(substr((string)$x->alle, 0, 5)) . '"></div><div class="campo" style="margin:0;flex:2;min-width:140px"><label>Nota</label><input class="inp" name="nota" value="' . esc_attr($x->nota) . '"></div><button class="btn verde">Salva</button></form>'; }
            echo '</div>';
        }
        echo '</div><div class="pf" style="justify-content:space-between"><a href="' . esc_url(self::link('presenze', $stato_qs + ['g' => $prec, 'du' => $uid])) . '">‹ Giorno precedente</a><a href="' . esc_url(self::link('presenze', $stato_qs + ['g' => $succ, 'du' => $uid])) . '">Giorno successivo ›</a></div></div></div>';
    }

    static function p_multi($a, $m, $stato_qs) {
        echo '<div class="drawer" id="dr-multi"><div class="ombra" data-chiudi></div><form class="pan" method="post">' . self::nonce() . '<input type="hidden" name="pdl_act" value="g_multi">';
        foreach ($stato_qs as $k => $v) echo '<input type="hidden" name="' . esc_attr($k) . '" value="' . esc_attr($v) . '">';
        echo '<div class="ph"><h2>Selezione multipla</h2><a href="#" data-chiudi>×</a></div><div class="pc"><div class="campo"><label>Dipendenti <i>*</i></label><div class="chips"><label><input type="checkbox" onclick="var c=this.checked;this.closest(\'.chips\').querySelectorAll(\'[name=&quot;dip[]&quot;]\').forEach(function(x){x.checked=c})"> <b>Tutti</b></label>';
        foreach (self::dipendenti() as $u) echo '<label><input type="checkbox" name="dip[]" value="' . $u->ID . '"> ' . self::nome($u) . '</label>';
        echo '</div></div><div style="background:#f7f9fc;border:1px solid var(--line);border-radius:6px;padding:14px;margin-bottom:14px"><div style="text-align:center;margin-bottom:12px"><div class="seg"><a href="#" class="on" data-modo="aggiungi">Aggiungi</a><a href="#" data-modo="elimina">Elimina</a></div></div><input type="hidden" name="modo" value="aggiungi">' . self::form_tipo() . '</div>';
        echo '<div class="campo"><label class="chk"><input type="checkbox" name="piu" value="1" onchange="var f=this.closest(\'form\');f.querySelector(\'.g1\').style.display=this.checked?\'none\':\'\';f.querySelector(\'.g2\').style.display=this.checked?\'grid\':\'none\'"> Applica per più giorni</label></div>';
        echo '<div class="campo g1"><label>Data <i>*</i></label><input class="inp" type="date" name="data" value="' . esc_attr(sprintf('%04d-%02d-%02d', $a, $m, min((int)current_time('j'), 28))) . '"></div><div class="griglia g2" style="grid-template-columns:1fr 1fr;display:none"><div class="campo"><label>Dal</label><input class="inp" type="date" name="dal"></div><div class="campo"><label>Al</label><input class="inp" type="date" name="al"></div></div>';
        echo '<div class="campo"><label>Nota</label><input class="inp" name="nota"></div><p class="mut" style="font-size:13px">Nei periodi di più giorni vengono saltati festivi e giorni non lavorativi del contratto.</p></div><div class="pf"><a class="btn" href="#" data-chiudi>↺ Annulla</a><button class="btn blu">Salva</button></div></form></div>';
        echo '<script>document.querySelectorAll("#dr-multi [data-modo]").forEach(function(a){a.addEventListener("click",function(e){e.preventDefault();var f=a.closest("form");f.querySelectorAll("[data-modo]").forEach(function(x){x.classList.toggle("on",x===a)});f.querySelector("[name=modo]").value=a.dataset.modo;f.querySelector(".sel-tipo").required=a.dataset.modo==="aggiungi";});});</script>' . self::js_tipo();
    }

    /* ---------- richieste ---------- */
    static function gruppi_richieste($stato = 'In attesa', $uid = 0) {
        global $wpdb;
        $q = $wpdb->prepare("SELECT gruppo, utente_id, tipo, MIN(giorno) dal, MAX(giorno) al, SUM(ore) ore, COUNT(*) n, MIN(dalle) dalle, MAX(alle) alle, MIN(creato) creato, MAX(nota) nota, MAX(stato) stato, MAX(nota_admin) nota_admin FROM " . self::t('giust') . " WHERE stato=%s", $stato);
        if ($uid) $q .= $wpdb->prepare(' AND utente_id=%d', $uid); else $q .= self::in_az();
        return $wpdb->get_results($q . ' GROUP BY gruppo, utente_id, tipo');
    }
    static function frase_richiesta($r, $chi = true) {
        $u = get_userdata($r->utente_id);
        $per = $r->dal === $r->al ? 'per <b>' . esc_html(date_i18n('l j F Y', strtotime($r->dal))) . '</b>' : 'dal <b>' . esc_html(date_i18n('j F', strtotime($r->dal))) . '</b> al <b>' . esc_html(date_i18n('j F Y', strtotime($r->al))) . '</b> (' . (int)$r->n . ' giorni)';
        return ($chi ? '<b>' . ($u ? esc_html(trim($u->first_name . ' ' . $u->last_name)) : '—') . '</b> ha richiesto ' : 'Hai richiesto ') . '<b>' . self::ore_fmt($r->ore) . '</b> di <b>' . esc_html($r->tipo) . '</b><br>' . $per . ($r->dalle ? ' dalle <b>' . substr($r->dalle, 0, 5) . '</b> alle <b>' . substr($r->alle, 0, 5) . '</b>' : '') . ($r->nota ? '<br><small class="mut">“' . esc_html($r->nota) . '”</small>' : '');
    }
    static function p_richieste() {
        echo self::p_css();
        $fu = (int)($_GET['fu'] ?? 0); $ord = ($_GET['ord'] ?? '') === 'richiesta' ? 'richiesta' : 'competenza';
        $R = self::gruppi_richieste('In attesa', $fu);
        usort($R, function ($a, $b) use ($ord) { return $ord === 'richiesta' ? strcmp($a->creato, $b->creato) : strcmp($a->dal, $b->dal); });
        echo '<form method="get" class="barra" style="margin-top:0;justify-content:flex-end"><input type="hidden" name="v" value="presenze"><input type="hidden" name="tab" value="richieste"><div class="campo" style="width:260px"><label>Filtra per dipendenti</label><select class="inp" name="fu" onchange="this.form.submit()"><option value="">Tutti</option>';
        foreach (self::dipendenti() as $u) echo '<option value="' . $u->ID . '"' . selected($fu, $u->ID, false) . '>' . self::nome($u) . '</option>';
        echo '</select></div><div class="campo" style="width:260px"><label>Ordina per</label><select class="inp" name="ord" onchange="this.form.submit()"><option value="competenza">Data di competenza ▲</option><option value="richiesta"' . selected($ord, 'richiesta', false) . '>Data della richiesta ▲</option></select></div></form>';
        echo '<div class="calbox">';
        if (!$R) { echo '<div class="vuoto"><div class="ill"><svg viewBox="0 0 24 24">' . self::ICONE['ombrellone'] . '</svg></div><h3>Nessuna richiesta da gestire</h3><p>Quando un dipendente chiede ferie o permessi dalla sua area, la richiesta compare qui.</p></div></div>'; return; }
        $tutti = ''; foreach ($R as $r) $tutti .= '<input type="hidden" name="gruppi[]" value="' . esc_attr($r->gruppo) . '">';
        echo '<div style="display:flex;justify-content:flex-end;gap:8px;padding:12px 16px;border-bottom:1px solid var(--line)">';
        foreach (['Rifiutato' => ['✕ Rifiuta', 'rifiutare'], 'Approvato' => ['✓ Approva', 'approvare']] as $st => $l)
            echo '<form method="post" onsubmit="return confirm(\'Vuoi ' . $l[1] . ' tutte le ' . count($R) . ' richieste?\')">' . self::nonce() . '<input type="hidden" name="pdl_act" value="g_stato"><input type="hidden" name="stato" value="' . $st . '">' . $tutti . '<button class="btn">' . $l[0] . ' ' . count($R) . ' richiest' . (count($R) === 1 ? 'a' : 'e') . '</button></form>';
        echo '</div>';
        foreach ($R as $r) {
            $ant = (int)floor((strtotime($r->dal) - strtotime(substr($r->creato, 0, 10))) / DAY_IN_SECONDS);
            echo '<div class="req"><span class="av" style="width:30px;height:30px;font-size:11px">' . (get_userdata($r->utente_id) ? self::iniziali(get_userdata($r->utente_id)) : '') . '</span><div class="tx">' . self::frase_richiesta($r) . '</div>'
               . '<div class="when">🕓 Richiesto il ' . esc_html(date_i18n('j M Y', strtotime($r->creato))) . ' con <b>' . ($ant < 0 ? abs($ant) . ' giorni di ritardo' : $ant . ' giorn' . ($ant === 1 ? 'o' : 'i') . ' di anticipo') . '</b></div>'
               . '<div class="az"><form method="post">' . self::nonce() . '<input type="hidden" name="pdl_act" value="g_stato"><input type="hidden" name="stato" value="Approvato"><input type="hidden" name="gruppi[]" value="' . esc_attr($r->gruppo) . '"><button class="btn verde" style="width:100%">Approva</button></form>'
               . '<form method="post" onsubmit="var n=prompt(\'Motivo del rifiuto (facoltativo)\',\'\');if(n===null)return false;this.nota.value=n;">' . self::nonce() . '<input type="hidden" name="pdl_act" value="g_stato"><input type="hidden" name="stato" value="Rifiutato"><input type="hidden" name="nota"><input type="hidden" name="gruppi[]" value="' . esc_attr($r->gruppo) . '"><button class="btn rosa" style="width:100%">Rifiuta</button></form></div></div>';
        }
        echo '</div>';
    }

    /* ---------- bilancio ---------- */
    static function bil_imp($uid) {
        $b = json_decode((string)get_user_meta($uid, 'pdl_bil', true), true) ?: [];
        $b += ['da' => current_time('Y') . '-01', 'ini' => [], 'mat' => []];
        foreach (self::CONTI as $k => $l) { $b['ini'][$k] = (float)($b['ini'][$k] ?? 0); $b['mat'][$k] = (float)($b['mat'][$k] ?? 0); }
        return $b;
    }
    /** Calcola il bilancio di un dipendente per il periodo [da_mese, a_mese] (formato YYYY-MM) */
    static function bilancio($uid, $p_da, $p_a) {
        global $wpdb;
        $b = self::bil_imp($uid); $T = self::tipi(); $out = [];
        $god = []; foreach ($wpdb->get_results($wpdb->prepare("SELECT DATE_FORMAT(giorno,'%%Y-%%m') m, tipo, SUM(ore) o FROM " . self::t('giust') . " WHERE utente_id=%d AND stato='Approvato' AND giorno>=%s GROUP BY m, tipo", $uid, $b['da'] . '-01')) as $r) { $c = $T[$r->tipo][3] ?? ''; if ($c) $god[$r->m][$c] = ($god[$r->m][$c] ?? 0) + (float)$r->o; }
        $cor = []; foreach ($wpdb->get_results($wpdb->prepare("SELECT anno, mese, conto, SUM(ore) o FROM " . self::t('correzioni') . " WHERE utente_id=%d GROUP BY anno, mese, conto", $uid)) as $r) $cor[sprintf('%04d-%02d', $r->anno, $r->mese)][$r->conto] = (float)$r->o;
        foreach (self::CONTI as $k => $l) {
            $saldo = $b['ini'][$k]; $res = null; $mat = $go = $co = 0;
            for ($mm = $b['da']; $mm <= $p_a; $mm = date('Y-m', strtotime($mm . '-01 +1 month'))) {
                if ($mm === $p_da || ($res === null && $mm > $p_da)) $res = $saldo;
                $dm = $b['mat'][$k]; $dg = $god[$mm][$k] ?? 0; $dc = $cor[$mm][$k] ?? 0;
                if ($mm >= $p_da) { $mat += $dm; $go += $dg; $co += $dc; }
                $saldo += $dm - $dg + $dc;
            }
            if ($res === null) $res = $p_a < $b['da'] ? 0 : $saldo;
            $out[$k] = ['residuo' => round($res, 2), 'maturato' => round($mat, 2), 'goduto' => round($go, 2), 'correzioni' => round($co, 2), 'bilancio' => round($p_a < $b['da'] ? 0 : $saldo, 2)];
        }
        return $out;
    }
    static function p_bilancio() {
        global $wpdb;
        echo self::p_css();
        [$a, $m] = self::mese(); $ann = ($_GET['per'] ?? '') === 'annuale';
        $mis = sanitize_key($_GET['mis'] ?? 'bilancio'); $misure = ['residuo' => 'Residuo mese precedente', 'bilancio' => 'Residuo mese corrente', 'goduto' => 'Goduto', 'correzioni' => 'Correzioni', 'maturato' => 'Maturazioni'];
        if (!isset($misure[$mis])) $mis = 'bilancio';
        $pda = $ann ? "$a-01" : sprintf('%04d-%02d', $a, $m); $pa = $ann ? "$a-12" : $pda;
        $qs = ['tab' => 'bilancio', 'per' => $ann ? 'annuale' : null, 'mis' => $mis];
        $prev = $ann ? ['anno' => $a - 1] : ['anno' => $m === 1 ? $a - 1 : $a, 'mese' => $m === 1 ? 12 : $m - 1]; $next = $ann ? ['anno' => $a + 1] : ['anno' => $m === 12 ? $a + 1 : $a, 'mese' => $m === 12 ? 1 : $m + 1];
        echo '<div class="calbox"><form class="calbar" method="get"><input type="hidden" name="v" value="presenze"><input type="hidden" name="tab" value="bilancio"><input type="hidden" name="anno" value="' . $a . '"><input type="hidden" name="mese" value="' . $m . '">' . ($ann ? '<input type="hidden" name="per" value="annuale">' : '')
           . '<div class="seg"><a class="' . (!$ann ? 'on' : '') . '" href="' . esc_url(self::link('presenze', ['tab' => 'bilancio', 'anno' => $a, 'mese' => $m, 'mis' => $mis])) . '">Mensile</a><a class="' . ($ann ? 'on' : '') . '" href="' . esc_url(self::link('presenze', ['tab' => 'bilancio', 'anno' => $a, 'mese' => $m, 'per' => 'annuale', 'mis' => $mis])) . '">Annuale</a></div><div class="sp"></div>'
           . '<div class="mesenav"><a href="' . esc_url(self::link('presenze', $qs + $prev)) . '">‹</a><span>' . ($ann ? $a : self::MESI[$m] . ' ' . $a) . '</span><a href="' . esc_url(self::link('presenze', $qs + $next)) . '">›</a></div><div class="sp"></div>'
           . '<select class="inp" name="mis" style="width:230px" onchange="this.form.submit()">';
        foreach ($misure as $k => $l) echo '<option value="' . $k . '"' . selected($mis, $k, false) . '>' . $l . '</option>';
        echo '</select></form><table class="bil"><thead><tr><th>Dipendente <button type="button" class="tog" onclick="document.querySelectorAll(\'.bil tr.det\').forEach(function(r){r.hidden=!r.hidden})" title="Espandi dettagli">▾</button></th>';
        foreach (self::CONTI as $k => $l) echo '<th>' . $l . '</th>';
        echo '<th></th></tr></thead><tbody>';
        $bu = (int)($_GET['bu'] ?? 0);
        foreach (self::dipendenti() as $u) {
            $B = self::bilancio($u->ID, $pda, $pa);
            echo '<tr><td><span class="chi"><span class="av" style="width:26px;height:26px;font-size:10px">' . self::iniziali($u) . '</span>' . self::nome($u) . '<button type="button" class="tog" onclick="var r=this.closest(\'tr\').nextElementSibling;for(var i=0;i<5;i++){r.hidden=!r.hidden;r=r.nextElementSibling;}">▾</button></span></td>';
            foreach (self::CONTI as $k => $l) echo '<td class="' . ($B[$k][$mis] < 0 ? 'neg' : '') . '">' . self::ore_fmt($B[$k][$mis]) . '</td>';
            echo '<td><a href="' . esc_url(self::link('presenze', ['tab' => 'bilancio', 'anno' => $a, 'mese' => $m, 'bu' => $u->ID])) . '">Imposta</a></td></tr>';
            foreach (['residuo' => 'Residuo', 'maturato' => 'Maturato', 'goduto' => 'Goduto', 'correzioni' => 'Correzioni', 'bilancio' => 'Bilancio'] as $kk => $ll) {
                echo '<tr class="det" hidden><td>' . $ll . '</td>';
                foreach (self::CONTI as $k => $l) echo '<td class="' . ($B[$k][$kk] < 0 ? 'neg' : '') . '">' . ($kk === 'goduto' && $B[$k][$kk] ? '-' : '') . self::ore_fmt($B[$k][$kk]) . '</td>';
                echo '<td></td></tr>';
            }
        }
        $da_agg = [];
        foreach (self::dipendenti() as $u) {
            $d = $wpdb->get_row($wpdb->prepare("SELECT id, anno, mese FROM " . self::t('documenti') . " WHERE tipo='busta' AND utente_id=%d AND mese BETWEEN 1 AND 12 ORDER BY anno DESC, mese DESC, id DESC LIMIT 1", $u->ID));
            if ($d) $da_agg[] = ['u' => $u->ID, 'id' => (int)$d->id, 'url' => html_entity_decode(self::link_doc($d->id, true)), 'nuovo' => (int)get_user_meta($u->ID, 'pdl_ratei_src', true) !== (int)$d->id];
        }
        $nuovi = count(array_filter($da_agg, function ($x) { return $x['nuovo']; }));
        if ($da_agg) {
            echo '<form id="bilbuste" method="post" style="margin-top:12px;display:flex;gap:10px;align-items:center;flex-wrap:wrap">' . self::nonce() . '<input type="hidden" name="pdl_act" value="bil_da_buste"><input type="hidden" name="dati"><button type="button" class="btn blu" id="bilbtn">Aggiorna dalle buste paga</button><span class="mut" id="bilst" style="font-size:13px">' . ($nuovi ? $nuovi . ' buste nuove: lettura in corso…' : 'Saldi letti dall\'ultima busta paga di ogni dipendente') . '</span></form>';
            echo '<script>window.PDL_BUSTE=' . wp_json_encode($da_agg) . ';</script><script src="' . esc_url(plugins_url('assets/ratei.js', __FILE__) . '?v=' . PDL_VER) . '"></script>';
        }
        echo '</tbody></table></div><p class="mut" style="font-size:13px;margin-top:12px">Il bilancio parte dal mese e dai saldi iniziali che imposti per ogni dipendente (copiali dall\'ultima busta paga). Ogni mese aggiunge la maturazione e toglie i giustificativi approvati.</p>';
        if ($bu && ($u = get_userdata($bu)) && self::is_dip($u)) {
            $b = self::bil_imp($bu);
            $chiudi = esc_url(self::link('presenze', ['tab' => 'bilancio', 'anno' => $a, 'mese' => $m]));
            echo '<div class="drawer on"><a class="ombra" href="' . $chiudi . '"></a><form class="pan" method="post">' . self::nonce() . '<input type="hidden" name="pdl_act" value="bil_salva"><input type="hidden" name="u" value="' . $bu . '"><input type="hidden" name="anno" value="' . $a . '"><input type="hidden" name="mese" value="' . $m . '"><div class="ph"><h2>Bilancio · ' . esc_html(trim($u->first_name . ' ' . $u->last_name)) . '</h2><a href="' . $chiudi . '">×</a></div><div class="pc">';
            echo '<div class="campo"><label>Calcola a partire dal mese</label><input class="inp" type="month" name="da" value="' . esc_attr($b['da']) . '"></div><table class="tab"><thead><tr><th></th><th>Saldo iniziale (ore)</th><th>Maturazione al mese (ore)</th></tr></thead><tbody>';
            foreach (self::CONTI as $k => $l) echo '<tr><td>' . $l . '</td><td><input class="inp" name="ini[' . $k . ']" value="' . esc_attr(str_replace('.', ',', $b['ini'][$k])) . '"></td><td><input class="inp" name="mat[' . $k . ']" value="' . esc_attr(str_replace('.', ',', $b['mat'][$k])) . '"></td></tr>';
            echo '</tbody></table><h3 style="font-size:15px;margin:20px 0 10px">Aggiungi correzione</h3><div class="griglia" style="grid-template-columns:1fr 1fr"><div class="campo"><label>Mese</label><input class="inp" type="month" name="c_mese" value="' . sprintf('%04d-%02d', $a, $m) . '"></div><div class="campo"><label>Conto</label><select class="inp" name="c_conto">';
            foreach (self::CONTI as $k => $l) echo '<option value="' . $k . '">' . $l . '</option>';
            echo '</select></div><div class="campo"><label>Ore (+ o −)</label><input class="inp" name="c_ore" placeholder="es. -8 oppure 4,5"></div><div class="campo"><label>Nota</label><input class="inp" name="c_nota"></div></div>';
            $C = $wpdb->get_results($wpdb->prepare("SELECT * FROM " . self::t('correzioni') . " WHERE utente_id=%d ORDER BY anno DESC, mese DESC, id DESC", $bu));
            if ($C) { echo '<h3 style="font-size:15px;margin:20px 0 10px">Correzioni inserite</h3>'; foreach ($C as $c) echo '<div class="gi" style="display:flex;gap:10px;align-items:center;padding:8px 0;border-bottom:1px solid var(--line)"><span style="flex:1">' . sprintf('%02d/%04d', $c->mese, $c->anno) . ' · ' . esc_html(self::CONTI[$c->conto] ?? $c->conto) . ' · <b>' . self::ore_fmt($c->ore) . '</b> ' . esc_html($c->nota) . '</span><button class="btn pic rosso" form="corr-' . $c->id . '">🗑</button></div>'; }
            echo '</div><div class="pf"><a class="btn" href="' . $chiudi . '">Annulla</a><button class="btn blu">Salva</button></div></form>';
            foreach ($C as $c) echo '<form id="corr-' . $c->id . '" method="post" onsubmit="return confirm(\'Eliminare la correzione?\')">' . self::nonce() . '<input type="hidden" name="pdl_act" value="corr_elimina"><input type="hidden" name="id" value="' . $c->id . '"><input type="hidden" name="u" value="' . $bu . '"></form>';
            echo '</div>';
        }
    }

    static function p_impostazioni() {
        $fe = ''; foreach ((array)get_option('pdl_festivi_extra', []) as $md => $n) $fe .= substr($md, 3, 2) . '/' . substr($md, 0, 2) . ' ' . $n . "\n";
        $ti = ''; foreach ((array)get_option('pdl_tipi_extra', []) as $n => $o) $ti .= $n . (!empty($o['ore']) ? ' (ore)' : '') . "\n";
        echo '<div class="drawer" id="dr-imp"><div class="ombra" data-chiudi></div><form class="pan" method="post">' . self::nonce() . '<input type="hidden" name="pdl_act" value="imp_salva"><div class="ph"><h2>Impostazioni presenze</h2><a href="#" data-chiudi>×</a></div><div class="pc">'
           . '<div class="campo"><label>Festività in più (oltre a quelle nazionali), una per riga: giorno/mese nome</label><textarea class="inp" name="festivi" placeholder="es. 13/11 Santo Patrono">' . esc_textarea($fe) . '</textarea></div>'
           . '<div class="campo"><label>Giustificativi in più, uno per riga (aggiungi "(ore)" se si inseriscono a ore)</label><textarea class="inp" name="tipi" placeholder="es. Visita medica (ore)">' . esc_textarea($ti) . '</textarea></div>'
           . '<p class="mut" style="font-size:13px">Gli orari di lavoro di ogni dipendente si impostano nella sua scheda, alla voce Contratto e orari.</p></div><div class="pf"><a class="btn" href="#" data-chiudi>Annulla</a><button class="btn blu">Salva</button></div></form></div>';
    }

    /* ---------- esportazione ---------- */
    /* ---------- PDF presenze per il commercialista ---------- */
    static function export_pdf() {
        require_once __DIR__ . '/lib/fpdf/fpdf.php';
        [$a, $m] = self::mese();
        $dip = self::dipendenti(); $gior = self::giorni($a, $m);
        $G = self::giust($gior[0], end($gior), wp_list_pluck($dip, 'ID'), ['Approvato']); $T = self::tipi();
        $az = self::az_nome(); $mese_t = self::MESI[$m] . ' ' . $a;
        $t = function ($x) { $r = @iconv('UTF-8', 'windows-1252//TRANSLIT', (string)$x); return $r === false ? (string)$x : $r; };
        $h = function ($n) { $n = round((float)$n, 2); return rtrim(rtrim(number_format($n, 2, ',', ''), '0'), ','); };
        $rgb = function ($hex) { $hex = ltrim($hex, '#'); return [hexdec(substr($hex, 0, 2)), hexdec(substr($hex, 2, 2)), hexdec(substr($hex, 4, 2))]; };
        $chiaro = function ($c) { return [(int)(255 - (255 - $c[0]) * .18), (int)(255 - (255 - $c[1]) * .18), (int)(255 - (255 - $c[2]) * .18)]; };
        $nomi_brevi = ['Aspettativa Non Retribuita' => 'ASPETTATIVA', 'Assenza Ingiustificata' => 'ASSENZA INGIUST.', 'Ferie' => 'FERIE', 'Ferie (ore)' => 'FERIE ORE', 'Malattia' => 'MALATTIA',
            'Malattia figlio < 3 anni' => 'MAL. FIGLIO <3', 'Malattia figlio 3+ anni' => 'MAL. FIGLIO 3+', 'Permessi' => 'PERMESSO', 'Permessi Ex Festività' => 'EX FESTIVITA', 'ROL' => 'ROL', 'Smart Working' => 'SMART WORKING', 'Straordinari' => 'STRAORDINARIO'];
        $pdf = new class('L', 'mm', 'A4') extends FPDF {
            public $piede = '';
            function Footer() { $this->SetY(-9); $this->SetFont('Helvetica', '', 7); $this->SetTextColor(120); $this->Cell(0, 5, $this->piede, 0, 0, 'L'); $this->Cell(0, 5, 'Pagina ' . $this->PageNo() . ' di {nb}', 0, 0, 'R'); $this->SetTextColor(0); }
        };
        $pdf->AliasNbPages(); $pdf->SetMargins(10, 10, 10); $pdf->SetAutoPageBreak(false); $pdf->SetDrawColor(200, 208, 220);
        $pdf->piede = $t($az . ' - Presenze ' . $mese_t . ' - generato il ' . current_time('d/m/Y H:i') . ' - conteggi sui soli giustificativi approvati');
        $pdf->SetTitle($t('Presenze ' . $mese_t . ' - ' . $az));
        $testa = function ($tit, $sotto) use ($pdf, $t) {
            $pdf->SetFillColor(21, 89, 201); $pdf->Rect(10, 8, 277, 15, 'F'); $pdf->SetTextColor(255);
            $pdf->SetFont('Helvetica', 'B', 14); $pdf->SetXY(14, 9.5); $pdf->Cell(200, 6.5, $t($tit), 0, 2); $pdf->SetFont('Helvetica', '', 9); $pdf->Cell(200, 5, $t($sotto), 0, 0); $pdf->SetTextColor(0); $pdf->SetY(27);
        };
        // ---- dati
        $righe = [];
        foreach ($dip as $u) {
            $r = ['u' => $u, 'contr' => 0, 'lav' => 0, 'gg' => 0, 'tipi' => [], 'g' => [], 'ass' => []];
            foreach ($gior as $g) {
                $L = $G[$u->ID][$g] ?? []; $oc = self::ore_contratto($u->ID, $g); $pr = self::presenza($u->ID, $g, $L);
                $r['contr'] += $oc; $r['lav'] += $pr; if ($pr > 0) $r['gg']++; $r['g'][$g] = ['oc' => $oc, 'pr' => $pr, 'L' => $L];
                foreach ($L as $x) { $r['tipi'][$x->tipo]['ore'] = ($r['tipi'][$x->tipo]['ore'] ?? 0) + (float)$x->ore; $r['tipi'][$x->tipo]['gg'] = ($r['tipi'][$x->tipo]['gg'] ?? 0) + 1; }
            }
            // periodi di assenza (giorni consecutivi lavorativi con lo stesso tipo e protocollo)
            $cur = null;
            foreach ($gior as $g) {
                $L = $r['g'][$g]['L']; $quest = [];
                foreach ($L as $x) $quest[$x->tipo . '|' . ($x->protocollo ?? '') . '|' . ($x->dalle ?? '')] = $x;
                if ($cur) { $k = $cur['k']; if (isset($quest[$k]) && !$T[$cur['x']->tipo][2]) { $cur['al'] = $g; $cur['ore'] += (float)$quest[$k]->ore; $cur['n']++; unset($quest[$k]); }
                    elseif ($r['g'][$g]['oc'] == 0 && !self::festivo($g) || self::festivo($g)) { /* riposo o festivo: il periodo continua */ }
                    else { $r['ass'][] = $cur; $cur = null; } }
                foreach ($quest as $k => $x) { if ($cur) { $r['ass'][] = $cur; } $cur = ['k' => $k, 'x' => $x, 'dal' => $g, 'al' => $g, 'ore' => (float)$x->ore, 'n' => 1]; if ($T[$x->tipo][2]) { $r['ass'][] = $cur; $cur = null; } }
            }
            if ($cur) $r['ass'][] = $cur;
            $righe[] = $r;
        }
        $somma = function ($r, $tipi, $campo = 'ore') { $s = 0; foreach ($tipi as $k) $s += $r['tipi'][$k][$campo] ?? 0; return $s; };
        $MAL = ['Malattia', 'Malattia figlio < 3 anni', 'Malattia figlio 3+ anni'];
        // ---- pagina unica: calendario di tutti + elenco assenze
        $fm = []; foreach (self::festivi($a) as $g => $n) if (substr($g, 0, 7) === sprintf('%04d-%02d', $a, $m)) $fm[] = date('d/m', strtotime($g)) . ' ' . $n;
        $pdf->SetAutoPageBreak(true, 14);
        $pdf->AddPage(); $testa('Presenze - ' . $mese_t, $az . ' - ' . count($righe) . ' dipendenti');
        $nw = 42; $sc = [['Ore lavorate', 14], ['Ferie h', 11], ['Perm. ROL h', 13], ['Malattia gg', 13]]; $sw = 51;
        $dw = (277 - $nw - $sw) / count($gior); $gl = ['L', 'M', 'M', 'G', 'V', 'S', 'D'];
        $rh = 10.5;
        $pdf->SetFont('Helvetica', 'B', 7); $pdf->SetFillColor(232, 240, 253); $y = $pdf->GetY();
        $pdf->Cell($nw, 9, $t('Dipendente'), 1, 0, 'L', true);
        foreach ($gior as $g) { $fe = self::festivo($g) || date('N', strtotime($g)) == 7; $pdf->SetFillColor($fe ? 222 : 232, $fe ? 226 : 240, $fe ? 232 : 253); $x = $pdf->GetX();
            $pdf->Cell($dw, 9, '', 1, 0, 'C', true); $pdf->SetXY($x, $y + .8); $pdf->SetFont('Helvetica', 'B', 7.5); $pdf->Cell($dw, 3.8, (int)substr($g, 8), 0, 2, 'C');
            $pdf->SetFont('Helvetica', '', 6); $pdf->Cell($dw, 3.5, $gl[date('N', strtotime($g)) - 1], 0, 0, 'C'); $pdf->SetXY($x + $dw, $y); }
        $pdf->SetFillColor(232, 240, 253); $pdf->SetFont('Helvetica', 'B', 6.5);
        foreach ($sc as $c) { $x = $pdf->GetX(); $pdf->Cell($c[1], 9, '', 1, 0, 'C', true); $pdf->SetXY($x, $y + 1); $pdf->MultiCell($c[1], 3.4, $t($c[0]), 0, 'C'); $pdf->SetXY($x + $c[1], $y); }
        $pdf->Ln(9);
        $usati = [];
        foreach ($righe as $r) {
            $y = $pdf->GetY(); $pdf->SetFont('Helvetica', 'B', 8);
            $pdf->Cell($nw, $rh, $t(trim($r['u']->last_name . ' ' . $r['u']->first_name)), 1, 0, 'L');
            foreach ($gior as $g) {
                $d = $r['g'][$g]; $fest = self::festivo($g); $x = $pdf->GetX();
                $ass = array_values(array_filter($d['L'], function ($z) use ($T) { return !empty($T[$z->tipo]) && $z->tipo !== 'Straordinari'; }));
                if ($ass) { $c = $rgb($T[$ass[0]->tipo][1]); $l = $chiaro($c); $pdf->SetFillColor($l[0], $l[1], $l[2]); foreach ($ass as $z) $usati[$z->tipo] = 1; }
                elseif ($fest || !$d['oc']) $pdf->SetFillColor(232, 234, 238); else $pdf->SetFillColor(255, 255, 255);
                $pdf->Cell($dw, $rh, '', 1, 0, 'C', true);
                if ($ass) {
                    $c = $rgb($T[$ass[0]->tipo][1]); $pdf->SetTextColor($c[0], $c[1], $c[2]);
                    $pdf->SetXY($x, $y + 1.2); $pdf->SetFont('Helvetica', 'B', 9); $pdf->Cell($dw, 4.5, $t($T[$ass[0]->tipo][0] . (count($ass) > 1 ? '+' : '')), 0, 2, 'C');
                    $pdf->SetFont('Helvetica', '', 5.8); $pdf->Cell($dw, 3.5, $T[$ass[0]->tipo][2] ? $h($ass[0]->ore) . 'h' : '', 0, 0, 'C'); $pdf->SetTextColor(0);
                } elseif ($fest) { $pdf->SetXY($x, $y + 3); $pdf->SetFont('Helvetica', 'B', 6.5); $pdf->SetTextColor(22, 128, 61); $pdf->Cell($dw, 4, 'FS', 0, 0, 'C'); $pdf->SetTextColor(0); }
                elseif ($d['pr'] > 0) { $pdf->SetXY($x, $y + 3); $pdf->SetFont('Helvetica', '', 7); $pdf->SetTextColor(70); $pdf->Cell($dw, 4, $h($d['pr']), 0, 0, 'C'); $pdf->SetTextColor(0); }
                $pdf->SetXY($x + $dw, $y);
            }
            $vals = [$h($r['lav']), $h($somma($r, ['Ferie', 'Ferie (ore)'])), $h($somma($r, ['Permessi', 'ROL', 'Permessi Ex Festività'])), $somma($r, $MAL, 'gg')];
            foreach ($sc as $k => $c) { $pdf->SetFont('Helvetica', $k === 0 ? 'B' : '', 8.5); $v = (string)$vals[$k]; $pdf->Cell($c[1], $rh, $v === '0' ? '-' : $v, 1, 0, 'C'); }
            $pdf->Ln($rh);
        }
        if (!$righe) $pdf->Cell(277, 8, $t('Nessun dipendente attivo.'), 1, 1, 'C');
        // legenda colori
        $pdf->Ln(2.5); $pdf->SetFont('Helvetica', '', 7.5); $pdf->SetX(10);
        $pdf->SetFillColor(232, 234, 238); $pdf->Cell(4, 4, '', 1, 0, '', true); $pdf->Cell(48, 4, $t(' Festivo (FS) o giorno di riposo'), 0, 0);
        $pdf->Cell(36, 4, $t('numero = ore lavorate'), 0, 0);
        foreach (array_keys($usati ?: ['Ferie' => 1, 'Malattia' => 1, 'Permessi' => 1]) as $k) { $c = $rgb($T[$k][1]); $l = $chiaro($c);
            if ($pdf->GetX() > 255) { $pdf->Ln(5); $pdf->SetX(10); }
            $pdf->SetFillColor($l[0], $l[1], $l[2]); $pdf->Cell(4, 4, '', 1, 0, '', true); $pdf->SetTextColor($c[0], $c[1], $c[2]); $pdf->SetFont('Helvetica', 'B', 7.5); $pdf->Cell(5, 4, $t(' ' . $T[$k][0]), 0, 0); $pdf->SetTextColor(0); $pdf->SetFont('Helvetica', '', 7.5); $pdf->Cell(28, 4, $t(' ' . $k), 0, 0); }
        $pdf->Ln(5); $pdf->SetFont('Helvetica', '', 7.5); $pdf->SetTextColor(90);
        $pdf->Cell(0, 4, $t('Festività del mese: ' . ($fm ? implode(', ', $fm) : 'nessuna') . '. Ore lavorate = ore previste dal contratto meno le assenze approvate, più gli straordinari.'), 0, 1); $pdf->SetTextColor(0);
        // elenco assenze di tutti
        $pdf->Ln(3); $pdf->SetFont('Helvetica', 'B', 10); $pdf->Cell(0, 6, $t('Elenco delle assenze'), 0, 1);
        $ca = [['Dipendente', 48], ['Tipo', 46], ['Dal', 23], ['Al', 23], ['Giorni', 14], ['Ore', 14], ['Protocollo certificato malattia', 62], ['Note', 47]];
        $intest_ass = function () use ($pdf, $t, $ca) { $pdf->SetFont('Helvetica', 'B', 7.5); $pdf->SetFillColor(232, 240, 253); foreach ($ca as $c) $pdf->Cell($c[1], 7, $t($c[0]), 1, 0, 'C', true); $pdf->Ln(); };
        $intest_ass(); $tutte = 0;
        foreach ($righe as $r) foreach ($r['ass'] as $z) {
            $x = $z['x']; if (empty($T[$x->tipo][4])) continue; $tutte++;
            if ($pdf->GetY() > 186) { $pdf->AddPage(); $testa('Presenze - ' . $mese_t . ' (segue)', $az); $intest_ass(); }
            $mal = strpos($x->tipo, 'Malattia') === 0; $c = $rgb($T[$x->tipo][1]);
            $pdf->SetFont('Helvetica', '', 8.5); $pdf->Cell(48, 7, $t(trim($r['u']->last_name . ' ' . $r['u']->first_name)), 1, 0, 'L');
            $pdf->SetTextColor($c[0], $c[1], $c[2]); $pdf->SetFont('Helvetica', 'B', 8.5); $pdf->Cell(46, 7, $t($x->tipo), 1, 0, 'L'); $pdf->SetTextColor(0); $pdf->SetFont('Helvetica', '', 8.5);
            $pdf->Cell(23, 7, date('d/m/Y', strtotime($z['dal'])), 1, 0, 'C'); $pdf->Cell(23, 7, date('d/m/Y', strtotime($z['al'])), 1, 0, 'C');
            $pdf->Cell(14, 7, $T[$x->tipo][2] ? '-' : $z['n'], 1, 0, 'C'); $pdf->Cell(14, 7, $h($z['ore']), 1, 0, 'C');
            $pdf->SetFont('Helvetica', $mal && !empty($x->protocollo) ? 'B' : '', 8.5);
            $pdf->Cell(62, 7, $t($mal ? (!empty($x->protocollo) ? $x->protocollo : '_________________________') : '-'), 1, 0, 'C'); $pdf->SetFont('Helvetica', '', 7.5);
            $pdf->Cell(47, 7, $t(($x->dalle ? 'dalle ' . substr($x->dalle, 0, 5) . ' alle ' . substr($x->alle, 0, 5) . ' ' : '') . ($x->nota ?? '')), 1, 1, 'L');
        }
        if (!$tutte) $pdf->Cell(277, 7, $t('Nessuna assenza nel mese.'), 1, 1, 'C');
        if ($pdf->GetY() > 190) { $pdf->AddPage(); $testa('Presenze - ' . $mese_t . ' (segue)', $az); }
        $pdf->Ln(6); $pdf->SetFont('Helvetica', '', 8.5);
        $pdf->Cell(130, 5, $t('Data: ____________________'), 0, 0); $pdf->Cell(0, 5, $t('Firma del datore di lavoro: ______________________________'), 0, 1);
        $nome = 'presenze_' . sanitize_file_name(strtolower(str_replace(' ', '_', remove_accents($az)))) . '_' . $a . '_' . sprintf('%02d', $m) . '.pdf';
        nocache_headers();
        $pdf->Output('D', $nome);
    }

    static function export_csv() {
        if (!current_user_can('manage_options') || !check_admin_referer('pdl_export')) wp_die('Non autorizzato');
        self::$fe = true;
        if (($_GET['formato'] ?? 'pdf') !== 'csv') { self::export_pdf(); exit; }
        [$a, $m] = self::mese();
        $dip = self::dipendenti(); $gior = self::giorni($a, $m); $G = self::giust($gior[0], end($gior), wp_list_pluck($dip, 'ID'), ['Approvato']); $T = self::tipi();
        header('Content-Type: text/csv; charset=utf-8'); header('Content-Disposition: attachment; filename=presenze_' . $a . '_' . sprintf('%02d', $m) . '.csv');
        $f = fopen('php://output', 'w'); fwrite($f, "\xEF\xBB\xBF");
        $h = ['Dipendente', 'Codice fiscale']; foreach ($gior as $g) $h[] = substr($g, 8, 2) . '/' . substr($g, 5, 2); $h[] = 'Ore lavorate'; foreach ($T as $k => $t) $h[] = 'Ore ' . $k;
        fputcsv($f, $h, ';');
        foreach ($dip as $u) {
            $r = [trim($u->last_name . ' ' . $u->first_name), self::m($u, 'codice_fiscale')]; $tot = 0; $tt = array_fill_keys(array_keys($T), 0);
            foreach ($gior as $g) { $L = $G[$u->ID][$g] ?? []; $pr = self::presenza($u->ID, $g, $L); $tot += $pr; $c = [];
                if (self::festivo($g)) $c[] = 'FEST';
                foreach ($L as $x) { $tt[$x->tipo] = ($tt[$x->tipo] ?? 0) + $x->ore; $c[] = ($T[$x->tipo][0] ?? $x->tipo) . ' ' . str_replace('.', ',', (float)$x->ore); }
                if ($pr) array_unshift($c, str_replace('.', ',', $pr)); $r[] = implode(' ', $c); }
            $r[] = str_replace('.', ',', $tot); foreach ($T as $k => $t) $r[] = str_replace('.', ',', $tt[$k] ?? 0);
            fputcsv($f, $r, ';');
        }
        exit;
    }

    /* =====================================================================
       AREA DIPENDENTI (shortcode [area_dipendenti])
       ===================================================================== */
    static function gestisci_post_frontend() {
        if (!self::is_dip() || empty($_POST['pdl_dip_act'])) return;
        if (!wp_verify_nonce($_POST['_wpnonce'] ?? '', 'pdl_dip')) return;
        global $wpdb; $me = get_current_user_id(); $act = $_POST['pdl_dip_act'];
        if ($act === 'richiesta') {
            self::$protocollo = sanitize_text_field(wp_unslash($_POST['protocollo'] ?? ''));
            $T = self::tipi(); $tipo = wp_unslash($_POST['tipo'] ?? '');
            $ok = isset($T[$tipo]) && !in_array($tipo, ['Assenza Ingiustificata', 'Straordinari'], true);
            $dal = self::d($_POST['dal'] ?? ''); $al = !empty($T[$tipo][2]) ? $dal : (self::d($_POST['al'] ?? '') ?: $dal);
            $n = 0;
            if ($ok && $dal && $al >= $dal) $n = self::crea_giust($me, $tipo, $dal, $al, $_POST['dalle'] ?? '', $_POST['alle'] ?? '', self::num($_POST['ore'] ?? ''), 'In attesa', sanitize_text_field(wp_unslash($_POST['motivo'] ?? '')), wp_generate_password(10, false));
            if ($n) self::notifica_admin(self::chi() . (strpos($tipo, 'Malattia') === 0 ? ' ha segnalato ' : ' ha chiesto ') . $tipo, ucfirst(self::periodo($dal, $al)) . (!empty($_POST['motivo']) ? ' · ' . sanitize_text_field(wp_unslash($_POST['motivo'])) : ''), self::link('presenze', ['tab' => 'richieste']));
            wp_safe_redirect(add_query_arg(['sez' => 'richieste', 'esito' => $n ? 'ok' : 'err'], self::url_area())); exit;
        }
        if ($act === 'annulla') {
            $wpdb->delete(self::t('giust'), ['gruppo' => sanitize_text_field($_POST['gruppo']), 'utente_id' => $me, 'stato' => 'In attesa']);
            wp_safe_redirect(add_query_arg(['sez' => 'richieste'], self::url_area())); exit;
        }
        if ($act === 'carica_richiesto') {
            $r = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . self::t('richieste_doc') . " WHERE id=%d AND utente_id=%d AND stato='In attesa'", (int)$_POST['id'], $me));
            $f = $_FILES['file'] ?? null; $ok = false;
            if ($r && $f && $f['error'] === UPLOAD_ERR_OK && ($nome = self::salva_fisico($f['tmp_name'], $f['name'], $me))) {
                $wpdb->insert(self::t('documenti'), ['utente_id' => $me, 'tipo' => 'doc', 'categoria' => $r->categoria ?: 'Altro', 'titolo' => $r->titolo, 'anno' => (int)current_time('Y'), 'condiviso' => 1,
                    'file' => $nome, 'nome_originale' => sanitize_file_name($f['name']), 'caricato' => current_time('mysql'), 'scaricato' => current_time('mysql'), 'note' => 'Caricato dal dipendente']);
                $wpdb->update(self::t('richieste_doc'), ['stato' => 'Caricato', 'documento_id' => $wpdb->insert_id], ['id' => $r->id]);
                $ok = true;
                self::notifica_admin(self::chi() . ' ha caricato un documento', $r->titolo, self::link('documenti'));
            }
            wp_safe_redirect(add_query_arg(['sez' => 'documenti', 'esito' => $ok ? 'caricato' : 'err'], self::url_area())); exit;
        }
    }

    static function shortcode() {
        global $wpdb;
        ob_start();
        echo '<style>.pdl-area{--blu:#1559c9;--blu2:#0d47a8;--blu-ch:#e8f0fd;--verde:#12805c;--verde-ch:#e3f6ec;--rosso:#c9302c;--line:#e3e7ee;--txt:#1f2a37;--mut:#6b7684;font-family:Inter,system-ui,sans-serif;max-width:900px;margin:0 auto;color:var(--txt);font-size:15px}
.pdl-area *{box-sizing:border-box}.pdl-area a{color:var(--blu);text-decoration:none}.pdl-area .card{background:#fff;border-radius:8px;box-shadow:0 1px 3px rgba(16,24,40,.08);padding:18px;margin-bottom:16px}.pdl-area .card h3{margin:0 0 14px;color:var(--blu);font-size:16px}
.pdl-area .av{width:44px;height:44px;border-radius:50%;background:#fff;color:var(--blu);display:inline-flex;align-items:center;justify-content:center;font-weight:700}
.pdl-area .tabs{display:flex;gap:4px;flex-wrap:wrap;background:#fff;border:1px solid var(--line);border-radius:8px;padding:4px;margin-bottom:16px}.pdl-area .tabs a{flex:1;text-align:center;padding:9px 10px;border-radius:6px;color:#4a5562;font-weight:500;white-space:nowrap}.pdl-area .tabs a.on{background:var(--blu);color:#fff}
.pdl-area table{width:100%;border-collapse:collapse;background:#fff;border-radius:8px;overflow:hidden;box-shadow:0 1px 3px rgba(16,24,40,.08)}.pdl-area th{text-align:left;font-weight:400;color:var(--mut);font-size:13px;padding:10px 12px;border-bottom:1px solid var(--line)}.pdl-area td{padding:11px 12px;border-bottom:1px solid var(--line)}
.pdl-area .btn{display:inline-flex;align-items:center;height:32px;padding:0 12px;border-radius:4px;border:1px solid var(--line);background:#fff;color:var(--txt)!important;font:inherit;font-size:14px;cursor:pointer}.pdl-area .btn.blu{background:var(--blu);border-color:var(--blu);color:#fff!important}.pdl-area .btn.verde{background:var(--verde);border-color:var(--verde);color:#fff!important}
.pdl-area .inp{height:38px;border:1px solid #d7dde6;border-radius:4px;padding:0 10px;font:inherit;width:100%}.pdl-area .griglia{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px}.pdl-area label{display:block;font-size:13px;color:#4a5562;margin-bottom:4px}
.pdl-area .stato{display:inline-block;padding:2px 9px;border-radius:3px;font-size:12px;font-weight:500}.pdl-area .stato.ok{background:var(--verde-ch);color:var(--verde)}.pdl-area .stato.no{background:#fde8e7;color:var(--rosso)}.pdl-area .stato.att{background:#fff4dc;color:#a15c00}
.pdl-area .msg{padding:12px 14px;border-radius:6px;background:var(--verde-ch);color:var(--verde);margin-bottom:14px}.pdl-area .msg.err{background:#fde8e7;color:var(--rosso)}.pdl-area .mut{color:var(--mut)}
.pdl-area .bils{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:10px;margin-bottom:16px}.pdl-area .bils div{background:#fff;border-radius:8px;box-shadow:0 1px 3px rgba(16,24,40,.08);padding:12px 14px}.pdl-area .bils small{color:var(--mut);display:block}.pdl-area .bils b{font-size:20px;color:var(--blu)}
.pdl-area .gg td{vertical-align:middle}.pdl-area .gg .ic{display:flex;gap:6px;align-items:center;flex-wrap:wrap}.pdl-area .pend{border:1.5px dashed #6f8fc9;border-radius:4px;padding:1px}
.pdl-area .login{max-width:400px;margin:20px auto}.pdl-area .login input[type=text],.pdl-area .login input[type=password]{width:100%;height:40px;border:1px solid #d7dde6;border-radius:4px;padding:0 10px}.pdl-area .login .button{width:100%;height:42px;background:var(--blu);color:#fff;border:0;border-radius:4px;font-weight:600;cursor:pointer}
@media(max-width:600px){.pdl-area .tabs a{flex:1 1 45%}.pdl-area td,.pdl-area th{padding:9px 8px}}</style><div class="pdl-area">';
        if (!is_user_logged_in()) {
            echo '<div class="card login"><h3>Area dipendenti</h3><p class="mut">Entra con utente e password che ti ha dato l\'azienda.</p>';
            wp_login_form(['redirect' => self::url_area(), 'label_username' => 'Nome utente', 'label_password' => 'Password', 'label_remember' => 'Ricordami', 'label_log_in' => 'Entra']);
            echo '<p><a href="' . esc_url(wp_lostpassword_url(self::url_area())) . '">Password dimenticata?</a></p></div></div>';
            return ob_get_clean();
        }
        $me = wp_get_current_user();
        if (!self::is_dip($me)) {
            echo '<div class="card">' . (current_user_can('manage_options') ? '<p>Sei amministratore: gestisci tutto da <a href="' . esc_url(self::url_gestione()) . '"><b>Gestione dipendenti</b></a>.</p>' : '<p>Area riservata ai dipendenti.</p>') . '</div></div>';
            return ob_get_clean();
        }
        $sez = sanitize_key($_GET['sez'] ?? 'buste'); $url = self::url_area();
        $req = $wpdb->get_results($wpdb->prepare("SELECT * FROM " . self::t('richieste_doc') . " WHERE utente_id=%d AND stato='In attesa' ORDER BY id DESC", $me->ID));
        echo '<div class="card" style="display:flex;align-items:center;gap:14px;background:var(--blu);color:#fff"><span class="av">' . self::iniziali($me) . '</span><div style="flex:1"><small style="opacity:.85">Area dipendenti</small><div style="font-size:19px;font-weight:600">Ciao ' . esc_html($me->first_name ?: $me->display_name) . '</div></div><a style="color:#fff;text-decoration:underline" href="' . esc_url(wp_logout_url($url)) . '">Esci</a></div>';
        echo '<div class="tabs">';
        foreach (['buste' => 'Buste paga', 'documenti' => 'Documenti' . ($req ? ' (' . count($req) . ')' : ''), 'presenze' => 'Presenze', 'richieste' => 'Ferie e permessi'] as $k => $l) echo '<a class="' . ($sez === $k ? 'on' : '') . '" href="' . esc_url(add_query_arg('sez', $k, $url)) . '">' . esc_html($l) . '</a>';
        echo '</div>';
        $es = $_GET['esito'] ?? '';
        if ($es === 'ok') echo '<div class="msg">Richiesta inviata: riceverai la risposta qui.</div>'; elseif ($es === 'caricato') echo '<div class="msg">Documento caricato, grazie.</div>'; elseif ($es === 'err') echo '<div class="msg err">Richiesta non inviata: controlla le date (i giorni festivi e non lavorativi non contano) e riprova.</div>';
        if ($sez === 'presenze' || $sez === 'richieste') {
            $B = self::bilancio($me->ID, current_time('Y-m'), current_time('Y-m'));
            echo '<div class="bils">'; foreach (self::CONTI as $k => $l) if ($k !== 'permessi' || $B[$k]['bilancio']) echo '<div><small>' . $l . ' disponibili</small><b>' . self::ore_fmt($B[$k]['bilancio']) . '</b></div>'; echo '</div>';
        }
        if ($sez === 'presenze') {
            [$a, $m] = self::mese(); $gior = self::giorni($a, $m);
            $G = self::giust($gior[0], end($gior), [$me->ID], ['Approvato', 'In attesa'])[$me->ID] ?? [];
            echo '<form method="get" action="' . esc_url($url) . '" style="display:flex;gap:8px;margin-bottom:14px"><input type="hidden" name="sez" value="presenze"><select class="inp" name="mese" style="width:150px">';
            for ($i = 1; $i <= 12; $i++) echo '<option value="' . $i . '"' . selected($i, $m, false) . '>' . self::MESI[$i] . '</option>';
            echo '</select><input class="inp" type="number" name="anno" value="' . $a . '" style="width:100px"><button class="btn blu">Vai</button></form>';
            $T = self::tipi(); $usati = []; $oggi = current_time('Y-m-d');
            echo '<style>.pdl-area .mc{display:grid;grid-template-columns:repeat(7,1fr);gap:4px;margin-bottom:12px}.pdl-area .mc .h{text-align:center;font-size:12px;color:#6b7280;font-weight:600;padding:4px 0}.pdl-area .mc .d{min-height:62px;border:1px solid #e5e7eb;border-radius:8px;padding:4px;display:flex;flex-direction:column;align-items:center;gap:3px;background:#fff}.pdl-area .mc .d.no{background:#f3f4f6}.pdl-area .mc .d.og{border:2px solid #1558d6}.pdl-area .mc .n{font-size:13px;font-weight:600;color:#374151}.pdl-area .mc .fe{font-size:10px;color:#16a34a;text-align:center;line-height:1.1}.pdl-area .bd{display:flex;flex-direction:column;align-items:center;width:100%;border-radius:6px;background:var(--c);color:#fff;line-height:1.1;padding:3px 0}.pdl-area .bd b{font-size:13px}.pdl-area .bd i{font-style:normal;font-size:11px}.pdl-area .bd.pe{background:#fff;color:var(--c);border:2px dashed var(--c)}.pdl-area .lg{display:flex;flex-wrap:wrap;gap:10px;font-size:13px;margin-bottom:16px}.pdl-area .lg span{display:inline-flex;align-items:center;gap:5px}.pdl-area .lg i{font-style:normal;color:#fff;font-weight:700;font-size:11px;border-radius:4px;padding:2px 6px}.pdl-area .el{border:1px solid #e5e7eb;border-radius:8px;overflow:hidden}.pdl-area .el div{display:flex;gap:10px;align-items:center;padding:10px 12px;border-bottom:1px solid #eef0f3;border-left:5px solid var(--c);font-size:14px}.pdl-area .el div:last-child{border-bottom:0}.pdl-area .el small{color:#6b7280;margin-left:auto}@media(max-width:480px){.pdl-area .mc{gap:2px}.pdl-area .mc .d{min-height:54px;padding:2px}.pdl-area .bd b{font-size:12px}}</style>';
            echo '<div class="mc">'; foreach (['Lun','Mar','Mer','Gio','Ven','Sab','Dom'] as $h) echo '<div class="h">' . $h . '</div>';
            for ($k = 1; $k < (int)date('N', strtotime($gior[0])); $k++) echo '<div></div>';
            $el = '';
            foreach ($gior as $g) { $L = $G[$g] ?? []; $f = self::festivo($g); $oc = self::ore_contratto($me->ID, $g);
                $agg = []; foreach ($L as $x) { $agg[$x->tipo]['o'] = ($agg[$x->tipo]['o'] ?? 0) + (float)$x->ore; if ($x->stato === 'In attesa') $agg[$x->tipo]['p'] = 1; }
                echo '<div class="d' . (!$oc && !$f ? ' no' : '') . ($g === $oggi ? ' og' : '') . '"><span class="n">' . (int)substr($g, 8) . '</span>' . ($f ? '<span class="fe">' . esc_html($f) . '</span>' : '');
                foreach ($agg as $tp => $v) { $tt = $T[$tp] ?? ['?', '#64748b']; $usati[$tp] = $tt; $h = rtrim(rtrim(number_format($v['o'], 2, ',', ''), '0'), ',');
                    echo '<span class="bd' . (!empty($v['p']) ? ' pe' : '') . '" style="--c:' . $tt[1] . '"><b>' . esc_html($tt[0]) . '</b>' . ($v['o'] ? '<i>' . $h . 'h</i>' : '') . '</span>';
                    $el .= '<div style="--c:' . $tt[1] . '"><b>' . self::data_it($g) . '</b> ' . esc_html($tp) . ' · ' . ($v['o'] ? $h . ' ore' : '') . '<small>' . (!empty($v['p']) ? 'In attesa' : 'Approvato') . '</small></div>'; }
                echo '</div>'; }
            echo '</div><div class="lg">'; foreach ($usati as $tp => $tt) echo '<span><i style="background:' . $tt[1] . '">' . esc_html($tt[0]) . '</i>' . esc_html($tp) . '</span>';
            echo '<span><i style="background:#fff;color:#1558d6;border:2px dashed #1558d6">F</i>In attesa di approvazione</span></div>';
            echo '<h3 style="font-size:16px;margin:0 0 8px">Assenze del mese</h3>' . ($el ? '<div class="el">' . $el . '</div>' : '<p class="mut">Nessuna assenza segnata in questo mese.</p>');
        } elseif ($sez === 'richieste') {
            $T = self::tipi(); $o = '';
            foreach ($T as $k => $t) if (!in_array($k, ['Assenza Ingiustificata', 'Straordinari'], true)) $o .= '<option value="' . esc_attr($k) . '" data-ore="' . ($t[2] ? 1 : 0) . '">' . esc_html($k) . '</option>';
            echo '<div class="card"><h3>Nuova richiesta</h3><form method="post" id="rq">' . wp_nonce_field('pdl_dip', '_wpnonce', true, false) . '<input type="hidden" name="pdl_dip_act" value="richiesta"><div class="griglia">'
               . '<div><label>Tipo</label><select class="inp" name="tipo" id="rq-tipo">' . $o . '</select></div><div><label id="rq-l1">Dal</label><input class="inp" type="date" name="dal" required></div><div class="rq-giorni"><label>Al</label><input class="inp" type="date" name="al"></div>'
               . '<div class="rq-ore" style="display:none"><label>Dalle</label><input class="inp" type="time" name="dalle"></div><div class="rq-ore" style="display:none"><label>Alle</label><input class="inp" type="time" name="alle"></div>'
               . '<div class="rq-prot" style="display:none"><label>N. protocollo certificato</label><input class="inp" name="protocollo"></div><div style="grid-column:1/-1"><label>Motivo / nota</label><input class="inp" name="motivo"></div></div><p><button class="btn blu">Invia richiesta</button></p></form></div>'
               . '<script>(function(){var s=document.getElementById("rq-tipo");function f(){var h=s.options[s.selectedIndex].dataset.ore==="1";document.querySelectorAll(".rq-ore").forEach(function(e){e.style.display=h?"":"none";e.querySelector("input").required=h;});document.querySelectorAll(".rq-giorni").forEach(function(e){e.style.display=h?"none":"";});document.getElementById("rq-l1").textContent=h?"Giorno":"Dal";document.querySelector(".rq-prot").style.display=/^Malattia/.test(s.value)?"":"none";}s.addEventListener("change",f);f();})();</script>';
            echo '<table><thead><tr><th>Richiesta</th><th>Stato</th><th></th></tr></thead><tbody>'; $tutte = [];
            foreach (['In attesa', 'Approvato', 'Rifiutato'] as $st) foreach (self::gruppi_richieste($st, $me->ID) as $r) $tutte[] = $r;
            usort($tutte, function ($a, $b) { return strcmp($b->creato, $a->creato); });
            if (!$tutte) echo '<tr><td colspan="3" class="mut">Nessuna richiesta.</td></tr>';
            foreach (array_slice($tutte, 0, 40) as $r) {
                echo '<tr><td>' . self::frase_richiesta($r, false) . ($r->nota_admin ? '<br><small class="mut">Risposta: ' . esc_html($r->nota_admin) . '</small>' : '') . '</td><td><span class="stato ' . ($r->stato === 'Approvato' ? 'ok' : ($r->stato === 'Rifiutato' ? 'no' : 'att')) . '">' . esc_html($r->stato === 'In attesa' ? 'In attesa' : $r->stato) . '</span></td><td>';
                if ($r->stato === 'In attesa') echo '<form method="post" onsubmit="return confirm(\'Annullare la richiesta?\')">' . wp_nonce_field('pdl_dip', '_wpnonce', true, false) . '<input type="hidden" name="pdl_dip_act" value="annulla"><input type="hidden" name="gruppo" value="' . esc_attr($r->gruppo) . '"><button class="btn">Annulla</button></form>';
                echo '</td></tr>';
            }
            echo '</tbody></table>';
        } else {
            $bp = $sez !== 'documenti';
            if (!$bp && $req) {
                echo '<div class="card"><h3>Documenti che ti sono stati richiesti</h3>';
                foreach ($req as $r) echo '<form method="post" enctype="multipart/form-data" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;padding:10px 0;border-bottom:1px solid var(--line)">' . wp_nonce_field('pdl_dip', '_wpnonce', true, false) . '<input type="hidden" name="pdl_dip_act" value="carica_richiesto"><input type="hidden" name="id" value="' . $r->id . '"><div style="flex:1;min-width:200px"><b>' . esc_html($r->titolo) . '</b>' . ($r->nota ? '<br><small class="mut">' . esc_html($r->nota) . '</small>' : '') . ($r->scadenza ? '<br><small class="mut">Entro il ' . self::data_it($r->scadenza) . '</small>' : '') . '</div><input type="file" name="file" required><button class="btn verde">Carica</button></form>';
                echo '</div>';
            }
            $docs = $wpdb->get_results($wpdb->prepare("SELECT * FROM " . self::t('documenti') . " WHERE utente_id=%d AND tipo=%s AND condiviso=1 ORDER BY anno DESC, mese DESC, id DESC", $me->ID, $bp ? 'busta' : 'doc'));
            echo '<table><thead><tr>' . ($bp ? '<th>Mese</th><th>Netto</th>' : '<th>Documento</th><th>Categoria</th>') . '<th></th></tr></thead><tbody>';
            if (!$docs) echo '<tr><td colspan="3" class="mut">Nessun ' . ($bp ? 'busta paga' : 'documento') . '.</td></tr>';
            foreach ($docs as $d) echo '<tr><td>' . ($bp ? '<b>' . self::nome_mese($d->mese) . ' ' . esc_html($d->anno) . '</b>' . (!$d->scaricato ? ' <span class="stato att">Nuova</span>' : '') : esc_html($d->titolo)) . '</td><td>' . ($bp ? self::euro($d->netto) : esc_html($d->categoria)) . '</td><td style="text-align:right;white-space:nowrap"><a class="btn" href="' . esc_url(self::link_doc($d->id, true)) . '" target="_blank">Apri</a> <a class="btn blu" href="' . esc_url(self::link_doc($d->id)) . '">Scarica</a></td></tr>';
            echo '</tbody></table>';
        }
        echo '</div>';
        return ob_get_clean();
    }

    /** Converte i dati della vecchia griglia presenze e le vecchie richieste nei giustificativi */
    static function migra_presenze() {
        global $wpdb;
        if (get_option('pdl_migrato_giust')) return;
        $map = ['F' => 'Ferie', 'PE' => 'Permessi', 'M' => 'Malattia', 'A' => 'Assenza Ingiustificata'];
        $old = $wpdb->get_results("SELECT * FROM " . self::t('presenze'));
        foreach ((array)$old as $r) if (isset($map[$r->codice])) {
            $tipo = $map[$r->codice]; $ore = $r->ore !== null ? (float)$r->ore : self::ore_contratto($r->utente_id, $r->giorno);
            $wpdb->insert(self::t('giust'), ['utente_id' => $r->utente_id, 'giorno' => $r->giorno, 'tipo' => $tipo, 'ore' => $ore, 'intero' => $tipo === 'Permessi' ? 0 : 1, 'stato' => 'Approvato', 'gruppo' => 'old' . $r->utente_id . str_replace('-', '', $r->giorno), 'creato' => current_time('mysql'), 'creato_da' => 0]);
        }
        $req = $wpdb->get_results("SELECT * FROM " . self::t('richieste') . " WHERE stato='In attesa'");
        foreach ((array)$req as $r) self::crea_giust($r->utente_id, $r->tipo === 'Permesso' ? 'Permessi' : $r->tipo, $r->dal, $r->al, '', '', $r->ore, 'In attesa', (string)$r->motivo, 'rq' . $r->id);
        update_option('pdl_migrato_giust', 1);
    }

    /* =====================================================================
       AREA DIPENDENTI COME APP (installabile sul telefono)
       ===================================================================== */
    static function icona_app($dim = 512) {
        $n = $dim >= 512 ? 512 : ($dim >= 192 ? 192 : ($dim >= 180 ? 180 : 32));
        return plugins_url('assets/icona-' . $n . '.png', __FILE__) . '?v=' . PDL_VER;
    }
    static function area_template() {
        $p = (int)get_option('pdl_pagina');
        if (!$p || !is_page($p)) return;
        $url = self::url_area();
        if (!defined('DONOTCACHEPAGE')) define('DONOTCACHEPAGE', true);
        header('Cache-Control: no-store, no-cache, must-revalidate'); header('X-LiteSpeed-Cache-Control: no-cache');
        if (isset($_GET['pdl_manifest'])) self::manifest('Area dipendenti · ' . get_bloginfo('name'), 'Area dipendenti', $url);
        if (isset($_GET['pdl_sw'])) self::sw();
        if (isset($_GET['pdl_icona'])) {
            header('Content-Type: image/svg+xml'); header('Cache-Control: max-age=86400');
            echo '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><rect width="512" height="512" rx="96" fill="#1559c9"/><text x="256" y="320" font-family="Arial,sans-serif" font-size="220" font-weight="700" fill="#fff" text-anchor="middle">DL</text></svg>';
            exit;
        }
        nocache_headers();
        $corpo = self::shortcode();
        $ic = self::icona_app(180);
        while (ob_get_level() > 0) @ob_end_clean(); // niente aggiunte di altri plugin (es. schermate di caricamento col logo del sito)
        header('Content-Type: text/html; charset=utf-8');
        echo '<!doctype html><html lang="it"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="robots" content="noindex,nofollow">'
           . '<title>Area dipendenti · ' . esc_html(get_bloginfo('name')) . '</title><meta name="theme-color" content="#1559c9"><link rel="manifest" href="' . esc_url(add_query_arg(['pdl_manifest' => 1, 'v' => PDL_VER], $url)) . '">'
           . '<meta name="apple-mobile-web-app-capable" content="yes"><meta name="mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-status-bar-style" content="default"><meta name="apple-mobile-web-app-title" content="Area dipendenti">'
           . '<link rel="apple-touch-icon" href="' . esc_url($ic) . '"><link rel="icon" href="' . esc_url(self::icona_app(32)) . '">'
           . '<link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">'
           . '<style>html,body{margin:0;background:#f3f5f9}body{padding:max(14px,env(safe-area-inset-top)) 14px max(20px,env(safe-area-inset-bottom))}.pdl-area{max-width:760px}
#pdl-inst{display:none;margin:0 auto 14px;max-width:760px;background:#fff;border:1px solid #c9d8f2;border-radius:8px;padding:12px 14px;font:14px Inter,sans-serif;color:#1d3c73;align-items:center;gap:10px}#pdl-inst button{margin-left:auto;background:#1559c9;color:#fff;border:0;border-radius:4px;padding:8px 12px;font:inherit;cursor:pointer}#pdl-inst .x{background:none;color:#6b7684;margin:0;padding:4px 8px}
.pdl-area .card .login{box-shadow:none}</style></head><body>'
           . '<div id="pdl-inst"><span id="pdl-inst-t">Installa l\'app sul telefono per aprirla con un tocco.</span><button id="pdl-inst-b">Installa</button><button class="x" onclick="this.parentNode.style.display=\'none\';try{localStorage.pdlNoInst=1}catch(e){}">✕</button></div>'
           . $corpo
           . self::push_js($url)
           . '<script>
(function(){var b=document.getElementById("pdl-inst"),no=false;try{no=!!localStorage.pdlNoInst}catch(e){}var standalone=window.matchMedia("(display-mode: standalone)").matches||navigator.standalone;if(standalone||no)return;
var ev=null;window.addEventListener("beforeinstallprompt",function(e){e.preventDefault();ev=e;b.style.display="flex";});
document.getElementById("pdl-inst-b").addEventListener("click",function(){if(ev){ev.prompt();ev.userChoice.then(function(){b.style.display="none";});}});
if(/iphone|ipad|ipod/i.test(navigator.userAgent)){document.getElementById("pdl-inst-t").innerHTML="Per installare l\'app: tocca <b>Condividi</b> in basso e poi <b>Aggiungi alla schermata Home</b>.";document.getElementById("pdl-inst-b").style.display="none";b.style.display="flex";}})();</script></body></html>';
        exit;
    }

    /* =====================================================================
       APP E NOTIFICHE PUSH (Web Push con chiavi VAPID, senza contenuto cifrato:
       il telefono riceve un "avviso" e scarica il testo dal sito)
       ===================================================================== */
    static function b64u($s) { return rtrim(strtr(base64_encode($s), '+/', '-_'), '='); }
    static function vapid() {
        $v = get_option('pdl_vapid');
        if (is_array($v) && !empty($v['pem']) && !empty($v['pub'])) return $v;
        $k = openssl_pkey_new(['curve_name' => 'prime256v1', 'private_key_type' => OPENSSL_KEYTYPE_EC]);
        if (!$k) return null;
        openssl_pkey_export($k, $pem); $d = openssl_pkey_get_details($k);
        $pad = function ($b) { return str_pad($b, 32, "\0", STR_PAD_LEFT); };
        $v = ['pem' => $pem, 'pub' => self::b64u("\x04" . $pad($d['ec']['x']) . $pad($d['ec']['y']))];
        update_option('pdl_vapid', $v, false);
        return $v;
    }
    static function der2raw($der) {
        $o = 2; if (ord($der[1]) & 0x80) $o += ord($der[1]) & 0x7f;
        $out = '';
        for ($i = 0; $i < 2; $i++) { $l = ord($der[$o + 1]); $n = substr($der, $o + 2, $l); $o += 2 + $l; $out .= str_pad(ltrim($n, "\0"), 32, "\0", STR_PAD_LEFT); }
        return $out;
    }
    static function jwt($aud) {
        $v = self::vapid(); if (!$v) return '';
        $h = self::b64u(wp_json_encode(['typ' => 'JWT', 'alg' => 'ES256']));
        $c = self::b64u(wp_json_encode(['aud' => $aud, 'exp' => time() + 12 * 3600, 'sub' => 'mailto:' . get_option('admin_email')]));
        if (!openssl_sign("$h.$c", $sig, $v['pem'], OPENSSL_ALGO_SHA256)) return '';
        return "$h.$c." . self::b64u(self::der2raw($sig));
    }
    static function push_invia($endpoint) {
        $p = wp_parse_url($endpoint); if (empty($p['scheme']) || $p['scheme'] !== 'https') return 0;
        $jwt = self::jwt($p['scheme'] . '://' . $p['host']); if (!$jwt) return 0;
        $r = wp_remote_post($endpoint, ['timeout' => 6, 'body' => '', 'headers' => ['TTL' => '86400', 'Urgency' => 'high', 'Content-Length' => '0',
            'Authorization' => 'vapid t=' . $jwt . ', k=' . self::vapid()['pub']]]);
        return is_wp_error($r) ? 0 : (int)wp_remote_retrieve_response_code($r);
    }
    /** Mette in coda una notifica per un utente e la spinge su tutti i suoi telefoni */
    static function notifica($uid, $titolo, $testo, $url) {
        $uid = (int)$uid; if (!$uid) return;
        $q = get_user_meta($uid, 'pdl_notif', true); $q = is_array($q) ? $q : [];
        $q[] = ['id' => wp_generate_password(8, false), 't' => $titolo, 'b' => $testo, 'u' => $url, 'tm' => time(), 'x' => 0];
        update_user_meta($uid, 'pdl_notif', array_slice($q, -30));
        $subs = get_user_meta($uid, 'pdl_push_subs', true); $subs = is_array($subs) ? $subs : [];
        foreach (array_keys($subs) as $ep) { $c = self::push_invia($ep); if ($c === 404 || $c === 410) unset($subs[$ep]); }
        update_user_meta($uid, 'pdl_push_subs', $subs);
    }
    static function notifica_admin($titolo, $testo, $url) { foreach (get_users(['role' => 'administrator', 'fields' => 'ID']) as $id) self::notifica($id, $titolo, $testo, $url); }
    static function chi($uid = 0) { $u = $uid ? get_userdata($uid) : wp_get_current_user(); return $u ? trim($u->first_name . ' ' . $u->last_name) ?: $u->display_name : ''; }
    static function periodo($dal, $al) { return $dal === $al ? 'il ' . date_i18n('j F', strtotime($dal)) : 'dal ' . date_i18n('j F', strtotime($dal)) . ' al ' . date_i18n('j F', strtotime($al)); }

    static function ajax_push_sub() {
        if (!is_user_logged_in() || !check_ajax_referer('pdl_push', 'n', false)) wp_send_json_error();
        $ep = esc_url_raw(wp_unslash($_POST['endpoint'] ?? ''), ['https']); if (!$ep) wp_send_json_error();
        $subs = get_user_meta(get_current_user_id(), 'pdl_push_subs', true); $subs = is_array($subs) ? $subs : [];
        $nuovo = !isset($subs[$ep]); $subs[$ep] = time(); update_user_meta(get_current_user_id(), 'pdl_push_subs', array_slice($subs, -5, null, true));
        if ($nuovo && !empty($_POST['prova'])) self::notifica(get_current_user_id(), 'Notifiche attive', 'Da adesso riceverai qui gli avvisi di ' . get_bloginfo('name') . '.', current_user_can('manage_options') ? self::url_gestione() : self::url_area());
        wp_send_json_success();
    }
    static function ajax_push_get() {
        if (!is_user_logged_in()) wp_send_json([]);
        $uid = get_current_user_id(); $q = get_user_meta($uid, 'pdl_notif', true); $q = is_array($q) ? $q : []; $out = [];
        foreach ($q as &$n) if (empty($n['x']) && $n['tm'] > time() - 7 * DAY_IN_SECONDS) { $out[] = ['id' => $n['id'], 't' => $n['t'], 'b' => $n['b'], 'u' => $n['u']]; $n['x'] = 1; }
        unset($n); update_user_meta($uid, 'pdl_notif', $q);
        nocache_headers(); wp_send_json($out);
    }

    static function manifest($nome, $breve, $url) {
        header('Content-Type: application/manifest+json; charset=utf-8'); header('Cache-Control: no-cache');
        echo wp_json_encode(['id' => wp_make_link_relative($url), 'name' => $nome, 'short_name' => $breve, 'start_url' => $url, 'scope' => wp_make_link_relative($url), 'display' => 'standalone',
            'background_color' => '#f3f5f9', 'theme_color' => '#1559c9', 'lang' => 'it', 'icons' => [['src' => self::icona_app(192), 'sizes' => '192x192', 'type' => 'image/png', 'purpose' => 'any'], ['src' => self::icona_app(512), 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'any']]]);
        exit;
    }
    static function sw() {
        header('Content-Type: application/javascript; charset=utf-8'); header('Cache-Control: no-cache');
        $ajax = admin_url('admin-ajax.php?action=pdl_push_get'); $ic = self::icona_app(192);
        echo "var AJ=" . wp_json_encode($ajax) . ",IC=" . wp_json_encode($ic) . ";\n"
           . "self.addEventListener('install',function(e){self.skipWaiting();});self.addEventListener('activate',function(e){e.waitUntil(self.clients.claim());});\n"
           . "// v" . PDL_VER . " nessuna intercettazione delle pagine: l'app carica sempre dal sito\n"
           . "self.addEventListener('push',function(e){e.waitUntil(fetch(AJ+'&_='+Date.now(),{credentials:'include',cache:'no-store'}).then(function(r){return r.json();}).catch(function(){return [];}).then(function(l){\n"
           . " if(!l||!l.length)return self.registration.showNotification('Nuovo avviso',{body:'Apri l\\'app per vederlo.',icon:IC,badge:IC});\n"
           . " return Promise.all(l.map(function(n){return self.registration.showNotification(n.t,{body:n.b,icon:IC,badge:IC,tag:n.id,data:{url:n.u}});}));}));});\n"
           . "self.addEventListener('notificationclick',function(e){e.notification.close();var u=(e.notification.data&&e.notification.data.url)||self.registration.scope;\n"
           . " e.waitUntil(clients.matchAll({type:'window',includeUncontrolled:true}).then(function(cs){for(var i=0;i<cs.length;i++){if('focus' in cs[i]){cs[i].navigate(u);return cs[i].focus();}}return clients.openWindow(u);}));});";
        exit;
    }
    /** Pulsante "Attiva notifiche" + registrazione dell'app e dell'abbonamento */
    static function push_js($url) {
        if (!is_user_logged_in() || !self::vapid()) return '';
        return '<div id="pdl-notif" style="display:none;position:fixed;left:50%;bottom:16px;transform:translateX(-50%);z-index:95;background:#fff;border:1px solid #c9d8f2;border-radius:10px;box-shadow:0 8px 24px rgba(16,24,40,.18);padding:12px 14px;font:14px Inter,system-ui,sans-serif;color:#1d3c73;align-items:center;gap:10px;width:min(520px,92vw)">'
             . '<span style="flex:1">🔔 Vuoi ricevere gli avvisi sul telefono?</span><button id="pdl-notif-b" style="background:#1559c9;color:#fff;border:0;border-radius:4px;padding:8px 12px;font:inherit;cursor:pointer">Attiva notifiche</button><button id="pdl-notif-x" style="background:none;border:0;color:#6b7684;font-size:16px;cursor:pointer">✕</button></div>'
             . '<script>(function(){var SW=' . wp_json_encode(add_query_arg('pdl_sw', 1, $url)) . ',SC=' . wp_json_encode(wp_make_link_relative($url)) . ',K=' . wp_json_encode(self::vapid()['pub']) . ',AJ=' . wp_json_encode(admin_url('admin-ajax.php')) . ',N=' . wp_json_encode(wp_create_nonce('pdl_push')) . ';
if(!("serviceWorker" in navigator))return;var reg=navigator.serviceWorker.register(SW,{scope:SC}).then(function(){return navigator.serviceWorker.ready;});
if(!("PushManager" in window)||!("Notification" in window))return;
function k(s){s=s.replace(/-/g,"+").replace(/_/g,"/");s+="===".slice((s.length+3)%4);var b=atob(s),a=new Uint8Array(b.length);for(var i=0;i<b.length;i++)a[i]=b.charCodeAt(i);return a;}
function iscrivi(prova){return reg.then(function(r){return r.pushManager.getSubscription().then(function(s){return s||r.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:k(K)});});}).then(function(s){var f=new FormData();f.append("action","pdl_push_sub");f.append("n",N);f.append("endpoint",s.endpoint);if(prova)f.append("prova","1");return fetch(AJ,{method:"POST",body:f,credentials:"same-origin"});});}
var box=document.getElementById("pdl-notif"),no=false;try{no=!!localStorage.pdlNoNotif}catch(e){}
if(Notification.permission==="granted")iscrivi(false).catch(function(){});
else if(Notification.permission==="default"&&!no)box.style.display="flex";
document.getElementById("pdl-notif-b").addEventListener("click",function(){Notification.requestPermission().then(function(p){box.style.display="none";if(p==="granted")iscrivi(true).catch(function(e){alert("Non è stato possibile attivare le notifiche: "+e.message);});});});
document.getElementById("pdl-notif-x").addEventListener("click",function(){box.style.display="none";try{localStorage.pdlNoNotif=1}catch(e){}});})();</script>';
    }
}

register_activation_hook(__FILE__, ['Presenze_DL', 'activate']);
add_action('plugins_loaded', ['Presenze_DL', 'init']);

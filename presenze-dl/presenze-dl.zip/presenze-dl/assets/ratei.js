function rateiPdf(I){var num=/^-?[\d.]+,\d{1,4}-?$/;
 function val(s){s=s.trim();var neg=/-$/.test(s)||/^-/.test(s);s=s.replace(/-/g,"").replace(/\./g,"").replace(",",".");var v=Math.round(parseFloat(s)*100)/100;return neg?-v:v;}
 var H=[];I.forEach(function(o){var re=/(Ferie|Perm\.?|Ex\.?\s*fes\.?t?\.?)\s*(AP|mat\.?\s*H?|god\.?|res\.?)/gi,m;while((m=re.exec(o.s))){
  H.push({k:/^Fer/i.test(m[1])?"ferie":/^Per/i.test(m[1])?"rol":"exfs",c:/^res/i.test(m[2])?"res":/^mat/i.test(m[2])?"mat":/^god/i.test(m[2])?"god":"ap",x:o.x+o.w*(m.index/o.s.length),y:o.y});}});
 if(H.filter(function(h){return h.c==="res";}).length){H.sort(function(a,b){return a.x-b.x;});var hy=Math.max.apply(null,H.map(function(h){return h.y;})),out={ferie:0,rol:0,exfs:0};
  I.filter(function(o){return num.test(o.s.trim())&&o.y<hy-3&&o.y>hy-25;}).forEach(function(v){var r=v.x+v.w,col=null;H.forEach(function(h){if(h.x<=r-1)col=h;});if(col&&col.c==="res")out[col.k]=val(v.s);});return out;}
 var righe={ferie:/^\s*FERIE/i,rol:/PERMESSI|R\.\s*O\.\s*L|^\s*ROL/i,exfs:/EX[\s.]*FESTIV/i},hdr=I.filter(function(o){return /RESIDUI|TOTALI/i.test(o.s);}),out={ferie:0,rol:0,exfs:0},ok=false;
 Object.keys(righe).forEach(function(k){var lab=I.filter(function(o){return righe[k].test(o.s)&&o.s.trim().length<32&&hdr.some(function(h){return h.y>o.y&&h.y<o.y+60;});}).sort(function(a,b){return a.x-b.x;})[0];if(!lab)return;
  var hs=hdr.filter(function(h){return h.y>lab.y&&h.y<lab.y+60;}),hx=Math.max.apply(null,hs.map(function(h){return h.x+h.w;}));
  var best=null,bd=40;I.forEach(function(o){if(num.test(o.s.trim())&&Math.abs(o.y-lab.y)<=4&&o.x>lab.x){var d=Math.abs(o.x+o.w-hx);if(d<bd){bd=d;best=o;}}});ok=true;if(best)out[k]=val(best.s);});
 return ok?out:null;}
(function(){var L=window.PDL_BUSTE||[],f=document.getElementById("bilbuste");if(!f||!L.length)return;var st=document.getElementById("bilst"),btn=document.getElementById("bilbtn");
function carica(u){return new Promise(function(ok,ko){var s=document.createElement("script");s.src=u;s.onload=ok;s.onerror=ko;document.head.appendChild(s);});}
function lib(){return window.pdfjsLib?Promise.resolve():carica("https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js").then(function(){pdfjsLib.GlobalWorkerOptions.workerSrc="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js";});}
function leggi(b){return fetch(b.url.replace(/&amp;/g,"&"),{credentials:"same-origin"}).then(function(r){return r.arrayBuffer();}).then(function(a){return pdfjsLib.getDocument({data:new Uint8Array(a)}).promise;}).then(function(d){return d.getPage(1);}).then(function(p){return p.getTextContent();}).then(function(c){return rateiPdf(c.items.map(function(x){return {s:x.str,x:x.transform[4],y:x.transform[5],w:x.width};}));}).catch(function(){return null;});}
function vai(tutti){var lista=L.filter(function(b){return tutti||b.nuovo;});if(!lista.length)return;btn.disabled=true;var out=[],i=0;
 lib().then(function next(){if(i>=lista.length){if(!out.length){st.textContent="Non sono riuscito a leggere i saldi dalle buste";btn.disabled=false;return;}f.dati.value=JSON.stringify(out);f.submit();return;}
  var b=lista[i++];st.textContent="Lettura busta "+i+" di "+lista.length+"…";return leggi(b).then(function(v){if(v)out.push({u:b.u,id:b.id,v:v});return next();});}).catch(function(){st.textContent="Errore nel caricare il lettore PDF";btn.disabled=false;});}
btn.onclick=function(){vai(true);};vai(false);})();
